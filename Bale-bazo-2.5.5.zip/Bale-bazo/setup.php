#!/usr/bin/env php
<?php
// setup.php — آزمون اتصال و ثبت اختیاری webhook

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

define('BALE_BAZO_VERSION', '2.5.5');
require_once __DIR__ . '/helpers/SiteClient.php';
require_once __DIR__ . '/database/Database.php';
require_once __DIR__ . '/helpers/BaleApi.php';

$config = require __DIR__ . '/config/config.php';
SiteClient::configure($config);

foreach (['curl', 'json', 'mbstring', 'fileinfo'] as $extension) {
    if (!extension_loaded($extension)) {
        fwrite(STDERR, "افزونه PHP لازم فعال نیست: {$extension}\n");
        exit(1);
    }
}

fwrite(STDOUT, "=== راه‌اندازی Bale Bazo Site Sync ===\n\n");

$required = ['bot_token'=>'BALE_BOT_TOKEN', 'site_url'=>'MPH_SITE_URL', 'site_sync_secret'=>'MPH_SITE_SYNC_SECRET', 'webhook_secret'=>'BALE_WEBHOOK_SECRET'];
foreach ($required as $key=>$name) {
    if (trim((string)($config[$key] ?? '')) === '') {
        fwrite(STDERR, "خطا: {$name} تنظیم نشده است.\n");
        exit(1);
    }
}
if (strlen((string)$config['site_sync_secret']) < 32 || strlen((string)$config['webhook_secret']) < 32) {
    fwrite(STDERR, "خطا: MPH_SITE_SYNC_SECRET و BALE_WEBHOOK_SECRET باید حداقل ۳۲ کاراکتر باشند.\n");
    exit(1);
}

try {
    $health = SiteClient::health();
    fwrite(STDOUT, "[✓] اتصال امن سایت: " . ($health['site_name'] ?? 'WordPress') . "\n");
    fwrite(STDOUT, "[✓] نسخه افزونه: " . ($health['plugin_version'] ?? 'نامشخص') . "\n");
    if (empty($health['features']['durable_updates']) || version_compare((string)($health['plugin_version'] ?? '0'), '28.0.0', '<')) {
        fwrite(STDERR, "[×] ابتدا Modern Profile Hub 28.0.0 یا بالاتر را نصب کنید.\n");
        exit(2);
    }
    if (version_compare((string)($health['plugin_version'] ?? '0'), '28.0.1', '<')) {
        fwrite(STDOUT, "[!] افزونه 28.0.1 به بعد پیشنهاد می‌شود (یادآوری سریع‌تر ثبت‌نام و کنترل مبلغ پرداخت).\n");
    }
    $storeCurrency = strtoupper((string)($health['store_currency'] ?? ''));
    if (!in_array($storeCurrency, ['IRR','RIAL','IRT','TOMAN','TMN'], true)) {
        fwrite(STDERR, "[×] واحد پول WooCommerce باید ریال یا تومان باشد؛ مقدار فعلی: " . ($storeCurrency ?: 'نامشخص') . "\n");
        exit(2);
    }
    fwrite(STDOUT, "[✓] واحد فروشگاه: {$storeCurrency} (نمایش ربات: تومان، پرداخت بله: ریال)\n");
    fwrite(STDOUT, "[✓] منبع داده: WordPress database\n");
    SiteClient::call('runtimeDiagnostics');
    fwrite(STDOUT, "[✓] جدول پردازش و بازیابی درخواست‌ها آماده است.\n");
} catch (SiteSyncException $error) {
    fwrite(STDERR, "[×] اتصال سایت: {$error->getMessage()} ({$error->getRemoteCode()})\n");
    exit(2);
}

$api = new BaleApi((string)$config['bot_token'], (string)$config['api_base']);
$identity = $api->getMe();
if (empty($identity['ok'])) {
    fwrite(STDERR, "[×] توکن ربات بله معتبر نیست یا API در دسترس نیست.\n");
    exit(3);
}
fwrite(STDOUT, "[✓] اتصال API بله برقرار است.\n");

$webhook = '';
foreach (array_slice($argv ?? [], 1) as $arg) {
    if (str_starts_with($arg, '--webhook=')) $webhook = trim(substr($arg, 10));
}
if ($webhook !== '') {
    if (!filter_var($webhook, FILTER_VALIDATE_URL) || strtolower((string)parse_url($webhook, PHP_URL_SCHEME)) !== 'https') {
        fwrite(STDERR, "[×] webhook باید یک URL معتبر HTTPS باشد.\n");
        exit(4);
    }
    if (!empty($config['webhook_secret'])) {
        $separator = str_contains($webhook, '?') ? '&' : '?';
        $webhook .= $separator . 'key=' . rawurlencode((string)$config['webhook_secret']);
    }
    $result = $api->setWebhook($webhook);
    if (empty($result['ok'])) {
        fwrite(STDERR, "[×] ثبت webhook توسط بله رد شد.\n");
        exit(5);
    }
    fwrite(STDOUT, "[✓] webhook ثبت شد.\n");
} else {
    fwrite(STDOUT, "[i] برای ثبت webhook اجرا کنید:\n");
    fwrite(STDOUT, "    php setup.php --webhook=https://bot.example.com/index.php\n");
}

fwrite(STDOUT, "\nراه‌اندازی کامل است؛ ربات هیچ دیتابیس محلی ندارد.\n");
