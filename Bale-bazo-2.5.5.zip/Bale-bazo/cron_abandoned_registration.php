<?php
// cron_abandoned_registration.php
//
// این اسکریپت برای یادآوری به کاربرانی است که ثبت‌نام را نیمه‌کاره رها کرده‌اند.
// باید با استفاده از Cron Job سرور هر چند دقیقه یک‌بار اجرا شود (مثلاً هر ۵ دقیقه):
//
//   */5 * * * * php /path/to/Bale-bazo/cron_abandoned_registration.php >> /path/to/Bale-bazo/cron.log 2>&1
//
// منطق: اگر کاربری مرحله ثبت‌نام (step با پیشوند reg_) را شروع کرده اما حداقل
// REMINDER_DELAY_MINUTES دقیقه است که آن را به پایان نرسانده و قبلاً برایش
// یادآوری ارسال نشده، یک پیام یادآوری برایش ارسال می‌شود.

declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '0');

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

define('BASE_DIR', __DIR__);
define('BALE_BAZO_VERSION', '2.5.5');
define('REMINDER_DELAY_MINUTES', 10); // پس از چند دقیقه یادآوری ارسال شود

require_once BASE_DIR . '/helpers/SiteClient.php';
require_once BASE_DIR . '/database/Database.php';
require_once BASE_DIR . '/helpers/StateManager.php';
require_once BASE_DIR . '/helpers/BaleApi.php';
require_once BASE_DIR . '/helpers/Keyboards.php';

$config = require BASE_DIR . '/config/config.php';
if (empty($config['bot_token']) || empty($config['site_url']) || strlen((string)($config['site_sync_secret'] ?? '')) < 32) {
    fwrite(STDERR, "Bale Bazo configuration is incomplete.\n");
    exit(1);
}
SiteClient::configure($config);
StateManager::init();
Keyboards::configure($config);
$api = new BaleApi($config['bot_token'], $config['api_base']);
try {
    $health = SiteClient::health();
} catch (SiteSyncException $error) {
    fwrite(STDERR, "Website sync is unavailable: " . $error->getRemoteCode() . "\n");
    exit(2);
}
$siteName = htmlspecialchars(trim((string)($health['site_name'] ?? 'سایت')) ?: 'سایت', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

$now     = time();
$sent    = 0;

$sendReminder = function (string $chatId) use ($api, $siteName, &$sent): void {
    SiteClient::setActorChatId($chatId);
    $api->sendMessage(
        $chatId,
        "👋 سلام!\n\n"
        . "متوجه شدیم اتصال حساب خود به <b>{$siteName}</b> را کامل نکرده‌اید.\n"
        . "آیا مشکلی پیش آمده؟ 🤔\n\n"
        . "برای ادامه ثبت‌نام از همان جایی که رها کرده‌اید، کافیست به سؤال قبلی پاسخ دهید یا دستور /start را بزنید.",
        Keyboards::cancelOnly()
    );
    StateManager::markReminded($chatId);
    $sent++;
};

// مسیر سریع (افزونه 28.0.1 به بعد): فقط شناسه چت‌های رهاشده از سایت می‌آید؛
// بدون دانلود کل وضعیت‌ها و بدون استعلام تکی هر کاربر.
$chatIds = Database::abandonedRegistrations(REMINDER_DELAY_MINUTES);
$rpcError = Database::lastError();
if ($rpcError && in_array((string)$rpcError['code'], ['method_not_allowed', 'method_unavailable', 'invalid_method'], true)) {
    // افزونه قدیمی: همان پویش قبلی روی همه وضعیت‌ها.
    foreach (StateManager::getAll() as $chatId => $state) {
        $chatId = (string)$chatId;
        SiteClient::setActorChatId($chatId);
        $step = $state['step'] ?? null;
        if (!$step || !str_starts_with($step, 'reg_')) {
            continue; // فقط مراحل ثبت‌نام بررسی شود
        }
        // اگر کاربر قبلاً ثبت‌نام کامل کرده (رکورد در users دارد)، رهایش کن
        if (Database::getUser($chatId)) {
            continue;
        }
        if (!empty($state['reminded'])) {
            continue; // قبلاً یادآوری ارسال شده
        }
        $updatedAt = $state['updated_at'] ?? null;
        if (!$updatedAt || ($now - $updatedAt) < (REMINDER_DELAY_MINUTES * 60)) {
            continue; // هنوز زمان کافی نگذشته
        }
        $sendReminder($chatId);
    }
} else {
    foreach ($chatIds as $chatId) {
        $sendReminder((string)$chatId);
    }
}

echo date('Y-m-d H:i:s') . " - بررسی ثبت‌نام‌های نیمه‌کاره انجام شد. تعداد یادآوری ارسال‌شده: {$sent}\n";
