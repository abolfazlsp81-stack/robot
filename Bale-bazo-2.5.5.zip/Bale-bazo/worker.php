#!/usr/bin/env php
<?php
declare(strict_types=1);
if (PHP_SAPI!=='cli') { http_response_code(404); exit; }
define('BALE_BAZO_VERSION','2.5.5');
require_once __DIR__.'/helpers/SiteClient.php';
$config=require __DIR__.'/config/config.php';
SiteClient::configure($config);
try {
    if (in_array('--status',$argv??[],true)) {
        $status=SiteClient::call('runtimeDiagnostics');
        fwrite(STDOUT,json_encode($status,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n");
        exit;
    }
    $started=microtime(true);$processed=0;
    do {
        $pending=SiteClient::call('pendingUpdates');
        if(empty($pending[0]))break;
        if(!function_exists('proc_open')){$GLOBALS['BALE_WORKER_UPDATE']=$pending[0];require __DIR__.'/index.php';break;}
        // Isolate globals for every update; the site still owns the atomic claim and retry state.
        $process=proc_open([PHP_BINARY,__DIR__.'/worker-child.php'],[0=>['pipe','r'],1=>STDOUT,2=>STDERR],$pipes,__DIR__);
        if(!is_resource($process))throw new RuntimeException('worker_process_unavailable');
        $payload=json_encode($pending[0],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        fwrite($pipes[0],$payload);fclose($pipes[0]);
        $deadline=microtime(true)+35;$status=array('running'=>true,'exitcode'=>-1);
        do{$status=proc_get_status($process);if(empty($status['running']))break;usleep(100000);}while(microtime(true)<$deadline);
        if(!empty($status['running'])){proc_terminate($process);fwrite(STDERR,"[BaleBazo worker] child_timeout\n");}
        $closed=proc_close($process);$code=(int)($status['exitcode']??-1);if($code<0)$code=$closed;$processed++;
        if($code!==0)break;
    }while($processed<5 && microtime(true)-$started<40);
    if($processed)fwrite(STDOUT,'[BaleBazo worker] processed='.$processed.' elapsed_ms='.(int)((microtime(true)-$started)*1000)."\n");
} catch (Throwable $error) {
    if(class_exists('UpdateLifecycle'))UpdateLifecycle::fail($error instanceof SiteSyncException?$error->getRemoteCode():'processing_error');
    http_response_code(503);
    fwrite(STDERR,'[BaleBazo worker] '.($error instanceof SiteSyncException?$error->getRemoteCode():'processing_error')."\n");
    exit(1);
}
