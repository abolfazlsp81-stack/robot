<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
$payload=json_decode(stream_get_contents(STDIN),true);
if(!is_array($payload)||!isset($payload['update_id']))exit(2);
$GLOBALS['BALE_WORKER_UPDATE']=$payload;
require __DIR__.'/index.php';
