<?php
declare(strict_types=1);
class SiteSyncException extends RuntimeException {
    public function getStatus():int{return 503;}
    public function getRemoteCode():string{return 'network_error';}
}
class SiteClient {
    public static array $calls=[];public static string $job='';public static bool $fail=false;
    public static function call(string $method,array $params=[],bool $cache=false){
        self::$calls[]=$method;if(self::$fail)throw new SiteSyncException('test');
        return ['status'=>'processing','token'=>'test-token','context'=>['user'=>['id'=>'123'],'is_admin'=>true],'state'=>['step'=>'reg_name','data'=>[],'updated_at'=>time(),'reminded'=>false]];
    }
    public static function setJob(string $id,string $token):void{self::$job=$id;}
    public static function actorChatId():string{return '123';}
}
require dirname(__DIR__).'/database/Database.php';
require dirname(__DIR__).'/helpers/StateManager.php';
StateManager::init();
Database::bootstrap('123','90',['update_id'=>90]);
if(Database::getUser('123')['id']!=='123' || StateManager::getStep('123')!=='reg_name' || !Database::isAdmin('123'))throw new RuntimeException('Bootstrap data was not reused');
if(SiteClient::$calls!==['beginUpdate'])throw new RuntimeException('Bootstrap caused redundant site requests');
SiteClient::$fail=true;
try {Database::stateSet('123','next',[]);throw new RuntimeException('Network failure was swallowed');}catch(SiteSyncException $e){}
if(!Database::retryError())throw new RuntimeException('Retry failure was not retained');
echo "Bootstrap: context + role + state use one HTTP request; retry errors propagate.\n";
