<?php
declare(strict_types=1);

final class TestFailure extends RuntimeException {}
function check(bool $condition, string $message): void { if (!$condition) throw new TestFailure($message); }

class BaleApi {
    public array $messages=[];
    public function sendMessage(string $chatId,string $text,array $keyboard=[]): array {$this->messages[]=compact('chatId','text','keyboard');return ['ok'=>true];}
}
class StateManager {
    public static ?string $step='reg_phone'; public static array $data=[];
    public static function getStep(string $id): ?string{return self::$step;}
    public static function getData(string $id): array{return self::$data;}
    public static function set(string $id,string $step,array $data=[]): void{self::$step=$step;self::$data=array_merge(self::$data,$data);}
    public static function clear(string $id): void{self::$step=null;self::$data=[];}
}
class Database {
    public static int $linkCalls=0; public static ?array $linkResult=null; public static array $context=[];
    public static function linkAccount(string $chat,string $phone,string $contact): ?array{self::$linkCalls++;return self::$linkResult;}
    public static function lastError(): ?array{return ['message'=>'remote'];}
    public static function refreshContext(string $chat): array{return self::$context;}
    public static function createUser(...$args): bool{return true;}
    public static function getAllAdmins(): array{return [];}
}
class Keyboards {
    public static array $context=[];
    public static function ownContact(): array{return ['keyboard'=>[[['text'=>'share','request_contact'=>true]]]];}
    public static function cancelOnly(): array{return [];}
    public static function backCancel(): array{return [];}
    public static function skipBackCancel(string $x): array{return [];}
    public static function educationLevels(bool $x=false): array{return [];}
    public static function setUserContext(array $x): void{self::$context=$x;}
    public static function adminMain(bool $x=false): array{return [['admin']];}
    public static function userMain(): array{return [['user']];}
}
class MediaSync {public static function transfer(...$args): array{return ['id'=>1];}}
require dirname(__DIR__).'/handlers/RegisterHandler.php';

$api=new BaleApi();$handler=new RegisterHandler($api);
$handler->handle(['message'=>['chat'=>['id'=>'123'],'from'=>['id'=>'123'],'text'=>'09121234567']]);
check(Database::$linkCalls===0,'Typed phone must never link an account.');
check(!empty($api->messages[0]['keyboard']['keyboard'][0][0]['request_contact']),'Own-contact button was not returned.');

$api->messages=[];StateManager::$step='reg_phone';Database::$linkCalls=0;Database::$linkResult=['linked'=>false];
$handler->handle(['message'=>['chat'=>['id'=>'123'],'from'=>['id'=>'123'],'contact'=>['user_id'=>'999','phone_number'=>'+989121234567']]]);
check(Database::$linkCalls===0,'Another user contact must be rejected.');

$api->messages=[];StateManager::$step='reg_phone';StateManager::$data=[];Database::$linkResult=['linked'=>false];
$handler->handle(['message'=>['chat'=>['id'=>'123'],'from'=>['id'=>'123'],'contact'=>['user_id'=>'123','phone_number'=>'+989121234567']]]);
check(Database::$linkCalls===1,'Verified own contact was not sent to the site.');
check(StateManager::$step==='reg_first_name','New verified user did not advance to profile creation.');
check((StateManager::$data['phone']??'')==='09121234567','Verified phone was not normalized.');

$api->messages=[];StateManager::$step='reg_phone';Database::$linkResult=['linked'=>true];Database::$context=['user'=>['fl_name'=>'Ali','roles'=>['instructor']],'is_admin'=>false];
$handler->handle(['message'=>['chat'=>['id'=>'123'],'from'=>['id'=>'123'],'contact'=>['user_id'=>'123','phone_number'=>'09121234567']]]);
check(StateManager::$step===null,'Existing site account registration state was not cleared.');
check(Keyboards::$context['fl_name']==='Ali','Existing site profile was not loaded.');
check(str_contains(end($api->messages)['text'],'حساب سایت متصل شد'),'Existing-account success was not shown.');

fwrite(STDOUT,"Register identity scenarios passed.\n");
