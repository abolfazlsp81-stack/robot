<?php
declare(strict_types=1);

final class TestFailure extends RuntimeException {}
function check(bool $condition, string $message): void { if (!$condition) throw new TestFailure($message); }
class BaleApi {
    public array $messages=[]; public int $inquiries=0; public array $transaction=['status'=>'paid','amount'=>125000,'userID'=>'123'];
    public function sendMessage(string $chat,string $text,array $keyboard=[]): array{$this->messages[]=$text;return ['ok'=>true];}
    public function inquireTransaction(string $id): array{$this->inquiries++;return ['ok'=>true,'result'=>$this->transaction];}
}
class Database {
    public static ?array $enrollment=null; public static array $confirms=[]; public static ?array $error=null;
    public static function getEnrollmentById(int $id): ?array{return self::$enrollment;}
    public static function getEnrollmentByUserCourse(int $u,int $c,int $p=0): ?array{return self::$enrollment;}
    public static function lastError(): ?array{return self::$error;}
    public static function confirmEnrollment(int $u,int $c,string $payment,int $p=0,int $order=0): bool{self::$confirms[]=compact('u','c','payment','p','order');return true;}
}
class Keyboards {public static function userMain(): array{return [];}}
require dirname(__DIR__).'/handlers/UserHandler.php';

function paymentUpdate(int $amount=125000,string $chat='123'): array{return ['message'=>['chat'=>['id'=>$chat],'successful_payment'=>['invoice_payload'=>'mph_order_88','currency'=>'IRR','total_amount'=>$amount,'telegram_payment_charge_id'=>'TX-1']]];}
$base=['id'=>88,'user_chat_id'=>'123','course_id'=>7,'product_id'=>12,'payment_amount_rial'=>125000,'payment_status'=>'pending','access_synced'=>false,'tracking_code'=>'ENR-X','delivery_label'=>'آنلاین','course_title'=>'دوره تست'];
$user=['id'=>'123'];

Database::$enrollment=$base;Database::$confirms=[];$api=new BaleApi();$handler=new UserHandler($api);
check($handler->handleSuccessfulPayment(paymentUpdate(),$user),'Valid payment was treated as retryable failure.');
check(count(Database::$confirms)===1 && Database::$confirms[0]['order']===88,'Payment did not confirm its exact order.');
check($api->inquiries===1,'Wallet transaction was not inquired.');

Database::$enrollment=$base;Database::$confirms=[];$api=new BaleApi();$handler=new UserHandler($api);
check($handler->handleSuccessfulPayment(paymentUpdate(124999),$user),'Invalid amount should be handled without webhook retry.');
check(Database::$confirms===[] && $api->inquiries===0,'Mismatched amount reached confirmation or inquiry.');

Database::$enrollment=array_merge($base,['payment_status'=>'paid','payment_id'=>'TX-1','access_synced'=>true]);Database::$confirms=[];$api=new BaleApi();$handler=new UserHandler($api);
check($handler->handleSuccessfulPayment(paymentUpdate(),$user),'Idempotent retry failed.');
check(Database::$confirms===[] && $api->inquiries===0,'Completed retry duplicated payment handling.');

Database::$enrollment=array_merge($base,['payment_status'=>'paid','payment_id'=>'TX-1','access_synced'=>false]);Database::$confirms=[];$api=new BaleApi();$handler=new UserHandler($api);
check($handler->handleSuccessfulPayment(paymentUpdate(),$user),'Access-repair retry failed.');
check(count(Database::$confirms)===1,'Paid order with unsynced access was not repaired.');

Database::$enrollment=$base;Database::$confirms=[];$api=new BaleApi();$handler=new UserHandler($api);
check($handler->handleSuccessfulPayment(paymentUpdate(125000,'456'),$user),'Wrong-owner payment should be handled without retry.');
check(Database::$confirms===[],'Wrong owner could confirm an order.');

fwrite(STDOUT,"Payment reconciliation scenarios passed.\n");
