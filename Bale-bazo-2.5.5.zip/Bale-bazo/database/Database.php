<?php
// database/Database.php
// این کلاس قرارداد نسخه قدیمی ربات را نگه می‌دارد؛ منبع داده فقط وردپرس است.

declare(strict_types=1);

final class Database
{
    private static array $contexts = [];
    private static ?array $lastError = null;
    private static ?array $retryError = null;

    public static function bootstrap(string $chatId, string $id, array $update): array {
        $data = self::request('beginUpdate', ['update_id'=>$id,'update'=>$update], []);
        if (!is_array($data) || empty($data['status'])) throw new SiteSyncException('پاسخ آغاز پردازش نامعتبر است.',503,'bootstrap_invalid');
        if (($data['status'] ?? '') === 'processing') {
            self::$contexts[$chatId] = (array)$data['context'];
            StateManager::seed($chatId,(array)$data['state']);
            SiteClient::setJob($id,(string)$data['token']);
        }
        return $data;
    }

    public static function retryError(): ?array { return self::$retryError; }
    public static function clearRetryError(): void { self::$retryError = null; }

    /** سازگاری با setup/index قدیمی؛ هیچ SQLiteای باز نمی‌شود. */
    public static function getInstance(): SiteClient
    {
        if (!SiteClient::isConfigured()) {
            throw new SiteSyncException('اتصال سایت تنظیم نشده است.', 0, 'not_configured');
        }
        return new SiteClient();
    }

    public static function lastError(): ?array
    {
        return self::$lastError;
    }

    public static function getContext(string $chatId): array
    {
        $chatId = trim($chatId);
        if (isset(self::$contexts[$chatId])) return self::$contexts[$chatId];
        $context = self::request('context', ['chat_id'=>$chatId], []);
        self::$contexts[$chatId] = is_array($context) ? $context : [];
        return self::$contexts[$chatId];
    }

    public static function refreshContext(string $chatId): array
    {
        unset(self::$contexts[trim($chatId)]);
        return self::getContext($chatId);
    }

    public static function linkAccount(string $chatId, string $phone, string $contactUserId): ?array
    {
        $result = self::request('linkAccount', ['chat_id'=>$chatId, 'phone'=>$phone, 'contact_user_id'=>$contactUserId], null);
        unset(self::$contexts[$chatId]);
        return is_array($result) ? $result : null;
    }

    public static function getUser(string $chatId): ?array
    {
        $context = self::getContext($chatId);
        return is_array($context['user'] ?? null) ? $context['user'] : null;
    }

    public static function createUser(
        string $chatId,
        string $firstName,
        string $lastName,
        string $phone,
        string $birth,
        string $idCard = '',
        string $fieldOfStudy = '',
        string $educationLevel = '',
        ?string $profilePhoto = null,
        string $firstNameEn = '',
        string $lastNameEn = ''
    ): bool {
        $ok = (bool) self::request('createUser', [
            'chat_id'=>$chatId, 'first_name'=>$firstName, 'last_name'=>$lastName,
            'phone'=>$phone, 'birthdate'=>$birth, 'id_card'=>$idCard,
            'field_of_study'=>$fieldOfStudy, 'education_level'=>$educationLevel,
            'profile_photo'=>$profilePhoto, 'first_name_en'=>$firstNameEn,
            'last_name_en'=>$lastNameEn,
        ], false);
        unset(self::$contexts[$chatId]);
        return $ok;
    }

    public static function updateUserField(string $chatId, string $field, string $value): bool
    {
        $ok = (bool) self::request('updateUserField', ['chat_id'=>$chatId, 'field'=>$field, 'value'=>$value], false);
        unset(self::$contexts[$chatId]);
        return $ok;
    }

    public static function updatePhoneByContact(string $chatId, string $phone, string $contactUserId): bool
    {
        $ok = (bool)self::request('updatePhoneByContact', [
            'chat_id'=>$chatId, 'phone'=>$phone, 'contact_user_id'=>$contactUserId,
        ], false);
        unset(self::$contexts[$chatId]);
        return $ok;
    }

    public static function syncFullName(string $chatId, bool $english = false): void
    {
        self::request('syncFullName', ['chat_id'=>$chatId, 'english'=>$english], false);
        unset(self::$contexts[$chatId]);
    }

    public static function updateProfilePhoto(string $chatId, string $fileId): bool
    {
        $ok = (bool) self::request('updateProfilePhoto', ['chat_id'=>$chatId, 'file_id'=>$fileId], false);
        unset(self::$contexts[$chatId]);
        return $ok;
    }

    public static function getAllUsers(): array { return self::arrayResult('getAllUsers'); }

    public static function blockUser(string $chatId, int $status): void
    {
        self::request('blockUser', ['chat_id'=>$chatId, 'status'=>$status ? 1 : 0], false);
        unset(self::$contexts[$chatId]);
    }

    public static function getUserByPhone(string $phone): ?array
    {
        $result = self::request('getUserByPhone', ['phone'=>$phone], null);
        return is_array($result) ? $result : null;
    }

    public static function resolveUserIdentifier(string $input): ?array
    {
        $result = self::request('resolveUserIdentifier', ['input'=>$input], null);
        return is_array($result) ? $result : null;
    }

    public static function isAdmin(string $chatId): bool
    {
        if ($chatId !== SiteClient::actorChatId()) return (bool)self::request('isAdmin', ['chat_id'=>$chatId], false);
        return !empty(self::getContext($chatId)['is_admin']);
    }

    public static function isOwner(string $chatId): bool
    {
        if ($chatId !== SiteClient::actorChatId()) return (bool)self::request('isOwner', ['chat_id'=>$chatId], false);
        return !empty(self::getContext($chatId)['is_owner']);
    }

    public static function addAdmin(string $chatId, string $addedBy, string $role = 'admin'): bool
    {
        $ok = (bool) self::request('addAdmin', ['chat_id'=>$chatId, 'added_by'=>$addedBy, 'role'=>$role], false);
        unset(self::$contexts[$chatId]);
        return $ok;
    }

    public static function getAllAdmins(): array { return self::arrayResult('getAllAdmins'); }

    public static function removeAdmin(string $chatId): bool
    {
        $ok = (bool) self::request('removeAdmin', ['chat_id'=>$chatId], false);
        unset(self::$contexts[$chatId]);
        return $ok;
    }

    public static function getSetting(string $key, string $default = ''): string
    {
        if ($key === 'bot_active' && SiteClient::actorChatId() !== '') {
            $context = self::getContext(SiteClient::actorChatId());
            if (array_key_exists('bot_active', $context)) return !empty($context['bot_active']) ? '1' : '0';
        }
        $value = self::request('getSetting', ['key'=>$key, 'default'=>$default], $default, true);
        return is_scalar($value) ? (string) $value : $default;
    }

    public static function setSetting(string $key, string $value): void
    {
        self::request('setSetting', ['key'=>$key, 'value'=>$value], false);
        self::$contexts = [];
    }

    public static function getPaymentMethod(): string { return (string) self::request('getPaymentMethod', [], 'card', true); }
    public static function setPaymentMethod(string $method): void { self::request('setPaymentMethod', ['method'=>$method], false); }
    public static function getPaymentCardNumber(): string { return (string) self::request('getPaymentCardNumber', [], '—', true); }
    public static function setPaymentCardNumber(string $number): void { self::request('setPaymentCardNumber', ['number'=>$number], false); }
    public static function getPaymentCardHolder(): string { return (string) self::request('getPaymentCardHolder', [], '', true); }
    public static function setPaymentCardHolder(string $holder): void { self::request('setPaymentCardHolder', ['holder'=>$holder], false); }

    public static function saveReceipt(int $enrollId, string $fileId): bool
    {
        return (bool) self::request('saveReceipt', ['enrollment_id'=>$enrollId, 'file_id'=>$fileId], false);
    }

    public static function getActiveCourses(): array { return self::arrayResult('getActiveCourses', [], true); }
    public static function coursePage(int $page=1): array { return self::arrayResult('coursePage',['page'=>max(1,$page)],true); }
    public static function getAllCourses(): array { return self::arrayResult('getAllCourses', [], true); }

    public static function getCourse(int $id): ?array
    {
        $result = self::request('getCourse', ['course_id'=>$id], null, true);
        return is_array($result) ? $result : null;
    }

    public static function updateCourseField(int $courseId, string $field, $value): bool
    {
        return (bool) self::request('updateCourseField', ['course_id'=>$courseId, 'field'=>$field, 'value'=>$value], false);
    }

    public static function toggleCourseActive(int $courseId): bool
    {
        return (bool) self::request('toggleCourseActive', ['course_id'=>$courseId], false);
    }

    public static function createCourse(
        string $title,
        string $desc,
        int $capacity,
        int $price,
        string $startDate,
        string $endDate,
        ?string $promoType = null,
        ?string $promoContent = null,
        ?string $promoCaption = null
    ): bool {
        return (bool) self::request('createCourse', [
            'title'=>$title, 'description'=>$desc, 'capacity'=>$capacity, 'price'=>$price,
            'start_date'=>$startDate, 'end_date'=>$endDate, 'promo_type'=>$promoType,
            'promo_content'=>$promoContent, 'promo_caption'=>$promoCaption,
        ], false);
    }

    public static function generateTrackingCode(string $prefix, string $table): string
    {
        return (string) self::request('generateTrackingCode', ['prefix'=>$prefix, 'scope'=>$table], '');
    }

    public static function getCourseEnrollCount(int $courseId): int
    {
        return (int) self::request('getCourseEnrollCount', ['course_id'=>$courseId], 0, true);
    }

    public static function deleteCourse(int $courseId): bool
    {
        return (bool) self::request('deleteCourse', ['course_id'=>$courseId], false);
    }

    public static function isUserEnrolled(int $userChatId, int $courseId, int $productId = 0): bool
    {
        return (bool) self::request('isUserEnrolled', ['user_chat_id'=>(string)$userChatId, 'course_id'=>$courseId, 'product_id'=>$productId], false, true);
    }

    public static function enrollUser(int $userId, int $courseId, int $productId = 0): string|false
    {
        $value = self::request('enrollUser', ['user_chat_id'=>(string)$userId, 'course_id'=>$courseId, 'product_id'=>$productId], false);
        return is_string($value) && $value !== '' ? $value : false;
    }

    public static function enrollUserPending(int $userChatId, int $courseId, int $productId = 0): string|false
    {
        $value = self::request('enrollUserPending', ['user_chat_id'=>(string)$userChatId, 'course_id'=>$courseId, 'product_id'=>$productId], false);
        return is_string($value) && $value !== '' ? $value : false;
    }

    public static function getEnrollmentByUserCourse(int $userId, int $courseId, int $productId = 0): ?array
    {
        $result = self::request('getEnrollmentByUserCourse', ['user_chat_id'=>(string)$userId, 'course_id'=>$courseId, 'product_id'=>$productId], null);
        return is_array($result) ? $result : null;
    }

    public static function getEnrollmentById(int $id): ?array
    {
        $result = self::request('getEnrollmentById', ['enrollment_id'=>$id], null);
        return is_array($result) ? $result : null;
    }

    public static function confirmEnrollment(int $userChatId, int $courseId, string $paymentId, int $productId = 0, int $orderId = 0, int $amountRial = 0): bool
    {
        return (bool) self::request('confirmEnrollment', ['user_chat_id'=>(string)$userChatId, 'course_id'=>$courseId, 'product_id'=>$productId, 'payment_id'=>$paymentId, 'enrollment_id'=>$orderId, 'amount_rial'=>$amountRial], false);
    }

    public static function confirmEnrollmentById(int $id, string $paymentId, int $amountRial = 0): bool
    {
        return (bool) self::request('confirmEnrollmentById', ['enrollment_id'=>$id, 'payment_id'=>$paymentId, 'amount_rial'=>$amountRial], false);
    }

    public static function getAllPayments(int $limit = 200): array { return self::arrayResult('getAllPayments', ['limit'=>$limit]); }
    public static function getEnrollments(int $courseId): array { return self::arrayResult('getEnrollments', ['course_id'=>$courseId]); }
    public static function getUserCourses(int $userChatId): array { return self::arrayResult('getUserCourses', ['user_chat_id'=>(string)$userChatId], true); }

    public static function issueCertificate(int $userChatId, ?int $courseId, string $title, string $issueDate, string $issuedBy, ?string $pdfFileId = null, int $attachmentId = 0): string|false
    {
        $value = self::request('issueCertificate', [
            'user_chat_id'=>(string)$userChatId, 'course_id'=>$courseId, 'title'=>$title,
            'issue_date'=>$issueDate, 'issued_by'=>$issuedBy, 'pdf_file_id'=>$pdfFileId, 'attachment_id'=>$attachmentId,
        ], false);
        return is_string($value) && $value !== '' ? $value : false;
    }

    public static function getCertificateById(int $id): ?array
    {
        $result = self::request('getCertificateById', ['certificate_id'=>$id], null);
        return is_array($result) ? $result : null;
    }

    public static function getUserCertificates(int $userChatId): array { return self::arrayResult('getUserCertificates', ['user_chat_id'=>(string)$userChatId], true); }

    public static function createAppointment(int $userId, string $date, string $timeSlot, string $desc): string|false
    {
        $value = self::request('createAppointment', ['user_chat_id'=>(string)$userId, 'date'=>$date, 'time_slot'=>$timeSlot, 'description'=>$desc], false);
        return is_string($value) && $value !== '' ? $value : false;
    }

    public static function getUserAppointments(int $userId): array { return self::arrayResult('getUserAppointments', ['user_chat_id'=>(string)$userId], true); }

    public static function getAppointmentById(int $id): ?array
    {
        $result = self::request('getAppointmentById', ['appointment_id'=>$id], null);
        return is_array($result) ? $result : null;
    }

    public static function cancelAppointment(int $id, int $userId): bool
    {
        return (bool) self::request('cancelAppointment', ['appointment_id'=>$id, 'user_chat_id'=>(string)$userId], false);
    }

    public static function getAllAppointments(int $limit = 200): array { return self::arrayResult('getAllAppointments', ['limit'=>$limit]); }
    public static function cleanupExpiredAppointments(): void { self::request('cleanupExpiredAppointments', [], false); }

    public static function createNews(string $title, string $content, string $adminId, string $type = 'news'): int
    {
        return (int) self::request('createNews', ['title'=>$title, 'content'=>$content, 'admin_chat_id'=>$adminId, 'type'=>$type], 0);
    }

    public static function getLatestNews(int $limit = 10): array { return self::arrayResult('getLatestNews', ['limit'=>$limit], true); }
    public static function getNewsByType(string $type, int $limit = 50): array { return self::arrayResult('getNewsByType', ['type'=>$type, 'limit'=>$limit], true); }
    public static function countNews(): int { return (int) self::request('countNews', [], 0, true); }

    public static function getNewsById(int $id): ?array
    {
        $result = self::request('getNewsById', ['news_id'=>$id], null, true);
        return is_array($result) ? $result : null;
    }

    public static function deleteNews(int $id): bool { return (bool) self::request('deleteNews', ['news_id'=>$id], false); }

    public static function saveMessage(int $userId, string $message, ?string $fileId = null, ?string $fileType = null): int
    {
        return (int) self::request('saveMessage', ['user_chat_id'=>(string)$userId, 'message'=>$message, 'file_id'=>$fileId, 'file_type'=>$fileType], 0);
    }

    public static function getUserMessageHistory(int $userId, int $limit = 10): array
    {
        return self::arrayResult('getUserMessageHistory', ['user_chat_id'=>(string)$userId, 'limit'=>$limit]);
    }

    public static function getMessageById(int $msgId): ?array
    {
        $result = self::request('getMessageById', ['message_id'=>$msgId], null);
        return is_array($result) ? $result : null;
    }

    public static function replyToMessage(int $msgId, string $reply, string $adminChatId): bool
    {
        return (bool) self::request('replyToMessage', ['message_id'=>$msgId, 'reply'=>$reply, 'admin_chat_id'=>$adminChatId], false);
    }

    public static function markMessageRead(int $msgId): void { self::request('markMessageRead', ['message_id'=>$msgId], false); }
    public static function getUnreadMessages(): array { return self::arrayResult('getUnreadMessages'); }
    public static function getAllMessages(int $limit = 20): array { return self::arrayResult('getAllMessages', ['limit'=>$limit]); }
    public static function getRepliedMessages(int $limit = 300): array { return self::arrayResult('getRepliedMessages', ['limit'=>$limit]); }
    public static function openOrCreateChat(int $userId): void { self::request('openOrCreateChat', ['user_chat_id'=>(string)$userId], false); }
    public static function closeChat(int $userId): void { self::request('closeChat', ['user_chat_id'=>(string)$userId], false); }
    public static function isChatOpen(int $userId): bool { return (bool) self::request('isChatOpen', ['user_chat_id'=>(string)$userId], true); }
    public static function getBookedSlotsForDay(string $day): array { return self::arrayResult('getBookedSlotsForDay', ['day'=>$day]); }

    public static function setActiveMode(string $chatId, string $mode): bool
    {
        $ok = (bool) self::request('setActiveMode', ['chat_id'=>$chatId, 'mode'=>$mode], false);
        unset(self::$contexts[$chatId]);
        return $ok;
    }

    public static function getPanelUrl(string $chatId, string $mode, string $panel): string
    {
        $context = self::getContext($chatId);
        foreach ((array) ($context['user']['menu_items'] ?? []) as $item) {
            if (($item['id'] ?? '') === $panel && !empty($item['url'])) return (string) $item['url'];
        }
        return (string) ($context['account_url'] ?? '');
    }

    // وضعیت مکالمه نیز در همان دیتابیس وردپرس نگهداری می‌شود.
    public static function stateGet(string $chatId): array
    {
        $result = self::request('stateGet', ['chat_id'=>$chatId], ['step'=>null, 'data'=>[]]);
        return is_array($result) ? $result : ['step'=>null, 'data'=>[]];
    }
    public static function stateSet(string $chatId, string $step, array $data = []): bool { return (bool) self::request('stateSet', ['chat_id'=>$chatId, 'step'=>$step, 'data'=>$data], false); }
    public static function stateClear(string $chatId): bool { return (bool) self::request('stateClear', ['chat_id'=>$chatId], false); }
    public static function stateAll(): array { return self::arrayResult('stateAll'); }
    /** Unlinked chat IDs with a stale reg_* step (needs plugin 28.0.1+; [] on older). */
    public static function abandonedRegistrations(int $olderThanMinutes = 10): array { return self::arrayResult('abandonedRegistrations', ['minutes'=>$olderThanMinutes]); }
    public static function pendingPush(): array { return self::arrayResult('pendingPush'); }
    public static function ackPush(array $sent, array $failed): int { return (int) self::request('ackPush', ['sent'=>array_values(array_map('intval',$sent)), 'failed'=>array_values(array_map('intval',$failed))], 0); }
    public static function ticketLatestReply(string $chatId, int $ticketId): ?array { $r = self::request('ticketLatestReply', ['chat_id'=>$chatId, 'ticket_id'=>$ticketId], null); return is_array($r) ? $r : null; }
    public static function ticketMessageFile(string $chatId, int $ticketId, int $attachmentId): ?array { $r = self::request('ticketMessageFile', ['chat_id'=>$chatId, 'ticket_id'=>$ticketId, 'attachment_id'=>$attachmentId], null); return is_array($r) ? $r : null; }
    public static function ticketMarkUserRead(string $chatId, int $ticketId): bool { return (bool) self::request('ticketMarkUserRead', ['chat_id'=>$chatId, 'ticket_id'=>$ticketId], false); }
    public static function stateMarkReminded(string $chatId): bool { return (bool) self::request('stateMarkReminded', ['chat_id'=>$chatId], false); }

    /** true=جدید، false=تکراری، null=ارتباط سایت ناموفق */
    public static function claimUpdate(string $chatId, string $updateId): ?bool
    {
        $value = self::request('claimUpdate', ['chat_id'=>$chatId, 'update_id'=>$updateId], null);
        return $value === null ? null : (bool) $value;
    }

    private static function arrayResult(string $method, array $params = [], bool $cache = false): array
    {
        $result = self::request($method, $params, [], $cache);
        return is_array($result) ? $result : [];
    }

    private static function request(string $method, array $params, $default, bool $cache = false)
    {
        $attempt = 0;
        while (true) {
            try {
                self::$lastError = null;
                return SiteClient::call($method, $params, $cache);
            } catch (SiteSyncException $error) {
                self::$lastError = ['method'=>$method, 'code'=>$error->getRemoteCode(), 'status'=>$error->getStatus(), 'message'=>$error->getMessage()];
                error_log('[BaleBazo Site Sync] ' . $method . ': ' . $error->getRemoteCode());
                // Same signed params (same receipt key): a twin request usually commits
                // its receipt during this pause, so one patient retry often succeeds.
                if ($error->getRemoteCode() === 'operation_uncertain' && $attempt < 1) {
                    $attempt++;
                    sleep(2);
                    continue;
                }
                if ($error->getStatus() === 0 || $error->getStatus() >= 500 || in_array($error->getStatus(),[408,429],true)
                    || in_array($error->getRemoteCode(),['lease_lost','operation_uncertain','invalid_json'],true)) {
                    self::$retryError = self::$lastError;
                    throw $error;
                }
                return $default;
            }
        }
    }
}
