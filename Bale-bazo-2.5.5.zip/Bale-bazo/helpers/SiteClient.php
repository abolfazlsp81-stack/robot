<?php
// helpers/SiteClient.php
// ارتباط امضاشده ربات با افزونه Modern Profile Hub روی وردپرس.

declare(strict_types=1);

final class SiteSyncException extends RuntimeException
{
    private int $status;
    private string $remoteCode;

    public function __construct(string $message, int $status = 0, string $remoteCode = 'site_sync_error')
    {
        parent::__construct($message);
        $this->status = $status;
        $this->remoteCode = $remoteCode;
    }

    public function getStatus(): int
    {
        return $this->status;
    }

    public function getRemoteCode(): string
    {
        return $this->remoteCode;
    }
}

final class SiteClient
{
    private static array $config = [];
    private static string $actorChatId = '';
    private static array $requestCache = [];
    private static $connection = null;
    private static string $jobId = '';
    private static string $jobToken = '';
    private static int $lastHeartbeat = 0;

    public static function setJob(string $id, string $token): void { self::$jobId=$id; self::$jobToken=$token; self::$lastHeartbeat=time(); }
    public static function heartbeat(): void {
        if(self::$jobId==='' || time()-self::$lastHeartbeat<60)return;
        self::call('heartbeatUpdate',['update_id'=>self::$jobId,'token'=>self::$jobToken]);
        self::$lastHeartbeat=time();
    }

    public static function configure(array $config): void
    {
        self::$config = $config;
        self::$requestCache = [];
    }

    public static function setActorChatId(string $chatId): void
    {
        if (self::$actorChatId !== trim($chatId)) self::$requestCache = [];
        if (self::$actorChatId !== trim($chatId)) self::setJob('', '');
        self::$actorChatId = trim($chatId);
    }

    public static function actorChatId(): string
    {
        return self::$actorChatId;
    }

    public static function isConfigured(): bool
    {
        return self::baseUrl() !== '' && strlen(self::secret()) >= 32;
    }

    public static function call(string $method, array $params = [], bool $cache = false)
    {
        $cache = $cache || in_array($method,['getSetting','getPaymentMethod','getPaymentCardNumber','getPaymentCardHolder','isAdmin','isOwner','getUser','getCourse','getActiveCourses','getAllCourses','getUserCertificates','getBookedSlotsForDay','coursePage'],true);
        // Mutations invalidate data already read during this webhook request.
        if (!$cache) self::$requestCache = [];
        if (!self::isConfigured()) {
            throw new SiteSyncException('نشانی سایت یا کلید همگام‌سازی تنظیم نشده است.', 0, 'not_configured');
        }

        $params['_actor_chat_id'] = self::$actorChatId;
        if (self::$jobId !== '' && !in_array($method,['beginUpdate','finishUpdate','pendingUpdates','runtimeDiagnostics','heartbeatUpdate'],true)) {
            $params['_job_id'] = self::$jobId;
            $params['_job_token'] = self::$jobToken;
        }
        $cacheKey = $method . ':' . hash('sha256', self::json($params));
        if ($cache && array_key_exists($cacheKey, self::$requestCache)) {
            return self::$requestCache[$cacheKey];
        }

        $body = self::json([
            'method' => $method,
            'params' => $params,
            'client' => [
                'name' => 'bale-bazo',
                'version' => defined('BALE_BAZO_VERSION') ? BALE_BAZO_VERSION : '2.0.0',
            ],
        ]);
        $timestamp = (string) time();
        $nonce = bin2hex(random_bytes(16));
        $signature = hash_hmac('sha256', $timestamp . "\n" . $nonce . "\n" . hash('sha256', $body), self::secret());

        if (self::$connection === null) self::$connection = curl_init();
        $ch = self::$connection;
        if ($ch === false) {
            throw new SiteSyncException('امکان آغاز ارتباط با سایت وجود ندارد.', 0, 'curl_init');
        }
        curl_setopt_array($ch, [
            CURLOPT_URL => self::baseUrl() . '/wp-json/mph-bale/v1/rpc',
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => max(2, (int) (self::$config['site_connect_timeout'] ?? 5)),
            CURLOPT_TIMEOUT => max(2, (int) (self::$config['site_timeout'] ?? 20)),
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json; charset=utf-8',
                'Accept: application/json',
                'X-MPH-Timestamp: ' . $timestamp,
                'X-MPH-Nonce: ' . $nonce,
                'X-MPH-Signature: ' . $signature,
            ],
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_ENCODING => '',
            CURLOPT_FRESH_CONNECT => false,
            CURLOPT_FORBID_REUSE => false,
            CURLOPT_TCP_KEEPALIVE => 1,
            CURLOPT_USERAGENT => 'BaleBazo/' . (defined('BALE_BAZO_VERSION') ? BALE_BAZO_VERSION : '2.0.0'),
        ]);

        $raw = curl_exec($ch);
        $curlError = curl_error($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $elapsed=(int)round((float)curl_getinfo($ch,CURLINFO_TOTAL_TIME)*1000);
        if($elapsed>=1500)error_log('[BaleBazo timing] method='.$method.' elapsed_ms='.$elapsed.' status='.$status);

        if ($raw === false || $curlError !== '') {
            throw new SiteSyncException('ارتباط امن با سایت برقرار نشد.', $status, 'network_error');
        }
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            throw new SiteSyncException('پاسخ سایت معتبر نیست.', $status, 'invalid_json');
        }
        if ($status < 200 || $status >= 300 || empty($decoded['success'])) {
            $error = is_array($decoded['error'] ?? null) ? $decoded['error'] : [];
            // خطاهای permission_callback وردپرس بیرون از envelope اختصاصی
            // و با ساختار استاندارد code/message/data برمی‌گردند.
            $message = trim((string) ($error['message'] ?? $decoded['message'] ?? 'درخواست همگام‌سازی توسط سایت رد شد.'));
            $code = trim((string) ($error['code'] ?? $decoded['code'] ?? 'remote_error'));
            $trace=preg_replace('/[^a-zA-Z0-9-]/','',(string)($decoded['request_id']??''));
            throw new SiteSyncException($message.($trace!==''?' — پیگیری: '.$trace:''), $status, $code);
        }

        $data = $decoded['data'] ?? null;
        if ($cache) {
            self::$requestCache[$cacheKey] = $data;
        }
        return $data;
    }

    public static function health(): array
    {
        $result = self::call('health', [], false);
        return is_array($result) ? $result : [];
    }

    /** فایل دانلودشده از بله را با بدنه باینری امضاشده به وردپرس می‌فرستد. */
    public static function uploadFile(string $localPath, array $metadata): array
    {
        if (!self::isConfigured() || !is_file($localPath) || !is_readable($localPath)) {
            throw new SiteSyncException('فایل محلی یا اتصال سایت معتبر نیست.', 0, 'asset_not_ready');
        }
        $size = (int)filesize($localPath);
        if ($size < 1 || $size > 20 * 1024 * 1024) {
            throw new SiteSyncException('اندازه فایل برای انتقال مجاز نیست.', 0, 'asset_size');
        }
        $body = file_get_contents($localPath);
        if (!is_string($body) || strlen($body) !== $size) {
            throw new SiteSyncException('خواندن فایل برای انتقال ممکن نبود.', 0, 'asset_read');
        }

        $metadata['actor_chat_id'] = self::$actorChatId;
        if (self::$jobId !== '') { $metadata['_job_id']=self::$jobId; $metadata['_job_token']=self::$jobToken; }
        $metaHeader = base64_encode(self::json($metadata));
        $timestamp = (string)time();
        $nonce = bin2hex(random_bytes(16));
        $canonical = $timestamp . "\n" . $nonce . "\n" . hash('sha256', $body) . "\n" . $metaHeader;
        $signature = hash_hmac('sha256', $canonical, self::secret());

        if (self::$connection === null) self::$connection = curl_init();
        $ch = self::$connection;
        if ($ch === false) throw new SiteSyncException('امکان آغاز انتقال فایل وجود ندارد.', 0, 'curl_init');
        curl_reset($ch);
        curl_setopt_array($ch, [
            CURLOPT_URL => self::baseUrl() . '/wp-json/mph-bale/v1/asset',
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => max(2, (int)(self::$config['site_connect_timeout'] ?? 5)),
            CURLOPT_TIMEOUT => max(20, (int)(self::$config['site_upload_timeout'] ?? 90)),
            CURLOPT_FRESH_CONNECT => false,
            CURLOPT_FORBID_REUSE => false,
            CURLOPT_TCP_KEEPALIVE => 1,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/octet-stream',
                'Expect:',
                'Accept: application/json',
                'X-MPH-Timestamp: ' . $timestamp,
                'X-MPH-Nonce: ' . $nonce,
                'X-MPH-Signature: ' . $signature,
                'X-MPH-Meta: ' . $metaHeader,
            ],
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_ENCODING => '',
            CURLOPT_USERAGENT => 'BaleBazo/' . (defined('BALE_BAZO_VERSION') ? BALE_BAZO_VERSION : '2.0.0'),
        ]);
        $started = microtime(true);
        $raw = curl_exec($ch);
        $curlError = curl_error($ch);
        $curlErrno = curl_errno($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $elapsed = (int)round((microtime(true) - $started) * 1000);
        unset($body);
        if ($raw === false || $curlError !== '') { error_log('[BaleBazo Media Sync] upload_network: errno=' . $curlErrno . ' status=' . $status . ' size=' . $size . ' elapsed_ms=' . $elapsed . ' err=' . substr($curlError, 0, 160)); throw new SiteSyncException('انتقال امن فایل به سایت انجام نشد.', $status, 'asset_network'); }
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) throw new SiteSyncException('پاسخ انتقال فایل معتبر نیست.', $status, 'invalid_json');
        if ($status < 200 || $status >= 300 || empty($decoded['success'])) {
            $error = is_array($decoded['error'] ?? null) ? $decoded['error'] : [];
            throw new SiteSyncException((string)($error['message'] ?? $decoded['message'] ?? 'انتقال فایل توسط سایت رد شد.'), $status, (string)($error['code'] ?? $decoded['code'] ?? 'asset_remote_error'));
        }
        return is_array($decoded['data'] ?? null) ? $decoded['data'] : [];
    }

    private static function baseUrl(): string
    {
        $url = rtrim(trim((string) (self::$config['site_url'] ?? '')), '/');
        if ($url === '') {
            return '';
        }
        $scheme = strtolower((string) parse_url($url, PHP_URL_SCHEME));
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        $local = in_array($host, ['localhost', '127.0.0.1', '::1'], true);
        if ($scheme !== 'https' && !$local) {
            throw new SiteSyncException('نشانی سایت برای همگام‌سازی باید HTTPS باشد.', 0, 'https_required');
        }
        return $url;
    }

    private static function secret(): string
    {
        return trim((string) (self::$config['site_sync_secret'] ?? ''));
    }

    private static function json(array $value): string
    {
        $json = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) {
            throw new SiteSyncException('ساخت داده درخواست ممکن نبود.', 0, 'json_encode');
        }
        return $json;
    }
}
