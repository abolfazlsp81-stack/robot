<?php
// helpers/StateManager.php
// وضعیت گفت‌وگو از طریق پل امن در دیتابیس وردپرس نگهداری می‌شود.

declare(strict_types=1);

final class StateManager
{
    private static array $cache = [];

    public static function seed(string $chatId, array $state): void { self::$cache[$chatId]=$state; }

    public static function init(string $unusedDirectory = ''): void
    {
        self::$cache = [];
    }

    public static function get(string $chatId): array
    {
        if (!isset(self::$cache[$chatId])) {
            $state = Database::stateGet($chatId);
            self::$cache[$chatId] = [
                'step' => isset($state['step']) && $state['step'] !== '' ? (string) $state['step'] : null,
                'data' => is_array($state['data'] ?? null) ? $state['data'] : [],
                'updated_at' => isset($state['updated_at']) ? (int) $state['updated_at'] : null,
                'reminded' => !empty($state['reminded']),
            ];
        }
        return self::$cache[$chatId];
    }

    public static function set(string $chatId, string $step, array $data = []): void
    {
        $current = self::get($chatId);
        $current['step'] = $step;
        $current['data'] = array_merge((array) ($current['data'] ?? []), $data);
        $current['updated_at'] = time();
        $current['reminded'] = false;
        if (Database::stateSet($chatId, $step, $current['data'])) {
            self::$cache[$chatId] = $current;
        }
    }

    public static function clear(string $chatId): void
    {
        Database::stateClear($chatId);
        unset(self::$cache[$chatId]);
    }

    public static function getStep(string $chatId): ?string
    {
        return self::get($chatId)['step'] ?? null;
    }

    public static function getData(string $chatId): array
    {
        return (array) (self::get($chatId)['data'] ?? []);
    }

    public static function getAll(): array
    {
        return Database::stateAll();
    }

    public static function getUpdatedAt(string $chatId): ?int
    {
        $value = self::get($chatId)['updated_at'] ?? null;
        return $value === null ? null : (int) $value;
    }

    public static function markReminded(string $chatId): void
    {
        if (Database::stateMarkReminded($chatId)) {
            $state = self::get($chatId);
            $state['reminded'] = true;
            self::$cache[$chatId] = $state;
        }
    }

    public static function isReminded(string $chatId): bool
    {
        return !empty(self::get($chatId)['reminded']);
    }
}
