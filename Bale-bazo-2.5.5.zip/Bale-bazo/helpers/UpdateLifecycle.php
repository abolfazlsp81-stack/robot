<?php
declare(strict_types=1);

/** Complete only after handlers finish; shutdown also records fatal or transport failures. */
final class UpdateLifecycle {
    private static ?array $job = null;
    private static string $failure = '';

    public static function fail(string $code): void { self::$failure=$code; }
    public static function clear(): void { self::$failure=''; }
    public static function attach(string $id, string $token): void {
        self::$job=['id'=>$id,'token'=>$token];
        register_shutdown_function([self::class,'finish']);
    }
    public static function finish(): void {
        if (self::$job===null) return;
        $last=error_get_last();
        $fatal=$last && in_array($last['type'],[E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR,E_USER_ERROR],true);
        $error=Database::retryError();
        $failed=$fatal || self::$failure!=='' || $error || http_response_code()>=500;
        $code=self::$failure ?: (string)($error['code']??($fatal?'php_error':'processing_failed'));
        try {
            $result=SiteClient::call('finishUpdate',['update_id'=>self::$job['id'],'token'=>self::$job['token'],'success'=>!$failed,'error_code'=>$failed?$code:'']);
            // A review item is persisted for the operator; retrying it automatically is unsafe.
            if (($result['status']??'')==='review') {
                error_log('[BaleBazo] update_review_required id='.self::$job['id']);
                http_response_code(200);
            } elseif ($failed) http_response_code(503);
        } catch (Throwable $e) {
            error_log('[BaleBazo] finish_pending id='.self::$job['id']);
            http_response_code(503);
        }
        self::$job=null;
    }
}
