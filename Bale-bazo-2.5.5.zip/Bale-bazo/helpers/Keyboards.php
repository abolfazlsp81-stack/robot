<?php
// helpers/Keyboards.php

class Keyboards
{
    // ───── تنظیمات قابل‌پیکربندی (نوبت‌دهی) ────────────────────────
    private static array $config = [];
    private static array $userContext = [];
    private static array $siteSelections = [];

    // باید یک‌بار در ابتدای اجرا (index.php) فراخوانی شود
    public static function configure(array $config): void
    {
        self::$config = $config;
    }

    public static function setUserContext(array $user): void
    {
        self::$userContext = $user;
        self::$siteSelections = [];
    }

    /** اطلاعات انتخاب‌شده را مستقل از عنوان قابل‌تغییر سایت برمی‌گرداند. */
    public static function resolveSiteSelection(string $text): ?array
    {
        if (in_array(trim($text), ['🎭 نقش‌ها', 'نقش‌ها', 'نقش ها'], true)) return ['type'=>'roles'];
        self::siteMain();
        return self::$siteSelections[trim($text)] ?? null;
    }

    public static function rolesMenu(): array
    {
        $rows = [];
        $active = (string)(self::$userContext['active_mode'] ?? 'user');
        foreach ((array)(self::$userContext['modes'] ?? []) as $mode) {
            $id = (string)($mode['id'] ?? '');
            if (!in_array($id, ['user','instructor','therapist','manager'], true)) continue;
            $title = trim((string)($mode['title'] ?? $id));
            $emoji = trim((string)($mode['emoji'] ?? '')) ?: self::roleEmoji($id);
            $rows[] = [['text'=>($active === $id ? '✅ ' : '').$emoji.' '.$title, 'callback_data'=>'site_role_'.$id]];
        }
        $rows[] = [['text'=>'🔙 بازگشت به منوی اصلی', 'callback_data'=>'back_main']];
        return $rows;
    }

    // ساعت‌های قابل رزرو (پیش‌فرض اگر در config.php تنظیم نشده باشد)
    public static function getAllSlots(): array
    {
        return self::$config['appointment_slots'] ?? [
            '۹:۰۰', '۱۰:۰۰', '۱۱:۰۰', '۱۲:۰۰', '۱۴:۰۰', '۱۵:۰۰', '۱۶:۰۰', '۱۷:۰۰', '۱۸:۰۰', '۱۹:۰۰',
        ];
    }

    // روزهای تعطیل هفته (پیش‌فرض: فقط جمعه). شاخص‌ها بر اساس date('w'): ۰=یکشنبه ... ۶=شنبه
    public static function getClosedWeekdays(): array
    {
        return self::$config['appointment_closed_weekdays'] ?? [5];
    }

    // ───── منوی کاربر عادی ────────────────────────────────────────
    public static function userMain(): array
    {
        $menu = self::siteMain();
        if ($menu) return $menu;
        return [
            [['text'=>'🎭 نقش‌ها']],
            [['text'=>'📚 ثبت‌نام دوره'], ['text'=>'📢 اخبار و اطلاعیه‌ها']],
            [['text'=>'🆘 تیکت پشتیبانی'], ['text'=>'📅 رزرو نوبت']],
            [['text'=>'📚 دوره‌های من'], ['text'=>'🎓 گواهینامه‌های من']],
            [['text'=>'🕒 نوبت‌های من'], ['text'=>'👤 پروفایل من']],
        ];
    }

    // ───── منوی ادمین ─────────────────────────────────────────────
    public static function adminMain(bool $isOwner = false): array
    {
        $menu = self::userMain();
        $menu[] = [['text'=>'⚙️ ابزارهای مدیریت ربات']];
        // نگاشت قدیمی برای پیام‌های قبلی همچنان معتبر است.
        self::$siteSelections['⚙️ ابزارهای مدیریت ربات'] = ['type'=>'bot_admin'];
        return $menu;
    }

    private static function siteMain(): array
    {
        $user = self::$userContext;
        $items = is_array($user['menu_items'] ?? null) ? $user['menu_items'] : [];
        if (!$items) return [];

        self::$siteSelections = [];
        $buttons = [[['text'=>'🎭 نقش‌ها']]];
        $modes = is_array($user['modes'] ?? null) ? $user['modes'] : [];
        $activeMode = (string) ($user['active_mode'] ?? 'user');
        if (count($modes) > 1) {
            $roleRow = [];
            foreach ($modes as $mode) {
                $key = (string) ($mode['id'] ?? '');
                if ($key === '') continue;
                $label = ($key === $activeMode ? '✅ ' : '') . (trim((string)($mode['emoji'] ?? '')) ?: self::roleEmoji($key)) . ' ' . (string) ($mode['title'] ?? $key);
                $roleRow[] = ['text'=>$label];
                self::$siteSelections[$label] = ['type'=>'role', 'mode'=>$key];
                if (count($roleRow) === 2) {
                    $roleRow = [];
                }
            }
            // Keep old role labels resolvable, but show roles only in their submenu.
        }

        $row = [];
        foreach ($items as $item) {
            $id = trim((string) ($item['id'] ?? ''));
            $title = trim((string) ($item['title'] ?? ''));
            if ($id === '' || $title === '') continue;
            $emoji = trim((string) ($item['emoji'] ?? '')) ?: self::dashiconEmoji((string) ($item['sidebar_icon'] ?? ''));
            $label = trim($emoji . ' ' . self::truncate($title, 34));
            $row[] = ['text'=>$label];
            self::$siteSelections[$label] = [
                'type'=>'panel',
                'id'=>$id,
                'mode'=>(string) ($item['mode'] ?? $activeMode),
                'title'=>$title,
                'hint'=>(string) ($item['hint'] ?? ''),
                'url'=>(string) ($item['url'] ?? ''),
            ];
            if (count($row) === 2) {
                $buttons[] = $row;
                $row = [];
            }
        }
        if ($row) $buttons[] = $row;
        return $buttons;
    }

    private static function roleEmoji(string $mode): string
    {
        return ['user'=>'👤', 'instructor'=>'👨‍🏫', 'therapist'=>'🩺', 'manager'=>'🛡️'][$mode] ?? '👤';
    }

    private static function dashiconEmoji(string $icon): string
    {
        $map = [
            'dashboard'=>'🏠', 'chart-area'=>'📊', 'chart-pie'=>'📊', 'chart-bar'=>'📈',
            'admin-users'=>'👤', 'groups'=>'👥', 'businessperson'=>'👨‍🏫', 'id'=>'🪪',
            'welcome-learn-more'=>'📚', 'playlist-video'=>'🎬', 'video-alt3'=>'🎥',
            'awards'=>'🎓', 'clipboard'=>'📋', 'editor-help'=>'📝', 'heart'=>'❤️',
            'cart'=>'🛒', 'list-view'=>'📜', 'calendar-alt'=>'📅', 'clock'=>'🕒',
            'money-alt'=>'💳', 'admin-generic'=>'⚙️', 'admin-settings'=>'⚙️',
            'yes-alt'=>'✅', 'tickets-alt'=>'🎟️', 'email-alt'=>'✉️', 'megaphone'=>'📢',
            'sos'=>'🆘', 'admin-links'=>'🔗', 'database-export'=>'💾',
        ];
        $key = preg_replace('/^dashicons-/', '', trim($icon));
        return $map[$key] ?? '🔹';
    }

    // ───── پنل مدیریت ─────────────────────────────────────────────
    // فقط ابزارهای مدیریت خود ربات؛ کنترل دسترسی همچنان در سایت انجام می‌شود.
    public static function adminPanel(bool $isOwner = false, bool $botActive = true): array
    {
        $toggle = $botActive ? '🔴 خاموش کردن ربات' : '🟢 روشن کردن ربات';
        $kb = [
            [['text' => $toggle]],
            [['text' => '➕ افزودن ادمین'], ['text' => '➖ حذف ادمین']],
            [['text' => '🔙 بازگشت']],
        ];
        return $kb;
    }

    // ───── منوی تنظیمات پرداخت ─────────────────────────────────────
    public static function paymentSettingsMenu(string $method): array
    {
        $nextLabel = match ($method) {
            'card' => '🔁 تغییر به درگاه آنلاین بله',
            'bale' => '🔁 تغییر به «هر دو روش»',
            default => '🔁 تغییر به کارت‌به‌کارت',
        };
        return [
            [
                ['text' => $nextLabel, 'callback_data' => 'paysettings_toggle_method'],
            ],
            [
                ['text' => '✏️ تغییر شماره کارت', 'callback_data' => 'paysettings_edit_card'],
            ],
        ];
    }

    // ───── انتخاب روش پرداخت توسط کاربر (وقتی هر دو روش فعال است) ────
    public static function paymentMethodChoice(int $courseId, int $productId = 0): array
    {
        $suffix = $productId > 0 ? "_{$productId}" : '';
        return [
            [['text' => '🏦 پرداخت آنلاین (بله)', 'callback_data' => "pay_choose_bale_{$courseId}{$suffix}"]],
            [['text' => '💳 کارت به کارت',         'callback_data' => "pay_choose_card_{$courseId}{$suffix}"]],
        ];
    }

    // ───── لیست دوره‌ها برای انتخاب توسط ادمین ──────────────────────
    public static function courseAdminList(array $courses): array
    {
        $buttons = [];
        foreach ($courses as $c) {
            $status = $c['is_active'] ? '✅' : '❌';
            $label  = "{$status} {$c['title']}";
            $buttons[] = [['text' => $label, 'callback_data' => "cadmin_select_{$c['id']}"]];
        }
        return $buttons;
    }

    // ───── دکمه‌های جزئیات یک دوره (بعد از انتخاب از لیست) ──────────
    public static function courseAdminDetail(int $courseId): array
    {
        return [
            [
                ['text' => '👥 ثبت‌نامی‌های این دوره', 'callback_data' => "course_enrolls_{$courseId}"],
                ['text' => '✏️ ویرایش دوره',          'callback_data' => "cedit_menu_{$courseId}"],
            ],
            [
                ['text' => '🔄 فعال/غیرفعال کردن', 'callback_data' => "cedit_toggle_{$courseId}"],
                ['text' => '🗑 حذف دوره',           'callback_data' => "delcourse_confirm_{$courseId}"],
            ],
            [
                ['text' => '🔙 بازگشت به لیست دوره‌ها', 'callback_data' => 'cadmin_list'],
            ],
        ];
    }

    // ───── دکمه‌های مدیریت هر دوره (قدیمی - دیگر استفاده نمی‌شود) ────
    public static function courseAdminActions(int $courseId): array
    {
        return [
            [
                ['text' => '👥 ثبت‌نامی‌های این دوره', 'callback_data' => "course_enrolls_{$courseId}"],
                ['text' => '✏️ ویرایش دوره',          'callback_data' => "cedit_menu_{$courseId}"],
            ],
        ];
    }

    // ───── منوی ویرایش فیلدهای یک دوره ──────────────────────────────
    public static function courseEditMenu(int $courseId): array
    {
        return [
            [
                ['text' => '📖 عنوان',   'callback_data' => "cedit_title_{$courseId}"],
                ['text' => '📝 توضیحات', 'callback_data' => "cedit_desc_{$courseId}"],
            ],
            [
                ['text' => '👥 ظرفیت', 'callback_data' => "cedit_cap_{$courseId}"],
                ['text' => '💰 قیمت',  'callback_data' => "cedit_price_{$courseId}"],
            ],
            [
                ['text' => '📅 تاریخ شروع', 'callback_data' => "cedit_start_{$courseId}"],
                ['text' => '📅 تاریخ پایان', 'callback_data' => "cedit_end_{$courseId}"],
            ],
            [
                ['text' => '📣 پیام تبلیغاتی', 'callback_data' => "cedit_promo_{$courseId}"],
            ],
            [
                ['text' => '🔄 فعال/غیرفعال کردن', 'callback_data' => "cedit_toggle_{$courseId}"],
            ],
            [
                ['text' => '🔙 بازگشت', 'callback_data' => "cadmin_select_{$courseId}"],
            ],
        ];
    }
    public static function receiptStartButton(int $enrollId): array
    {
        return [[['text' => '✅ واریز کردم، ارسال رسید', 'callback_data' => "receipt_start_{$enrollId}"]]];
    }

    // ───── دکمه نمایش عکس رسید برای ادمین ───────────────────────────
    public static function receiptViewButton(int $enrollId): array
    {
        return [[['text' => '🧾 مشاهده رسید', 'callback_data' => "view_receipt_{$enrollId}"]]];
    }

    // ───── کیبورد لغو ─────────────────────────────────────────────
    public static function cancelOnly(): array
    {
        return [[['text' => '❌ لغو']]];
    }

    // ───── کیبورد بازگشت به مرحله قبل + لغو ──────────────────────
    public static function backCancel(): array
    {
        return [
            [['text' => '⬅️ مرحله قبل']],
            [['text' => '❌ لغو']],
        ];
    }

    // ───── کیبورد رد شدن / بازگشت / لغو ────────────────────────────
    public static function skipBackCancel(string $skipLabel = '⏭ رد شدن'): array
    {
        return [
            [['text' => $skipLabel]],
            [['text' => '⬅️ مرحله قبل']],
            [['text' => '❌ لغو']],
        ];
    }

    // ───── کیبورد رد شدن / لغو ─────────────────────────────────────
    public static function skipOrCancel(string $skipLabel = '⏭ رد شدن'): array
    {
        return [
            [['text' => $skipLabel]],
            [['text' => '❌ لغو']],
        ];
    }

    // ───── کیبورد حذف / لغو (برای ویرایش پیام تبلیغاتی دوره) ────────
    public static function removeOrCancel(): array
    {
        return [
            [['text' => '🗑 حذف پیام تبلیغاتی']],
            [['text' => '❌ لغو']],
        ];
    }

    // ───── کیبورد انتخاب مقطع تحصیلی ────────────────────────────────
    public static function educationLevels(bool $showBack = false): array
    {
        $kb = [
            [['text' => 'دیپلم'],          ['text' => 'کاردانی']],
            [['text' => 'کارشناسی'],       ['text' => 'کارشناسی ارشد']],
            [['text' => 'دکتری']],
        ];
        if ($showBack) {
            $kb[] = [['text' => '⬅️ مرحله قبل']];
        }
        $kb[] = [['text' => '❌ لغو']];
        return $kb;
    }

    /** دکمه رسمی بله برای ارسال شماره متعلق به خود کاربر. */
    public static function ownContact(): array
    {
        return [
            'keyboard' => [
                [['text'=>'📱 تأیید شماره من', 'request_contact'=>true]],
                [['text'=>'❌ لغو']],
            ],
            'resize_keyboard' => true,
            'one_time_keyboard' => true,
        ];
    }

    // ───── Inline: پروفایل ────────────────────────────────────────
    public static function profileView(): array
    {
        return [
            [
                ['text' => '✏️ ویرایش اطلاعات', 'callback_data' => 'edit_profile'],
            ],
        ];
    }

    // ───── Inline: انتخاب فیلد ویرایش ────────────────────────────
    public static function profileEditFields(): array
    {
        return [
            [
                ['text' => '👤 نام',              'callback_data' => 'edit_field_first_name'],
                ['text' => '👤 نام‌خانوادگی',       'callback_data' => 'edit_field_last_name'],
            ],
            [
                ['text' => '🌍 نام به انگلیسی',      'callback_data' => 'edit_field_first_name_en'],
                ['text' => '🌍 نام‌خانوادگی به انگلیسی', 'callback_data' => 'edit_field_last_name_en'],
            ],
            [
                ['text' => '📞 شماره تلفن',         'callback_data' => 'edit_field_phone'],
                ['text' => '🪪 کد ملی',             'callback_data' => 'edit_field_id_card'],
            ],
            [
                ['text' => '🎂 تاریخ تولد',          'callback_data' => 'edit_field_birthday'],
                ['text' => '🏠 آدرس',               'callback_data' => 'edit_field_address'],
            ],
            [
                ['text' => '🎓 رشته تحصیلی',         'callback_data' => 'edit_field_field_of_study'],
                ['text' => '📚 مقطع تحصیلی',         'callback_data' => 'edit_field_education_level'],
            ],
            [
                ['text' => '📧 ایمیل',               'callback_data' => 'edit_field_email'],
                ['text' => '🖼 عکس پروفایل',        'callback_data' => 'edit_field_photo'],
            ],
            [
                ['text' => '⬅️ برگشت به پروفایل',    'callback_data' => 'show_profile'],
            ],
        ];
    }

    // ───── Inline: لیست دوره‌ها ───────────────────────────────────
    public static function courseList(array $courses): array
    {
        $buttons = [];
        foreach ($courses as $c) {
            $price = (int)($c['price'] ?? 0);
            $label = "📖 {$c['title']}" . ($price > 0 ? " — " . number_format($price) . " ت" : " — رایگان");
            $buttons[] = [['text' => $label, 'callback_data' => "course_{$c['id']}"]];
        }
        $buttons[] = [['text' => '🔙 بازگشت', 'callback_data' => 'back_main']];
        return $buttons;
    }

    // ───── Inline: جزئیات دوره ────────────────────────────────────
    public static function courseDetail(array $course, bool $enrolled, bool $full): array
    {
        $buttons = [];
        $modes = is_array($course['delivery_modes'] ?? null) ? $course['delivery_modes'] : [];
        if ($modes) {
            foreach ($modes as $mode) {
                $productId = (int)($mode['product_id'] ?? 0);
                if ($productId <= 0) continue;
                $key = (string)($mode['mode'] ?? '');
                $icon = ['offline'=>'🎬', 'online'=>'💻', 'inperson'=>'📍'][$key] ?? '📦';
                $label = trim((string)($mode['label'] ?? '')) ?: (['offline'=>'آفلاین', 'online'=>'آنلاین', 'inperson'=>'حضوری'][$key] ?? 'شیوه دوره');
                $price = (int)round((float)($mode['price'] ?? 0));
                $priceLabel = $price > 0 ? number_format($price) . ' تومان' : 'رایگان';
                if (!empty($mode['full'])) {
                    $buttons[] = [['text'=>"🚫 {$label} — ظرفیت تکمیل", 'callback_data'=>'noop']];
                } else {
                    $buttons[] = [['text'=>"{$icon} {$label} — {$priceLabel}", 'callback_data'=>"course_variant_{$course['id']}_{$productId}"]];
                }
            }
        } elseif ($enrolled) {
            $buttons[] = [['text' => '✅ ثبت‌نام شده‌اید', 'callback_data' => 'noop']];
        } elseif ($full) {
            $buttons[] = [['text' => '🚫 ظرفیت تکمیل است', 'callback_data' => 'noop']];
        } else {
            $price = (int)($course['price'] ?? 0);
            if ($price > 0) {
                $buttons[] = [['text' => "💳 پرداخت و ثبت‌نام — " . number_format($price) . " تومان", 'callback_data' => "course_pay_{$course['id']}"]];
            } else {
                $buttons[] = [['text' => '✅ ثبت‌نام رایگان', 'callback_data' => "course_enroll_{$course['id']}"]];
            }
        }
        $buttons[] = [['text' => '🔙 بازگشت به لیست دوره‌ها', 'callback_data' => 'back_courses']];
        return $buttons;
    }

    // ───── Inline: اخبار (طبقه‌بندی‌شده با ناوبری بین دو دسته) ─────
    public static function newsNav(string $type, int $idx, int $total): array
    {
        $buttons = [];

        // ناوبری درون همان دسته (قبلی/بعدی)
        $navRow = [];
        if ($total > 0) {
            if ($idx < $total - 1) {
                $navRow[] = ['text' => '⬅️ قبلی', 'callback_data' => "newsnav_{$type}_" . ($idx + 1)];
            }
            $navRow[] = ['text' => ($idx + 1) . "/{$total}", 'callback_data' => 'noop'];
            if ($idx > 0) {
                $navRow[] = ['text' => '➡️ بعدی', 'callback_data' => "newsnav_{$type}_" . ($idx - 1)];
            }
        }
        if (!empty($navRow)) $buttons[] = $navRow;

        // جابجایی بین اخبار و اطلاعیه‌ها
        $newsLabel = $type === 'news' ? '✅ 📰 اخبار' : '📰 اخبار';
        $annLabel  = $type === 'announcement' ? '✅ 📢 اطلاعیه‌ها' : '📢 اطلاعیه‌ها';
        $buttons[] = [
            ['text' => $newsLabel, 'callback_data' => 'newssw_news'],
            ['text' => $annLabel,  'callback_data' => 'newssw_announcement'],
        ];

        $buttons[] = [['text' => '🔙 بازگشت', 'callback_data' => 'back_main']];
        return $buttons;
    }

    // ───── Inline: انتخاب روز رزرو ───────────────────────────────
    public static function appointmentDays(): array
    {
        $weekdaysFa     = [0 => 'یک‌شنبه', 1 => 'دوشنبه', 2 => 'سه‌شنبه', 3 => 'چهارشنبه', 4 => 'پنج‌شنبه', 5 => 'جمعه', 6 => 'شنبه'];
        $closedWeekdays = self::getClosedWeekdays();
        $buttons    = [];
        $row        = [];
        $daysAdded  = 0;
        $offset     = 0;
        // به جای یک بازه ثابت ۶ روزه (که می‌توانست یک روز هفته را به‌طور تصادفی حذف کند)،
        // به جلو حرکت می‌کنیم و فقط روزهای تعطیل را رد می‌کنیم تا همه روزهای کاری هفته نمایش داده شوند
        while ($daysAdded < 6 && $offset < 21) {
            $ts = strtotime("+{$offset} day");
            $w  = (int)date('w', $ts);
            $offset++;
            if (in_array($w, $closedWeekdays, true)) {
                continue;
            }
            $dateStr   = date('Y-m-d', $ts);
            $jalali    = self::gregorianToJalali((int)date('Y', $ts), (int)date('n', $ts), (int)date('j', $ts));
            $jalaliStr = sprintf('%04d/%02d/%02d', $jalali[0], $jalali[1], $jalali[2]);
            $label     = $weekdaysFa[$w] . ' ' . $jalaliStr;
            $row[]     = ['text' => $label, 'callback_data' => "appt_day_{$dateStr}"];
            $daysAdded++;
            if (count($row) === 2) { $buttons[] = $row; $row = []; }
        }
        if ($row) $buttons[] = $row;
        $buttons[] = [['text' => '🔙 بازگشت', 'callback_data' => 'back_main']];
        return $buttons;
    }

    // ───── نمایش تاریخ میلادی ذخیره‌شده به شکل شمسی + نام روز هفته ──
    public static function formatApptDate(string $gregorianDate): string
    {
        $ts = strtotime($gregorianDate);
        if (!$ts) return $gregorianDate;
        $weekdaysFa = [0 => 'یک‌شنبه', 1 => 'دوشنبه', 2 => 'سه‌شنبه', 3 => 'چهارشنبه', 4 => 'پنج‌شنبه', 5 => 'جمعه', 6 => 'شنبه'];
        $w = (int)date('w', $ts);
        $jalali = self::gregorianToJalali((int)date('Y', $ts), (int)date('n', $ts), (int)date('j', $ts));
        return $weekdaysFa[$w] . ' ' . sprintf('%04d/%02d/%02d', $jalali[0], $jalali[1], $jalali[2]);
    }

    // تبدیل تاریخ میلادی به شمسی (الگوریتم استاندارد jdf)
    private static function gregorianToJalali(int $gy, int $gm, int $gd): array
    {
        $g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        $gy2   = ($gm > 2) ? ($gy + 1) : $gy;
        $days  = 355666 + (365 * $gy) + intdiv($gy2 + 3, 4) - intdiv($gy2 + 99, 100) + intdiv($gy2 + 399, 400) + $gd + $g_d_m[$gm - 1];
        $jy    = -1595 + (33 * intdiv($days, 12053));
        $days %= 12053;
        $jy   += 4 * intdiv($days, 1461);
        $days %= 1461;
        if ($days > 365) {
            $jy   += intdiv($days - 1, 365);
            $days  = ($days - 1) % 365;
        }
        if ($days < 186) {
            $jm = 1 + intdiv($days, 31);
            $jd = 1 + ($days % 31);
        } else {
            $jm = 7 + intdiv($days - 186, 30);
            $jd = 1 + (($days - 186) % 30);
        }
        return [$jy, $jm, $jd];
    }

    // ───── Inline: انتخاب ساعت رزرو ──────────────────────────────
    public static function appointmentTimes(array $bookedSlots = []): array
    {
        $slots     = self::getAllSlots();
        $available = array_values(array_diff($slots, $bookedSlots));
        $buttons   = [];
        $row       = [];
        foreach ($available as $slot) {
            $row[] = ['text' => $slot, 'callback_data' => "appt_time_{$slot}"];
            if (count($row) === 4) { $buttons[] = $row; $row = []; }
        }
        if ($row) $buttons[] = $row;
        $buttons[] = [['text' => '🔙 بازگشت به انتخاب روز', 'callback_data' => 'appt_back_days']];
        return $buttons;
    }

    // ───── Inline: انتخاب نوع هنگام انتشار خبر/اطلاعیه ────────────
    public static function newsTypeChoice(): array
    {
        return [
            [
                ['text' => '📰 خبر',      'callback_data' => 'news_create_type_news'],
                ['text' => '📢 اطلاعیه', 'callback_data' => 'news_create_type_announcement'],
            ],
        ];
    }

    // ───── Inline: لیست دوره‌ها برای حذف ───────────────────────────
    public static function courseDeleteList(array $courses): array
    {
        $buttons = [];
        foreach ($courses as $c) {
            $buttons[] = [['text' => "🗑 {$c['title']}", 'callback_data' => "delcourse_confirm_{$c['id']}"]];
        }
        $buttons[] = [['text' => '❌ انصراف', 'callback_data' => 'delcourse_cancel']];
        return $buttons;
    }

    // ───── Inline: تأیید حذف دوره ──────────────────────────────────
    public static function courseDeleteConfirm(int $courseId): array
    {
        return [
            [
                ['text' => '✅ بله، حذف شود', 'callback_data' => "delcourse_do_{$courseId}"],
                ['text' => '❌ انصراف',       'callback_data' => 'delcourse_cancel'],
            ],
        ];
    }

    // ───── Inline: منوی ارسال پیام (همگانی / تکی) ──────────────────
    public static function messagingMenu(): array
    {
        return [
            [['text' => '📣 پیام همگانی', 'callback_data' => 'msg_broadcast']],
            [['text' => '✉️ پیام تکی',     'callback_data' => 'msg_single']],
        ];
    }

    // ───── Inline: لیست اخبار/اطلاعیه‌ها برای حذف ───────────────────
    public static function newsDeleteList(array $items): array
    {
        $buttons = [];
        foreach ($items as $n) {
            $icon  = ($n['type'] ?? 'news') === 'announcement' ? '📢' : '📰';
            $title = self::truncate($n['title'], 30);
            $buttons[] = [['text' => "{$icon} {$title}", 'callback_data' => "delnews_confirm_{$n['id']}"]];
        }
        $buttons[] = [['text' => '❌ انصراف', 'callback_data' => 'delnews_cancel']];
        return $buttons;
    }

    // برش امن رشته بدون نیاز قطعی به افزونه mbstring
    private static function truncate(string $text, int $len): string
    {
        if (function_exists('mb_substr')) {
            return mb_substr($text, 0, $len);
        }
        return substr($text, 0, $len);
    }

    // ───── Inline: تأیید حذف خبر/اطلاعیه ────────────────────────────
    public static function newsDeleteConfirm(int $id): array
    {
        return [
            [
                ['text' => '✅ بله، حذف شود', 'callback_data' => "delnews_do_{$id}"],
                ['text' => '❌ انصراف',       'callback_data' => 'delnews_cancel'],
            ],
        ];
    }

    // ───── Inline: گزینه‌های تعاملی پس از ارتباط با ادمین ──────────
    public static function contactReplyOptions(): array
    {
        return [
            [['text' => '↩️ ارسال پیام جدید',   'callback_data' => 'contact_again']],
            [['text' => '📜 پیام‌های قبلی من',   'callback_data' => 'contact_history']],
        ];
    }

    // ───── Inline: دکمه بستن چت برای ادمین ──────────────────────────
    public static function adminCloseChat(string $targetChatId): array
    {
        return [[['text' => '🔒 بستن چت با کاربر', 'callback_data' => "close_chat_{$targetChatId}"]]];
    }

    // ───── Inline: انتخاب ارسال PDF برای گواهینامه ───────────────────
    public static function certPdfChoice(): array
    {
        return [
            [
                ['text' => '📎 ارسال فایل PDF', 'callback_data' => 'certpdf_yes'],
                ['text' => '⏭ بدون فایل',       'callback_data' => 'certpdf_no'],
            ],
        ];
    }

    // ───── Inline: تأیید لغو نوبت ─────────────────────────────────
    public static function apptCancelConfirm(int $id): array
    {
        return [
            [
                ['text' => '✅ بله، لغو شود', 'callback_data' => "delappt_do_{$id}"],
                ['text' => '❌ انصراف',       'callback_data' => 'delappt_cancel'],
            ],
        ];
    }

    // ───── Inline: تأیید پرداخت توسط ادمین ─────────────────────────
    public static function paymentConfirmButton(int $enrollmentId): array
    {
        return [[['text' => '✅ تأیید پرداخت', 'callback_data' => "confirm_pay_{$enrollmentId}"]]];
    }
}
