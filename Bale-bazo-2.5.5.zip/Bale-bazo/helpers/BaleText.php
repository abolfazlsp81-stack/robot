<?php
declare(strict_types=1);

/** Readable text for Bale clients that display HTML parse_mode literally. */
final class BaleText {
    public static function plain(string $text): string {
        $text = preg_replace('~<(script|style)\b[^>]*>.*?</\1\s*>~isu', '', $text) ?? $text;
        $text = preg_replace_callback('~<a\b[^>]*\bhref\s*=\s*(["\x27])(.*?)\1[^>]*>(.*?)</a\s*>~isu', static function(array $m): string {
            $label = strip_tags($m[3]);
            $url = html_entity_decode($m[2], ENT_QUOTES | ENT_HTML5, 'UTF-8');
            return preg_match('~^https?://~i', $url) && $url !== html_entity_decode($label, ENT_QUOTES | ENT_HTML5, 'UTF-8') ? $label.' ('.$url.')' : $label;
        }, $text) ?? $text;
        $text = preg_replace('~<br\s*/?>|</(?:p|div|li|h[1-6])\s*>~iu', "\n", $text) ?? $text;
        // Known formatting tags only: preserve ordinary comparisons such as 2 < 5.
        $text = preg_replace('~</?(?:b|strong|i|em|u|s|strike|del|code|pre|span|p|div|ul|ol|li|h[1-6]|blockquote|a)(?:\s+[^>]*)?\s*/?>~iu', '', $text) ?? $text;
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = str_replace("\r\n", "\n", $text);
        return trim(preg_replace('/\n{3,}/u', "\n\n", $text) ?? $text);
    }

    public static function payload(string $method, array $params): array {
        if (!in_array($method, ['sendMessage','editMessageText','sendPhoto','sendVideo','sendDocument','editMessageCaption'], true)) return $params;
        if (isset($params['parse_mode']) && strtoupper((string)$params['parse_mode']) !== 'HTML' && $params['parse_mode'] !== '') return $params;
        foreach (['text','caption'] as $field) if (isset($params[$field]) && is_string($params[$field])) $params[$field] = self::plain($params[$field]);
        unset($params['parse_mode']);
        return $params;
    }
}
