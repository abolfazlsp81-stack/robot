<?php
// انتقال فایل بله به کتابخانه رسانه وردپرس؛ بدون دیتابیس یا فایل دائمی محلی.

declare(strict_types=1);

final class MediaSync
{
    private static ?array $lastError = null;

    public static function lastError(): ?array
    {
        return self::$lastError;
    }

    /**
     * استخراج شناسه عکس از پیام: photo یا document با MIME تصویری.
     * (کاربرانی که عکس را به‌صورت فایل/بدون فشرده‌سازی می‌فرستند.)
     */
    public static function photo(array $msg): ?string
    {
        if (!empty($msg['photo']) && is_array($msg['photo'])) {
            $best = end($msg['photo']);
            if (!empty($best['file_id'])) return (string)$best['file_id'];
        }
        $doc = $msg['document'] ?? null;
        if (is_array($doc) && !empty($doc['file_id'])
            && str_starts_with((string)($doc['mime_type'] ?? ''), 'image/')) {
            return (string)$doc['file_id'];
        }
        return null;
    }

    public static function transfer(
        BaleApi $api,
        string $fileId,
        string $purpose,
        int $objectId = 0,
        string $preferredName = '',
        int $maxBytes = 2097152
    ): ?array {
        self::$lastError = null;
        $download = $api->downloadFile($fileId, $maxBytes);
        if (!$download || empty($download['path'])) {
            $reason = BaleApi::$downloadError ?? 'network';
            $message = $reason === 'too_large'
                ? 'حجم فایل بیشتر از ۲ مگابایت است؛ لطفاً نسخه کم‌حجم‌تر بفرستید.'
                : ($reason === 'unavailable'
                    ? 'فایل در سرور بله پیدا نشد؛ لطفاً دوباره ارسال کنید.'
                    : 'دانلود فایل از بله ناموفق بود؛ کمی بعد دوباره تلاش کنید.');
            self::$lastError = ['code'=>$reason, 'message'=>$message];
            error_log('[BaleBazo Media Sync] bale_download_failed:' . $reason);
            return null;
        }

        $path = (string)$download['path'];
        $name = trim($preferredName) !== '' ? trim($preferredName) : (string)($download['file_name'] ?? 'bale-file.bin');
        $fields = [
            'purpose'=>$purpose,
            'object_id'=>$objectId,
            'bale_file_id'=>$fileId,
            'file_name'=>$name,
            'mime'=>(string)($download['mime'] ?? ''),
        ];
        $attempt = 0;
        try {
            while (true) {
                try {
                    return SiteClient::uploadFile($path, $fields);
                } catch (SiteSyncException $error) {
                    error_log('[BaleBazo Media Sync] ' . $error->getRemoteCode());
                    // Same signed fields (same receipt key): the twin request
                    // usually commits its receipt during this pause.
                    if ($error->getRemoteCode() === 'operation_uncertain' && $attempt < 1) {
                        $attempt++;
                        sleep(2);
                        continue;
                    }
                    if ($error->getStatus()===0 || $error->getStatus()>=500 || in_array($error->getRemoteCode(),['lease_lost','operation_uncertain'],true)) {
                        if(class_exists('UpdateLifecycle'))UpdateLifecycle::fail($error->getRemoteCode());
                        self::$lastError = ['code'=>$error->getRemoteCode(), 'message'=>$error->getMessage()];
                        throw $error;
                    }
                    self::$lastError = ['code'=>$error->getRemoteCode(), 'message'=>$error->getMessage()];
                    return null;
                }
            }
        } finally {
            if (is_file($path)) @unlink($path);
        }
    }
}
