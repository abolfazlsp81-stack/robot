<?php
// این فایل را به local.php تغییر نام دهید و خارج از کنترل نسخه نگه دارید.
return [
    'bot_token' => '',
    'payment_token' => '',
    'site_url' => '',
    'site_sync_secret' => '',
    'webhook_secret' => '',
];
