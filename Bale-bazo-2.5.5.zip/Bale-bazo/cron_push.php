<?php
// cron_push.php
//
// ارسال خودکار اعلان‌ها و پاسخ‌های پشتیبانی به کاربران بله، بدون نیاز به
// هیچ اقدامی از طرف کاربر. باید با Cron Job سرور هر دقیقه اجرا شود:
//
//   * * * * * php /path/to/Bale-bazo/cron_push.php >> /path/to/Bale-bazo/cron_push.log 2>&1
//
// منطق: افزونه سایت (28.0.6 به بعد) هر اعلان تازه و هر پاسخ تازه پشتیبانی
// را در صف «mph_bale_push» می‌گذارد. این اسکریپت صف را می‌خواند:
//   - اعلان: متن کامل برای کاربر ارسال می‌شود.
//   - پاسخ تیکت: پیام «شما تیکت جدیدی از تیم پشتیبانی دریافت کرده‌اید.»
//     همراه دکمه «مشاهده تیکت» ارسال می‌شود؛ با لمس دکمه، متن پاسخ و
//     پیوست آن نمایش داده می‌شود.

declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '0');

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

define('BASE_DIR', __DIR__);
define('BALE_BAZO_VERSION', '2.5.5');

require_once BASE_DIR . '/helpers/SiteClient.php';
require_once BASE_DIR . '/database/Database.php';
require_once BASE_DIR . '/helpers/BaleApi.php';
require_once BASE_DIR . '/helpers/Keyboards.php';

$config = require BASE_DIR . '/config/config.php';
if (empty($config['bot_token']) || empty($config['site_url']) || strlen((string)($config['site_sync_secret'] ?? '')) < 32) {
    fwrite(STDERR, "Bale Bazo configuration is incomplete.\n");
    exit(1);
}
SiteClient::configure($config);
Keyboards::configure($config);
$api = new BaleApi($config['bot_token'], $config['api_base']);
try {
    $health = SiteClient::health();
} catch (SiteSyncException $error) {
    fwrite(STDERR, "Website sync is unavailable: " . $error->getRemoteCode() . "\n");
    exit(2);
}

$sent = [];
$failed = [];
try {
    $items = Database::pendingPush();
} catch (SiteSyncException $error) {
    fwrite(STDERR, "Push queue is unavailable: " . $error->getRemoteCode() . "\n");
    exit(2);
}
if (Database::lastError() && in_array((string)(Database::lastError()['code'] ?? ''), ['method_not_allowed', 'method_unavailable', 'invalid_method'], true)) {
    echo date('Y-m-d H:i:s') . " - افزونه سایت قدیمی است و صف اعلان ندارد.\n";
    exit(0);
}

foreach ($items as $item) {
    if (!is_array($item)) continue;
    $id = (int)($item['id'] ?? 0);
    $chatId = trim((string)($item['chat_id'] ?? ''));
    $kind = (string)($item['kind'] ?? '');
    $refId = (int)($item['ref_id'] ?? 0);
    if ($id < 1 || $chatId === '' || ($kind !== 'notice' && $kind !== 'ticket')) {
        continue;
    }
    SiteClient::setActorChatId($chatId);
    try {
        if ($kind === 'notice') {
            $title = trim((string)($item['title'] ?? ''));
            $body = trim((string)($item['body'] ?? ''));
            $text = ($title !== '' ? $title . "\n\n" : '') . $body;
            if ($text === '') { $failed[] = $id; continue; }
            $res = $api->sendMessage($chatId, $text, Keyboards::userMain());
        } else {
            if ($refId < 1) { $failed[] = $id; continue; }
            $res = $api->sendInlineMessage(
                $chatId,
                "شما تیکت جدیدی از تیم پشتیبانی دریافت کرده‌اید.",
                [[['text' => 'مشاهده تیکت', 'callback_data' => 'ticket_view_' . $refId]]]
            );
        }
        if (!empty($res['ok'])) $sent[] = $id; else $failed[] = $id;
    } catch (Throwable $error) {
        error_log('[BaleBazo push] chat=' . $chatId . ' kind=' . $kind . ' error=' . $error->getMessage());
        $failed[] = $id;
    }
}

if ($sent || $failed) {
    try {
        Database::ackPush($sent, $failed);
    } catch (SiteSyncException $error) {
        fwrite(STDERR, "Push ack failed: " . $error->getRemoteCode() . "\n");
        exit(3);
    }
}

echo date('Y-m-d H:i:s') . " - صف اعلان بررسی شد. ارسال‌شده: " . count($sent) . " ناموفق: " . count($failed) . "\n";
