<?php
declare(strict_types=1);

/** Site-owned native workflows. No token, account or catalog is copied into this file. */
final class NativeHandler {
    private BaleApi $api;
    public function __construct(BaleApi $api){$this->api=$api;}
    private function call(string $op,array $data=[]){return SiteClient::call('native',array_merge(['op'=>$op],$data));}
    private function syncError(string $chat,SiteSyncException $error): void {
        $retryable=$error->getStatus()===429 || $error->getStatus()>=500 || in_array($error->getRemoteCode(),['network_error','invalid_json','curl_init','asset_network','lease_lost','operation_uncertain'],true);
        if($retryable && class_exists('UpdateLifecycle')){UpdateLifecycle::fail($error->getRemoteCode());return;}
        $this->send($chat,$error->getMessage());
    }
    private function home(): array{return [[['text'=>'🏠 خانه','callback_data'=>'back_main']]];}
    private function send(string $chat,string $text,array $buttons=[]): void {$this->api->sendInlineMessage($chat,$text,array_merge($buttons,$this->home()));}
    public function panel(string $chat,string $panel): bool {
        try {
            if($panel==='book_appointment'){
                $rows=$this->call('therapists');$buttons=[];foreach($rows as $row)$buttons[]=[['text'=>$row['name'],'callback_data'=>'n:slots:'.$row['id'].':1']];
                $this->send($chat,$buttons?'📅 نوبت‌گیری — درمانگر را انتخاب کنید.':'هنوز درمانگری برای نوبت‌گیری ثبت نشده است.',$buttons);return true;
            }
            if($panel==='cart'){$this->cart($chat);return true;}
            if($panel==='orders'){
                $rows=$this->call('orders');$parts=[];foreach($rows as $row)$parts[]=$this->orderText($row);
                foreach(array_chunk($parts,4) as $chunk)$this->send($chat,implode("\n\n",$chunk));
                if(!$parts)$this->send($chat,'سفارشی برای این حساب ثبت نشده است.');return true;
            }
            if($panel==='ticket_support'){$this->send($chat,'🎫 پشتیبانی',[ [['text'=>'تیکت جدید','callback_data'=>'n:ticket:new'],['text'=>'تیکت‌های من','callback_data'=>'n:ticket:list']] ]);return true;}
            return false;
        }catch(SiteSyncException $e){$this->syncError($chat,$e);return true;}
    }
    public function callback(string $chat,string $data): bool {
        if(strpos($data,'n:')!==0)return false;
        try {
            $part=explode(':',$data);$op=$part[1]??'';
            if($op==='slots'){
                $therapist=(int)($part[2]??0);$page=max(1,(int)($part[3]??1));$rows=$this->call('slots',['therapist_id'=>$therapist,'page'=>$page]);$buttons=[];
                $labels=['phone'=>'تلفنی','online'=>'آنلاین','inperson'=>'حضوری'];
                foreach($rows['items'] as $slot)$buttons[]=[['text'=>$slot['date'].' '.$slot['time'].' · '.($labels[$slot['mode']]??$slot['mode']).' · '.number_format((float)$slot['price']),'callback_data'=>'n:slot:'.$slot['id'].':'.$slot['mode']]];
                if($page>1)$buttons[]=[['text'=>'صفحه قبل','callback_data'=>'n:slots:'.$therapist.':'.($page-1)]];
                if($rows['more'])$buttons[]=[['text'=>'صفحه بعد','callback_data'=>'n:slots:'.$therapist.':'.($page+1)]];
                $buttons[]=[['text'=>'↩ درمانگران','callback_data'=>'n:therapists']];$this->send($chat,'ساعت و نوع جلسه را انتخاب کنید. مبلغ به واحد فروشگاه است. ساعت هنگام پرداخت دوباره بررسی می‌شود.',$buttons);
            }elseif($op==='therapists')$this->panel($chat,'book_appointment');
            elseif($op==='slot'){
                StateManager::set($chat,'native_note',['slot_id'=>(int)($part[2]??0),'mode'=>$part[3]??'']);
                $this->send($chat,'توضیح کوتاه و اختیاری برای نوبت را بنویسید؛ یا «بدون توضیح» را بزنید.',[[['text'=>'بدون توضیح','callback_data'=>'n:note:skip']]]);
            }elseif($op==='note'){
                $saved=StateManager::getData($chat);if(StateManager::getStep($chat)!=='native_note'){$this->send($chat,'انتخاب قبلی منقضی شده است؛ ساعت را دوباره انتخاب کنید.');return true;}
                $this->call('appointment_add',$saved+['note'=>'']);StateManager::clear($chat);$this->cart($chat);
            }elseif($op==='cart')$this->cart($chat);
            elseif($op==='add'){$this->call('cart_add',['product_id'=>(int)($part[2]??0)]);$this->cart($chat);}
            elseif($op==='rm'){$this->call('cart_remove',['prefix'=>$part[2]??'','instance_prefix'=>$part[3]??'']);$this->cart($chat);}
            elseif($op==='checkout'){
                $billing=$this->call('billing');$data=['kind'=>($part[2]??'online'),'billing'=>$billing,'index'=>0];StateManager::set($chat,'native_billing',$data);$this->billingPrompt($chat,$data);
            }elseif($op==='keep'){
                $data=StateManager::getData($chat);if(StateManager::getStep($chat)!=='native_billing'){return true;}
                $fields=$this->fields();$key=$fields[(int)$data['index']][0];if(trim((string)($data['billing'][$key]??''))===''){$this->billingPrompt($chat,$data);return true;}$this->nextBilling($chat,$data);
            }elseif($op==='pay'){
                $data=StateManager::getData($chat);if(StateManager::getStep($chat)!=='native_confirm'){$this->send($chat,'ابتدا اطلاعات صورتحساب را مرور کنید.');return true;}
                $result=$this->call('checkout',['billing'=>$data['billing'],'file_id'=>$data['file_id']??0]);StateManager::clear($chat);$buttons=[];
                if(!empty($result['payment_url']))$buttons[]=[['text'=>'💳 ورود به درگاه بانکی','url'=>$result['payment_url']]];
                $buttons[]=[['text'=>'وضعیت سفارش‌ها','callback_data'=>'n:orders'],['text'=>'سبد من','callback_data'=>'n:cart']];
                $this->send($chat,$this->orderText($result),$buttons);
            }elseif($op==='orders')$this->panel($chat,'orders');
            elseif($op==='ticket'){
                if(($part[2]??'')==='new'){StateManager::set($chat,'contact_write');$this->api->sendMessage($chat,'متن تیکت یا تصویر/PDF را بفرستید.',Keyboards::cancelOnly());}
                elseif(($part[2]??'')==='list'){$rows=SiteClient::call('getUserMessageHistory',['user_chat_id'=>$chat,'limit'=>30]);$buttons=[];foreach($rows as $row)$buttons[]=[['text'=>'#'.$row['id'].' · '.$row['subject'].' · '.$row['status'],'callback_data'=>'n:ticket:'.$row['id']]];$this->send($chat,$buttons?'تیکت را انتخاب کنید.':'هنوز تیکتی ثبت نکرده‌اید.',$buttons);}
                else{$row=SiteClient::call('getMessageById',['message_id'=>(int)($part[2]??0)]);if(!$row){$this->send($chat,'تیکت پیدا نشد.');return true;}$this->send($chat,'#'.$row['id'].' '.$row['subject']."\n\n".$row['message'].(!empty($row['reply'])?"\n\nپاسخ پشتیبانی:\n".$row['reply']:''),[[['text'=>'↩ تیکت‌های من','callback_data'=>'n:ticket:list']]]);foreach(['attachment_id','reply_attachment_id'] as $field)if(!empty($row[$field]))$this->attachment($chat,(int)$row[$field]);}
            }else $this->send($chat,'این دکمه معتبر نیست؛ به خانه برگردید.');
        }catch(SiteSyncException $e){$this->syncError($chat,$e);}
        return true;
    }
    public function message(string $chat,array $msg): bool {
        $step=StateManager::getStep($chat);if(strpos($step??'','native_')!==0)return false;
        $text=trim((string)($msg['text']??''));if(in_array($text,['❌ لغو','🏠 خانه','/start'],true)){StateManager::clear($chat);return false;}
        $data=StateManager::getData($chat);
        try{
            if($step==='native_note'){$this->call('appointment_add',$data+['note'=>$text]);StateManager::clear($chat);$this->cart($chat);}
            elseif($step==='native_billing'){
                $fields=$this->fields();$index=(int)$data['index'];$key=$fields[$index][0];if($text===''){$this->billingPrompt($chat,$data);return true;}
                if(in_array($key,['first_name','last_name'],true) && !preg_match('/\p{L}/u',$text)){$this->send($chat,'نام باید با حروف نوشته شود.');return true;}
                $data['billing'][$key]=$text;$this->nextBilling($chat,$data);
            }elseif($step==='native_receipt'){
                $photos=$msg['photo']??[];$photo=$photos?end($photos):[];$file=$msg['document']??$photo;$id=(string)($file['file_id']??'');
                if(!$id){$this->send($chat,'تصویر یا PDF فیش را تا ۲ مگابایت بفرستید.');return true;}
                try{$uploaded=MediaSync::transfer($this->api,$id,'draft_receipt',0,(string)($file['file_name']??''));}catch(SiteSyncException $e){UpdateLifecycle::clear();Database::clearRetryError();$this->send($chat,'آپلود نیمه‌کاره ماند؛ فقط فایل را دوباره ارسال کنید. اطلاعات فرم محفوظ است.');return true;}if(!$uploaded){$err=MediaSync::lastError();$this->send($chat,'آپلود کامل نشد: '.($err['message']??'خطای نامشخص').' فقط فایل را دوباره ارسال کنید. اطلاعات فرم محفوظ است.');return true;}
                $data['file_id']=(int)$uploaded['attachment_id'];$this->confirm($chat,$data);
            }elseif($step==='native_confirm')$this->confirm($chat,$data);
        }catch(SiteSyncException $e){$this->syncError($chat,$e);}
        return true;
    }
    private function fields(): array{return [['first_name','نام'],['last_name','نام خانوادگی'],['phone','شماره موبایل'],['address_1','آدرس صورتحساب']];}
    private function billingPrompt(string $chat,array $data): void{
        $field=$this->fields()[(int)$data['index']];$old=trim((string)($data['billing'][$field[0]]??''));$buttons=$old!==''?[[['text'=>'استفاده از مقدار فعلی','callback_data'=>'n:keep']]]:[];
        $this->send($chat,$field[1].' را وارد کنید.'.($old!==''?"\nمقدار فعلی: ".$old:''),$buttons);
    }
    private function nextBilling(string $chat,array $data): void{
        $data['index']++;
        if($data['index']<count($this->fields())){StateManager::set($chat,'native_billing',$data);$this->billingPrompt($chat,$data);return;}
        if($data['kind']==='receipt'){$cart=$this->call('cart');StateManager::set($chat,'native_receipt',$data);$this->send($chat,'مبلغ فعلی سبد: '.number_format((float)$cart['total']).' '.$cart['currency']."\nشماره کارت: ".$cart['card']."\nبه نام: ".$cart['card_owner']."\nتصویر یا PDF فیش را تا ۲ مگابایت بفرستید.");return;}
        $this->confirm($chat,$data);
    }
    private function confirm(string $chat,array $data): void{StateManager::set($chat,'native_confirm',$data);$this->send($chat,'نام: '.$data['billing']['first_name'].' '.$data['billing']['last_name']."\nموبایل: ".$data['billing']['phone']."\nآدرس: ".$data['billing']['address_1']."\n\nپس از تأیید، مبلغ و ظرفیت دوباره از سایت بررسی می‌شوند.",[[['text'=>'تأیید و ثبت سفارش','callback_data'=>'n:pay'],['text'=>'↩ سبد من','callback_data'=>'n:cart']]]);}
    private function cart(string $chat): void{
        $cart=$this->call('cart');$text='🛒 سبد مشترک حساب شما';$buttons=[];
        foreach($cart['items'] as $i=>$item){$text.="\n".($i+1).'. '.$item['name'].' — '.number_format((float)$item['price']).' '.$cart['currency'];$buttons[]=[['text'=>'حذف مورد '.($i+1),'callback_data'=>'n:rm:'.substr($item['key'],0,12).':'.substr($item['instance'],0,12)]];}
        if(!$cart['items'])$text.="\nسبد خرید خالی است.";
        else{if($cart['gateways']||(float)$cart['total']<=0)$buttons[]=[['text'=>(float)$cart['total']<=0?'تکمیل خرید رایگان':'پرداخت آنلاین','callback_data'=>'n:checkout:online']];if($cart['receipt_available'])$buttons[]=[['text'=>'ثبت فیش واریزی','callback_data'=>'n:checkout:receipt']];$text.="\nجمع فعلی با تخفیف و مالیات: ".number_format((float)$cart['total']).' '.$cart['currency'];}
        $buttons[]=[['text'=>'افزودن دوره','callback_data'=>'back_courses'],['text'=>'افزودن نوبت','callback_data'=>'n:therapists']];$this->send($chat,$text,$buttons);
    }
    private function orderText(array $row): string{return '#'.$row['number'].' — '.$row['message']."\nمبلغ: ".number_format((float)$row['total']).' '.$row['currency'].(!empty($row['reference'])?"\nکد پیگیری بانکی: ".$row['reference']:'');}
    private function attachment(string $chat,int $id): void{
        $file=$this->call('file',['file_id'=>$id]);$bytes=base64_decode((string)$file['content'],true);if($bytes===false)return;
        $tmp=tempnam(sys_get_temp_dir(),'bale-private-');if(!$tmp)return;
        try{file_put_contents($tmp,$bytes);@chmod($tmp,0600);$this->api->sendDocument($chat,new CURLFile($tmp,$file['mime'],$file['name']),'پیوست تیکت');}finally{if(is_file($tmp))unlink($tmp);}
    }
}
