<?php
// handlers/RegisterHandler.php

class RegisterHandler
{
    private BaleApi $api;

    // ترتیب مراحل ثبت‌نام (برای پیاده‌سازی دکمه «مرحله قبل»)
    private const STEP_ORDER = [
        'reg_phone',
        'reg_first_name',
        'reg_last_name',
        'reg_first_name_en',
        'reg_last_name_en',
        'reg_birthdate',
        'reg_field',
        'reg_education',
        'reg_national_code',
        'reg_photo',
    ];

    private const TOTAL_STEPS = 10;

    public function __construct(BaleApi $api)
    {
        $this->api = $api;
    }

    public function handle(array $update): void
    {
        $msg    = $update['message'] ?? null;
        if (!$msg) return;

        $chatId = (string)($msg['chat']['id'] ?? '');
        $text   = trim($msg['text'] ?? '');
        $step   = StateManager::getStep($chatId);

        // ── دریافت عکس پروفایل در مرحله آخر ثبت‌نام ──
        if ($step === 'reg_photo' && ($regPhotoId = MediaSync::photo($msg))) {
            $this->handlePhoto($chatId, $regPhotoId);
            return;
        }

        if ($text === '/start' || $step === null) {
            StateManager::clear($chatId);
            $this->askPhone($chatId);
            return;
        }

        // ── دکمه «مرحله قبل» در هر مرحله‌ای (به‌جز اولین) ──
        if ($text === '⬅️ مرحله قبل') {
            $this->goBack($chatId, $step);
            return;
        }

        match ($step) {
            'reg_first_name'    => $this->handleFirstName($chatId, $text),
            'reg_last_name'     => $this->handleLastName($chatId, $text),
            'reg_first_name_en' => $this->handleFirstNameEn($chatId, $text),
            'reg_last_name_en'  => $this->handleLastNameEn($chatId, $text),
            'reg_phone'         => $this->handlePhone($chatId, $msg),
            'reg_birthdate'     => $this->handleBirthdate($chatId, $text),
            'reg_field'         => $this->handleField($chatId, $text),
            'reg_education'     => $this->handleEducation($chatId, $text),
            'reg_national_code' => $this->handleNationalCode($chatId, $text),
            'reg_photo'         => $this->handlePhotoStep($chatId, $text),
            default             => $this->askPhone($chatId),
        };
    }

    // ───── بازگشت به مرحله قبل ─────────────────────────────────────
    private function goBack(string $chatId, string $currentStep): void
    {
        $idx = array_search($currentStep, self::STEP_ORDER, true);
        if ($idx === false || $idx === 0) {
            // در اولین مرحله، دکمه بازگشت وجود ندارد؛ به‌هرحال دوباره همان مرحله را نشان بده
            $this->askPhone($chatId);
            return;
        }
        $askMethods = [
            'reg_first_name'    => 'askName',
            'reg_last_name'     => 'askLastName',
            'reg_first_name_en' => 'askFirstNameEn',
            'reg_last_name_en'  => 'askLastNameEn',
            'reg_phone'         => 'askPhone',
            'reg_birthdate'     => 'askBirthdate',
            'reg_field'         => 'askField',
            'reg_education'     => 'askEducation',
            'reg_national_code' => 'askNationalCode',
            'reg_photo'         => 'askPhoto',
        ];
        $prevStep = self::STEP_ORDER[$idx - 1];
        $method   = $askMethods[$prevStep];
        $this->$method($chatId);
    }

    // ───── مرحله ۲: نام (مرحله ۱ تأیید شماره است) ───────────────
    private function askName(string $chatId): void
    {
        StateManager::set($chatId, 'reg_first_name');
        $this->api->sendMessage(
            $chatId,
            "📝 <b>مرحله ۲ از " . self::TOTAL_STEPS . "</b> — حسابی با شماره تأییدشده در سایت پیدا نشد؛ اطلاعات ثبت‌نام در سایت ذخیره می‌شود.\n\nلطفاً <b>نام</b> خود را وارد کنید:",
            Keyboards::backCancel()
        );
    }

    private function handleFirstName(string $chatId, string $text): void
    {
        if ($text === '❌ لغو') { StateManager::clear($chatId); $this->cancelMsg($chatId); return; }
        if (!self::validPersianName($text)) {
            $this->api->sendMessage($chatId, "⚠️ نام باید حداقل ۲ حرف باشد و فقط از حروف تشکیل شود. مجدداً وارد کنید:", Keyboards::cancelOnly());
            return;
        }
        StateManager::set($chatId, 'reg_last_name', ['first_name' => $text]);
        $this->askLastName($chatId);
    }

    // ───── مرحله ۲: نام خانوادگی ──────────────────────────────────
    private function askLastName(string $chatId): void
    {
        StateManager::set($chatId, 'reg_last_name');
        $this->api->sendMessage(
            $chatId,
            "📝 <b>مرحله ۳ از " . self::TOTAL_STEPS . "</b>\n\nلطفاً <b>نام خانوادگی</b> خود را وارد کنید:",
            Keyboards::backCancel()
        );
    }

    private function handleLastName(string $chatId, string $text): void
    {
        if ($text === '❌ لغو') { StateManager::clear($chatId); $this->cancelMsg($chatId); return; }
        if (!self::validPersianName($text)) {
            $this->api->sendMessage($chatId, "⚠️ نام خانوادگی باید حداقل ۲ حرف باشد و فقط از حروف تشکیل شود. مجدداً وارد کنید:", Keyboards::backCancel());
            return;
        }
        StateManager::set($chatId, 'reg_first_name_en', ['last_name' => $text]);
        $this->askFirstNameEn($chatId);
    }

    // ───── مرحله ۳: نام به انگلیسی (اجباری) ────────────────────
    private function askFirstNameEn(string $chatId): void
    {
        StateManager::set($chatId, 'reg_first_name_en');
        $this->api->sendMessage(
            $chatId,
            "📝 <b>مرحله ۴ از " . self::TOTAL_STEPS . "</b>\n\nلطفاً <b>نام</b> خود را به <b>انگلیسی</b> وارد کنید:\nمثال: Ali",
            Keyboards::backCancel()
        );
    }

    private function handleFirstNameEn(string $chatId, string $text): void
    {
        if ($text === '❌ لغو') { StateManager::clear($chatId); $this->cancelMsg($chatId); return; }
        if (!self::validEnglishName($text)) {
            $this->api->sendMessage($chatId, "⚠️ نام به انگلیسی باید فقط شامل حروف انگلیسی باشد. مجدداً وارد کنید:", Keyboards::backCancel());
            return;
        }
        StateManager::set($chatId, 'reg_last_name_en', ['first_name_en' => $text]);
        $this->askLastNameEn($chatId);
    }

    // ───── مرحله ۴: نام‌خانوادگی به انگلیسی (اجباری) ───────────
    private function askLastNameEn(string $chatId): void
    {
        StateManager::set($chatId, 'reg_last_name_en');
        $this->api->sendMessage(
            $chatId,
            "📝 <b>مرحله ۵ از " . self::TOTAL_STEPS . "</b>\n\nلطفاً <b>نام‌خانوادگی</b> خود را به <b>انگلیسی</b> وارد کنید:\nمثال: Rezaei",
            Keyboards::backCancel()
        );
    }

    private function handleLastNameEn(string $chatId, string $text): void
    {
        if ($text === '❌ لغو') { StateManager::clear($chatId); $this->cancelMsg($chatId); return; }
        if (!self::validEnglishName($text)) {
            $this->api->sendMessage($chatId, "⚠️ نام‌خانوادگی به انگلیسی باید فقط شامل حروف انگلیسی باشد. مجدداً وارد کنید:", Keyboards::backCancel());
            return;
        }
        StateManager::set($chatId, 'reg_birthdate', ['last_name_en' => $text]);
        $this->askBirthdate($chatId);
    }

    // ───── مرحله ۵: تلفن ─────────────────────────────────────────
    private function askPhone(string $chatId): void
    {
        StateManager::set($chatId, 'reg_phone');
        $this->api->sendMessage(
            $chatId,
            "📱 برای اتصال به حساب سایت، دکمه زیر را بزنید و شماره همین حساب بله را به اشتراک بگذارید. اگر قبلاً عضو سایت باشید، اطلاعات و نقش شما مستقیم از سایت دریافت می‌شود.",
            Keyboards::ownContact()
        );
    }

    private function handlePhone(string $chatId, array $message): void
    {
        $text = trim((string)($message['text'] ?? ''));
        if ($text === '❌ لغو') { StateManager::clear($chatId); $this->cancelMsg($chatId); return; }
        $contact = is_array($message['contact'] ?? null) ? $message['contact'] : [];
        $contactId = (string)($contact['user_id'] ?? '');
        if ($contactId !== $chatId || (string)($message['from']['id'] ?? '') !== $chatId
            || isset($message['forward_from']) || isset($message['forward_origin']) || isset($message['forward_date'])) {
            $this->api->sendMessage($chatId, '⚠️ لطفاً شماره خودتان را با دکمه «تأیید شماره من» ارسال کنید. شماره تایپ‌شده یا مخاطب شخص دیگر قابل تأیید نیست. اگر دکمه کار نمی‌کند، بله را به‌روز کنید.', Keyboards::ownContact());
            return;
        }
        $phone = preg_replace('/\D+/', '', self::normalizeDigits((string)($contact['phone_number'] ?? '')));
        if (strpos($phone, '0098') === 0) $phone = substr($phone, 2);
        if (strpos($phone, '98') === 0) $phone = '0' . substr($phone, 2);
        if (!preg_match('/^09\d{9}$/', $phone)) {
            $this->api->sendMessage($chatId, '⚠️ شماره موبایل ایرانی معتبر لازم است.', Keyboards::ownContact());
            return;
        }
        $result = Database::linkAccount($chatId, $phone, $contactId);
        if ($result === null) {
            $error = Database::lastError();
            $this->api->sendMessage($chatId, '❌ ' . htmlspecialchars((string)($error['message'] ?? 'اتصال به سایت انجام نشد؛ دوباره تلاش کنید.'), ENT_QUOTES, 'UTF-8'), Keyboards::ownContact());
            return;
        }
        if (!empty($result['linked'])) {
            StateManager::clear($chatId);
            $context = Database::refreshContext($chatId);
            $user = is_array($context['user'] ?? null) ? $context['user'] : [];
            Keyboards::setUserContext($user);
            $name = htmlspecialchars((string)($user['fl_name'] ?? 'کاربر'), ENT_QUOTES, 'UTF-8');
            $keyboard = !empty($context['is_admin']) ? Keyboards::adminMain(!empty($context['is_owner'])) : Keyboards::userMain();
            $this->api->sendMessage($chatId, "✅ حساب سایت متصل شد.\nخوش آمدید <b>{$name}</b>؛ اطلاعات و منوها از سایت دریافت شدند.", $keyboard);
            return;
        }
        StateManager::set($chatId, 'reg_first_name', ['phone'=>$phone]);
        $this->askName($chatId);
    }

    // ───── مرحله ۶: تاریخ تولد ─────────────────────────────────────
    private function askBirthdate(string $chatId): void
    {
        StateManager::set($chatId, 'reg_birthdate');
        $this->api->sendMessage(
            $chatId,
            "📝 <b>مرحله ۶ از " . self::TOTAL_STEPS . "</b>\n\nلطفاً <b>تاریخ تولد</b> خود را وارد کنید:\nمثال: ۱۳۷۰/۰۵/۱۵",
            Keyboards::backCancel()
        );
    }

    private function handleBirthdate(string $chatId, string $text): void
    {
        if ($text === '❌ لغو') { StateManager::clear($chatId); $this->cancelMsg($chatId); return; }
        $text = str_replace('-', '/', self::normalizeDigits($text));
        if (!preg_match('/^(1[23]\d{2}|14\d{2})\/(0?[1-9]|1[0-2])\/(0?[1-9]|[12]\d|3[01])$/', $text)) {
            $this->api->sendMessage($chatId, "⚠️ فرمت تاریخ معتبر نیست.\nمثال: ۱۳۷۰/۰۵/۱۵", Keyboards::backCancel());
            return;
        }
        StateManager::set($chatId, 'reg_field', ['birthdate' => $text]);
        $this->askField($chatId);
    }

    // ───── مرحله ۷: رشته تحصیلی ─────────────────────────────────────
    private function askField(string $chatId): void
    {
        StateManager::set($chatId, 'reg_field');
        $this->api->sendMessage(
            $chatId,
            "📝 <b>مرحله ۷ از " . self::TOTAL_STEPS . "</b>\n\nلطفاً <b>رشته تحصیلی</b> خود را وارد کنید:\nمثال: مهندسی کامپیوتر",
            Keyboards::backCancel()
        );
    }

    private function handleField(string $chatId, string $text): void
    {
        if ($text === '❌ لغو') { StateManager::clear($chatId); $this->cancelMsg($chatId); return; }
        if (mb_strlen($text) < 2 || !preg_match('/\p{L}/u', $text)) {
            $this->api->sendMessage($chatId, "⚠️ رشته تحصیلی معتبر نیست. مجدداً وارد کنید:", Keyboards::backCancel());
            return;
        }
        StateManager::set($chatId, 'reg_education', ['field' => $text]);
        $this->askEducation($chatId);
    }

    // ───── مرحله ۸: مقطع تحصیلی ─────────────────────────────────────
    private function askEducation(string $chatId): void
    {
        StateManager::set($chatId, 'reg_education');
        $this->api->sendMessage(
            $chatId,
            "📝 <b>مرحله ۸ از " . self::TOTAL_STEPS . "</b>\n\nلطفاً <b>مقطع تحصیلی</b> خود را انتخاب کنید:",
            Keyboards::educationLevels(true)
        );
    }

    private function handleEducation(string $chatId, string $text): void
    {
        if ($text === '❌ لغو') { StateManager::clear($chatId); $this->cancelMsg($chatId); return; }
        $valid = ['دیپلم', 'کاردانی', 'کارشناسی', 'کارشناسی ارشد', 'دکتری'];
        if (!in_array($text, $valid, true)) {
            $this->api->sendMessage($chatId, "⚠️ لطفاً مقطع تحصیلی را از گزینه‌های زیر انتخاب کنید:", Keyboards::educationLevels(true));
            return;
        }
        StateManager::set($chatId, 'reg_national_code', ['education' => $text]);
        $this->askNationalCode($chatId);
    }

    // ───── مرحله ۹: کد ملی ─────────────────────────────────────────
    private function askNationalCode(string $chatId): void
    {
        StateManager::set($chatId, 'reg_national_code');
        $this->api->sendMessage(
            $chatId,
            "📝 <b>مرحله ۹ از " . self::TOTAL_STEPS . "</b>\n\nلطفاً <b>کد ملی</b> خود را وارد کنید:\nمثال: ۰۰۱۲۳۴۵۶۷۸",
            Keyboards::backCancel()
        );
    }

    private function handleNationalCode(string $chatId, string $text): void
    {
        if ($text === '❌ لغو') { StateManager::clear($chatId); $this->cancelMsg($chatId); return; }
        $code = preg_replace('/\D+/', '', self::normalizeDigits($text));
        if (strlen($code) !== 10) {
            $this->api->sendMessage($chatId, "⚠️ کد ملی باید ۱۰ رقم باشد. مجدداً وارد کنید:", Keyboards::backCancel());
            return;
        }
        StateManager::set($chatId, 'reg_photo', ['national_code' => $code]);
        $this->askPhoto($chatId);
    }

    // ───── مرحله ۱۰: عکس پروفایل (آخرین مرحله) ─────────────────────────────────────
    private function askPhoto(string $chatId): void
    {
        StateManager::set($chatId, 'reg_photo');
        $this->api->sendMessage(
            $chatId,
            "📝 <b>مرحله ۱۰ از " . self::TOTAL_STEPS . "</b> (آخرین مرحله)\n\nلطفاً <b>عکس پروفایل</b> خود را ارسال کنید:\n(یا می‌توانید این مرحله را رد کنید)",
            Keyboards::skipBackCancel('⏭ رد شدن (بدون عکس)')
        );
    }

    private function handlePhotoStep(string $chatId, string $text): void
    {
        if ($text === '❌ لغو') { StateManager::clear($chatId); $this->cancelMsg($chatId); return; }
        if ($text === '⏭ رد شدن (بدون عکس)') {
            $this->finishRegistration($chatId, null);
            return;
        }
        $this->api->sendMessage(
            $chatId,
            "📷 لطفاً عکس پروفایل خود را ارسال کنید، یا «⏭ رد شدن (بدون عکس)» را بزنید:",
            Keyboards::skipBackCancel('⏭ رد شدن (بدون عکس)')
        );
    }

    private function handlePhoto(string $chatId, string $fileId): void
    {
        $this->finishRegistration($chatId, $fileId);
    }

    private function finishRegistration(string $chatId, ?string $photoFileId): void
    {
        $data      = StateManager::getData($chatId);
        $firstName = $data['first_name'] ?? '';
        $lastName  = $data['last_name'] ?? '';
        $fullName  = trim("{$firstName} {$lastName}");

        $ok = Database::createUser(
            $chatId,
            $firstName,
            $lastName,
            $data['phone'] ?? '',
            $data['birthdate'] ?? '',
            $data['national_code'] ?? '',
            $data['field'] ?? '',
            $data['education'] ?? '',
            $photoFileId,
            $data['first_name_en'] ?? '',
            $data['last_name_en'] ?? ''
        );
        if ($ok) {
            StateManager::clear($chatId);
            $photoSynced = true;
            if ($photoFileId) {
                try {
                    $photoSynced = (bool)MediaSync::transfer($this->api, $photoFileId, 'profile');
                } catch (SiteSyncException $error) {
                    UpdateLifecycle::clear();Database::clearRetryError();
                    $photoSynced = false;
                }
            }
            $fresh = Database::refreshContext($chatId);
            $registeredUser = is_array($fresh['user'] ?? null) ? $fresh['user'] : [];
            Keyboards::setUserContext($registeredUser);
            $isAdmin = !empty($fresh['is_admin']);
            $isOwner = !empty($fresh['is_owner']);
            $kb = $isAdmin ? Keyboards::adminMain($isOwner) : Keyboards::userMain();
            $this->api->sendMessage(
                $chatId,
                "✅ <b>ثبت‌نام با موفقیت انجام شد!</b>\n\nخوش آمدید <b>{$fullName}</b> عزیز 🎉\nاکنون می‌توانید از امکانات ربات استفاده کنید."
                . (!$photoSynced ? "\n\n⚠️ حساب ساخته شد اما انتقال عکس به رسانه سایت کامل نشد؛ بعداً از بخش پروفایل دوباره امتحان کنید." : ''),
                $kb
            );

            // ── اطلاع‌رسانی ثبت‌نام جدید به همه ادمین‌ها ──
            $admins = Database::getAllAdmins();
            $notice = "🆕 <b>ثبت‌نام کاربر جدید</b>\n\n"
                    . "👤 نام: {$fullName}\n"
                    . "📞 تلفن: " . ($data['phone'] ?? '—') . "\n"
                    . "🆔 شناسه: <code>{$chatId}</code>";
            foreach ($admins as $admin) {
                $adminChat = trim((string)($admin['chat_id'] ?? ''));
                if ($adminChat !== '') $this->api->sendMessage($adminChat, $notice);
            }
        } else {
            $error = Database::lastError();
            $message = $error && !empty($error['message']) ? (string) $error['message'] : 'اتصال حساب با سایت انجام نشد.';
            $message = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
            $this->api->sendMessage($chatId, "❌ {$message}\n\nاطلاعات این مرحله حفظ شده است؛ دوباره تلاش کنید. برای تأیید مجدد شماره /start را بزنید.");
        }
    }

    private function cancelMsg(string $chatId): void
    {
        $this->api->sendMessage($chatId, "❌ عملیات لغو شد.");
    }

    private static function normalizeDigits(string $value): string
    {
        return strtr($value, [
            '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
            '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
        ]);
    }

    private static function validPersianName(string $value): bool
    {
        $value = trim($value);
        if (!preg_match('/^[\p{L}\p{M}\x{200C}\s\.\'\x{2019}-]+$/u', $value)) return false;
        preg_match_all('/\p{L}/u', $value, $letters);
        return count($letters[0] ?? []) >= 2;
    }

    private static function validEnglishName(string $value): bool
    {
        $value = trim($value);
        return preg_match('/^[A-Za-z\s\.\'\x{2019}-]+$/u', $value) === 1
            && preg_match_all('/[A-Za-z]/', $value) >= 2;
    }
}
