<?php
// handlers/AdminHandler.php

class AdminHandler
{
    private BaleApi $api;

    public function __construct(BaleApi $api)
    {
        $this->api = $api;
    }

    // ───── Dispatcher اصلی ───────────────────────────────────────
    public function handle(array $update, array $user, bool $isOwner): void
    {
        $msg    = $update['message'] ?? null;
        if (!$msg) return;

        $chatId = (string)($msg['chat']['id'] ?? '');
        $text   = trim($msg['text'] ?? '');
        $step   = StateManager::getStep($chatId);

        if (in_array($step, ['bot_admin_add','bot_admin_remove','bot_admin_confirm'], true)) {
            $this->handleBotAdminInput($chatId, $text, $step, $isOwner);
            return;
        }

        // ── دریافت فایل PDF گواهینامه ──
        if ($step === 'cert_pdf_upload' && !empty($msg['document'])) {
            $this->handleCertPdfUpload($chatId, $msg['document'], $isOwner);
            return;
        }

        // ── دریافت پیام تبلیغاتی دوره (متن یا عکس/فیلم با کپشن) ──
        if ($step === 'course_promo') {
            $this->handleCoursePromo($chatId, $msg, $text);
            return;
        }

        // ── ویرایش پیام تبلیغاتی یک دوره موجود ──
        if ($step === 'course_edit_promo') {
            $this->handleCourseEditPromo($chatId, $msg, $text, $isOwner);
            return;
        }

        if ($step) {
            $this->handleStep($chatId, $text, $step, $user, $isOwner);
            return;
        }

        match ($text) {
            '⚙️ پنل مدیریت',
            '⚙️ ابزارهای مدیریت ربات' => $this->showPanel($chatId, $isOwner),
            '🔴 خاموش کردن ربات'    => $this->toggleBot($chatId, $isOwner, false),
            '🟢 روشن کردن ربات'    => $this->toggleBot($chatId, $isOwner, true),
            '➕ افزودن ادمین'      => $this->startBotAdminChange($chatId, 'add'),
            '➖ حذف ادمین'         => $this->startBotAdminChange($chatId, 'remove'),
            '👥 لیست کاربران'       => $this->listUsers($chatId),
            '📋 لیست دوره‌ها'       => $this->listCourses($chatId),
            '➕ ثبت دوره جدید'     => $this->startAddCourse($chatId),
            '🗑 حذف دوره'           => $this->startDeleteCourse($chatId),
            '📢 انتشار خبر'         => $this->startPublishNews($chatId),
            '🗑 حذف خبر/اطلاعیه'    => $this->startDeleteNews($chatId),
            '📨 ارسال پیام'         => $this->showMessagingMenu($chatId),
            '📥 صندوق پیام‌ها'      => $this->showInbox($chatId),
            '📑 پاسخ‌داده‌شده‌ها'    => $this->sendRepliedMessagesFile($chatId),
            '🎓 صدور گواهینامه'     => $this->startIssueCert($chatId),
            '📅 نوبت‌های رزرو شده'  => $this->listAppointments($chatId),
            '💳 لیست پرداخت‌ها'     => $this->listPayments($chatId),
            '💰 تنظیمات پرداخت'     => $this->showPaymentSettings($chatId),
            '📋 فایل کامل ثبت‌نامی‌ها' => $this->sendRegistrantsFile($chatId),
            '👤 افزودن/حذف ادمین'   => $this->showPanel($chatId, $isOwner),
            '🚫 بلاک کاربر'         => $this->startBlockUser($chatId),
            '🔙 بازگشت'             => $this->backToMain($chatId, $user, $isOwner),
            default                  => null,
        };
    }

    // ───── Callback ادمین ─────────────────────────────────────────
    public function handleCallback(array $update, array $user, bool $isOwner): void
    {
        $cb     = $update['callback_query'];
        $chatId = (string)($cb['message']['chat']['id'] ?? '');
        $msgId  = (int)($cb['message']['message_id'] ?? 0);
        $cbId   = $cb['id'];
        $data   = $cb['data'] ?? '';

        try {

        if (str_starts_with($data, 'bot_admin_')) {
            $this->confirmBotAdminChange($chatId, $msgId, $data, $isOwner);
            return;
        }

        // ── پاسخ به پیام کاربر ──
        if (str_starts_with($data, 'reply_msg_')) {
            $msgId2 = (int)str_replace('reply_msg_', '', $data);
            $msg    = Database::getMessageById($msgId2);
            if (!$msg) {
                $this->api->sendMessage($chatId, "❌ پیام یافت نشد.");
                return;
            }
            StateManager::set($chatId, "admin_reply_{$msgId2}", ['target_msg_id' => $msgId2, 'target_chat_id' => (string)$msg['user_chat_id']]);
            $this->api->sendMessage(
                $chatId,
                "↩️ <b>پاسخ به پیام</b>\n\n"
                . "👤 کاربر: {$msg['fl_name']}\n"
                . "💬 پیام: {$msg['message']}\n\n"
                . "متن پاسخ خود را بنویسید:",
                Keyboards::cancelOnly()
            );
            return;
        }

        // ── لیست دوره‌ها: بازگشت به لیست ──
        if ($data === 'cadmin_list') {
            $courses = Database::getAllCourses();
            $this->api->editMessageText(
                $chatId, $msgId,
                "📋 <b>لیست دوره‌ها</b> (" . count($courses) . " مورد)\n\nروی دوره موردنظر بزنید:",
                Keyboards::courseAdminList($courses)
            );
            return;
        }

        // ── انتخاب یک دوره از لیست ──
        if (str_starts_with($data, 'cadmin_select_')) {
            $courseId = (int)str_replace('cadmin_select_', '', $data);
            $this->showCourseAdminDetail($chatId, $msgId, $courseId);
            return;
        }

        // ── ثبت‌نامی‌های یک دوره خاص ──
        if (str_starts_with($data, 'course_enrolls_')) {
            $courseId = (int)str_replace('course_enrolls_', '', $data);
            $this->showCourseEnrollments($chatId, $courseId);
            return;
        }

        // ── منوی ویرایش یک دوره ──
        if (str_starts_with($data, 'cedit_menu_')) {
            $courseId = (int)str_replace('cedit_menu_', '', $data);
            $course   = Database::getCourse($courseId);
            if (!$course) { $this->api->answerCallbackQuery($cbId, '❌ دوره یافت نشد.', true); return; }
            $this->api->editMessageText($chatId, $msgId, "✏️ <b>ویرایش دوره: {$course['title']}</b>\n\nکدام فیلد را می‌خواهید ویرایش کنید؟", Keyboards::courseEditMenu($courseId));
            return;
        }

        // ── فعال/غیرفعال کردن سریع دوره ──
        if (str_starts_with($data, 'cedit_toggle_')) {
            $courseId = (int)str_replace('cedit_toggle_', '', $data);
            Database::toggleCourseActive($courseId);
            $this->showCourseAdminDetail($chatId, $msgId, $courseId);
            return;
        }

        // ── شروع ویرایش یکی از فیلدهای متنی/عددی دوره ──
        if (preg_match('/^cedit_(title|desc|cap|price|start|end)_(\d+)$/', $data, $m)) {
            $field    = $m[1];
            $courseId = (int)$m[2];
            $course   = Database::getCourse($courseId);
            if (!$course) { $this->api->answerCallbackQuery($cbId, '❌ دوره یافت نشد.', true); return; }
            $prompts = [
                'title' => 'عنوان جدید دوره را وارد کنید:',
                'desc'  => 'توضیحات جدید دوره را وارد کنید:',
                'cap'   => 'ظرفیت جدید (عدد) را وارد کنید:',
                'price' => 'قیمت جدید را به تومان وارد کنید (برای رایگان عدد 0 بزنید):',
                'start' => 'تاریخ شروع جدید را وارد کنید:',
                'end'   => 'تاریخ پایان جدید را وارد کنید:',
            ];
            StateManager::set($chatId, 'course_edit_field', ['edit_course_id' => $courseId, 'edit_field' => $field]);
            $this->api->sendMessage($chatId, "✏️ {$prompts[$field]}\n\nمقدار فعلی: {$course[$this->courseFieldColumn($field)]}", Keyboards::cancelOnly());
            return;
        }

        // ── شروع ویرایش پیام تبلیغاتی دوره ──
        if (str_starts_with($data, 'cedit_promo_')) {
            $courseId = (int)str_replace('cedit_promo_', '', $data);
            $course   = Database::getCourse($courseId);
            if (!$course) { $this->api->answerCallbackQuery($cbId, '❌ دوره یافت نشد.', true); return; }
            StateManager::set($chatId, 'course_edit_promo', ['edit_course_id' => $courseId]);
            $this->api->sendMessage(
                $chatId,
                "📣 پیام تبلیغاتی جدید (متن، یا عکس/فیلم با کپشن) را ارسال کنید:\n(برای حذف پیام تبلیغاتی، «🗑 حذف پیام تبلیغاتی» را بزنید)",
                Keyboards::removeOrCancel()
            );
            return;
        }

        // ── انتخاب نوع هنگام انتشار خبر/اطلاعیه ──
        if (str_starts_with($data, 'news_create_type_')) {
            $type = str_replace('news_create_type_', '', $data);
            $type = $type === 'announcement' ? 'announcement' : 'news';
            $label = $type === 'announcement' ? 'اطلاعیه' : 'خبر';
            StateManager::set($chatId, 'news_title', ['news_type' => $type]);
            $this->api->sendMessage($chatId, "📢 <b>انتشار {$label} جدید</b>\n\nعنوان {$label} را وارد کنید:", Keyboards::cancelOnly());
            return;
        }

        // ── منوی ارسال پیام: همگانی ──
        if ($data === 'msg_broadcast') {
            StateManager::set($chatId, 'broadcast_text');
            $this->api->sendMessage($chatId, "📣 <b>پیام همگانی</b>\n\nمتن پیام را بنویسید:", Keyboards::cancelOnly());
            return;
        }

        // ── منوی ارسال پیام: تکی ──
        if ($data === 'msg_single') {
            StateManager::set($chatId, 'single_msg_target');
            $this->api->sendMessage(
                $chatId,
                "✉️ <b>پیام تکی</b>\n\nآیدی عددی (Chat ID) یا شماره تلفن کاربر موردنظر را وارد کنید:",
                Keyboards::cancelOnly()
            );
            return;
        }

        // ── حذف دوره: تأیید ──
        if (str_starts_with($data, 'delcourse_confirm_')) {
            $courseId = (int)str_replace('delcourse_confirm_', '', $data);
            $course   = Database::getCourse($courseId);
            if (!$course) {
                $this->api->editMessageText($chatId, $msgId, "❌ دوره یافت نشد.");
                return;
            }
            $enrolls = Database::getCourseEnrollCount($courseId);
            $this->api->editMessageText(
                $chatId, $msgId,
                "⚠️ آیا از حذف دوره «<b>{$course['title']}</b>» مطمئن هستید؟\n"
                . "👥 تعداد ثبت‌نام‌شده: {$enrolls} نفر\n\n"
                . "<i>توجه: ثبت‌نام‌های مرتبط با این دوره نیز حذف خواهند شد.</i>",
                Keyboards::courseDeleteConfirm($courseId)
            );
            return;
        }

        // ── حذف دوره: اجرا ──
        if (str_starts_with($data, 'delcourse_do_')) {
            $courseId = (int)str_replace('delcourse_do_', '', $data);
            $course   = Database::getCourse($courseId);
            $title    = $course['title'] ?? '';
            $ok       = Database::deleteCourse($courseId);
            $text     = $ok ? "✅ دوره «{$title}» با موفقیت حذف شد." : "❌ خطا در حذف دوره.";
            $this->api->editMessageText($chatId, $msgId, $text);
            return;
        }

        // ── حذف دوره: انصراف ──
        if ($data === 'delcourse_cancel') {
            $this->api->editMessageText($chatId, $msgId, "❌ عملیات حذف لغو شد.");
            return;
        }

        // ── حذف خبر/اطلاعیه: تأیید ──
        if (str_starts_with($data, 'delnews_confirm_')) {
            $id   = (int)str_replace('delnews_confirm_', '', $data);
            $item = Database::getNewsById($id);
            if (!$item) {
                $this->api->editMessageText($chatId, $msgId, "❌ مورد یافت نشد.");
                return;
            }
            $label = ($item['type'] ?? 'news') === 'announcement' ? 'اطلاعیه' : 'خبر';
            $this->api->editMessageText(
                $chatId, $msgId,
                "⚠️ آیا از حذف این {$label} مطمئن هستید؟\n\n«<b>{$item['title']}</b>»",
                Keyboards::newsDeleteConfirm($id)
            );
            return;
        }

        // ── حذف خبر/اطلاعیه: اجرا ──
        if (str_starts_with($data, 'delnews_do_')) {
            $id    = (int)str_replace('delnews_do_', '', $data);
            $item  = Database::getNewsById($id);
            $title = $item['title'] ?? '';
            $ok    = Database::deleteNews($id);
            $text  = $ok ? "✅ «{$title}» با موفقیت حذف شد." : "❌ خطا در حذف.";
            $this->api->editMessageText($chatId, $msgId, $text);
            return;
        }

        // ── حذف خبر/اطلاعیه: انصراف ──
        if ($data === 'delnews_cancel') {
            $this->api->editMessageText($chatId, $msgId, "❌ عملیات حذف لغو شد.");
            return;
        }

        // ── صدور گواهینامه: انتخاب ارسال PDF ──
        if ($data === 'certpdf_yes') {
            StateManager::set($chatId, 'cert_pdf_upload');
            $this->api->editMessageText($chatId, $msgId, "📎 لطفاً فایل PDF گواهینامه را ارسال کنید:");
            return;
        }
        if ($data === 'certpdf_no') {
            $this->api->editMessageText($chatId, $msgId, "⏳ در حال صدور گواهینامه...");
            $this->finalizeCertificate($chatId, $isOwner, null);
            return;
        }

        // ── بستن چت با کاربر ──
        if (str_starts_with($data, 'close_chat_')) {
            $targetId = str_replace('close_chat_', '', $data);
            Database::closeChat((int)$targetId);
            $this->api->editMessageText($chatId, $msgId, "🔒 چت با کاربر <code>{$targetId}</code> بسته شد.");
            $this->api->sendMessage(
                $targetId,
                "🔒 گفتگوی شما با ادمین بسته شد.\nدر صورت نیاز می‌توانید پیام جدید ارسال کنید."
            );
            return;
        }

        // ── تنظیمات پرداخت: تغییر روش (چرخشی: کارت → بله → هر دو) ──
        if ($data === 'paysettings_toggle_method') {
            $current = Database::getPaymentMethod();
            $new = match ($current) {
                'card'  => 'bale',
                'bale'  => 'both',
                default => 'card',
            };
            Database::setPaymentMethod($new);
            $methodName = match ($new) {
                'bale'  => 'درگاه آنلاین بله',
                'both'  => 'هر دو روش (کاربر انتخاب می‌کند)',
                default => 'کارت‌به‌کارت (تأیید دستی)',
            };
            $this->api->editMessageText($chatId, $msgId, "✅ روش پرداخت به «{$methodName}» تغییر یافت.", Keyboards::paymentSettingsMenu($new));
            return;
        }

        // ── تنظیمات پرداخت: تغییر شماره کارت ──
        if ($data === 'paysettings_edit_card') {
            StateManager::set($chatId, 'payment_card_number');
            $this->api->sendMessage($chatId, "✏️ <b>شماره کارت جدید</b> را وارد کنید:", Keyboards::cancelOnly());
            return;
        }

        // ── مشاهده عکس رسید توسط ادمین ──
        if (str_starts_with($data, 'view_receipt_')) {
            $enrollId = (int)str_replace('view_receipt_', '', $data);
            $enroll   = Database::getEnrollmentById($enrollId);
            if (!$enroll || empty($enroll['receipt_file_id'])) {
                $this->api->answerCallbackQuery($cbId, '❌ رسیدی برای این پرداخت ثبت نشده است.', true);
                return;
            }
            $caption = "🧾 رسید «{$enroll['fl_name']}» — دوره «{$enroll['course_title']}»\n🔢 کد پیگیری: <code>{$enroll['tracking_code']}</code>";
            $btn = $enroll['payment_status'] === 'pending' ? Keyboards::paymentConfirmButton($enrollId) : [];
            $this->api->sendPhoto($chatId, $enroll['receipt_file_id'], $caption, $btn);
            return;
        }

        // ── تأیید پرداخت توسط ادمین ──
        if (str_starts_with($data, 'confirm_pay_')) {
            $enrollId = (int)str_replace('confirm_pay_', '', $data);
            $enroll   = Database::getEnrollmentById($enrollId);
            if (!$enroll) {
                $this->api->answerCallbackQuery($cbId, '❌ رکورد پرداخت یافت نشد.', true);
                return;
            }
            if ($enroll['payment_status'] === 'paid') {
                $this->api->answerCallbackQuery($cbId, '✅ این پرداخت قبلاً تأیید شده است.', true);
                return;
            }
            $expectedRial = (int)($enroll['payment_amount_rial'] ?? ((int)($enroll['price'] ?? 0) * 10));
            $confirmed = Database::confirmEnrollmentById($enrollId, "manual-{$chatId}-" . time(), $expectedRial);
            if (!$confirmed) {
                $confirmError = Database::lastError();
                $this->api->answerCallbackQuery($cbId, '❌ ' . ($confirmError['message'] ?? 'تأیید سفارش در سایت انجام نشد؛ دوباره تلاش کنید.'), true);
                return;
            }
            $this->api->editMessageText(
                $chatId, $msgId,
                "✅ پرداخت <b>{$enroll['fl_name']}</b> برای دوره «{$enroll['course_title']}» تأیید شد.\n🔢 کد پیگیری: <code>{$enroll['tracking_code']}</code>"
            );
            $this->api->sendMessage(
                $enroll['user_id'],
                "✅ پرداخت شما برای دوره «{$enroll['course_title']}» تأیید شد!\n🔢 کد پیگیری: <code>{$enroll['tracking_code']}</code>\n\nثبت‌نام شما نهایی شد. 🎉"
            );
            return;
        }
        } finally {
            $this->api->answerCallbackQueryIfPending((string)$cbId);
        }
    }

    // ───── نمایش پنل ─────────────────────────────────────────────
    private function showPanel(string $chatId, bool $isOwner): void
    {
        $botActive   = Database::getSetting('bot_active') === '1';
        $status      = $botActive ? '🟢 فعال' : '🔴 غیرفعال';

        $this->api->sendMessage(
            $chatId,
            "⚙️ تنظیمات ربات\n\nوضعیت ربات: {$status}\nعملیات موردنظر را انتخاب کنید.",
            Keyboards::adminPanel($isOwner, $botActive)
        );
    }

    // ───── روشن/خاموش ─────────────────────────────────────────────
    private function toggleBot(string $chatId, bool $isOwner, bool $active): void
    {
        $new     = $active ? '1' : '0';
        Database::setSetting('bot_active', $new);
        if (Database::getSetting('bot_active') !== $new) {
            $this->api->sendMessage($chatId, '❌ تغییر وضعیت ذخیره نشد. دوباره تلاش کنید.');
            return;
        }
        $status = $new === '1' ? '🟢 ربات روشن شد.' : '🔴 ربات خاموش شد.';
        $this->api->sendMessage($chatId, $status, Keyboards::adminPanel($isOwner, $new === '1'));
    }

    private function startBotAdminChange(string $chatId, string $action): void
    {
        StateManager::set($chatId, 'bot_admin_'.$action, ['bot_admin_action'=>$action]);
        $label = $action === 'add' ? 'افزودن ادمین' : 'حذف ادمین';
        $this->api->sendMessage($chatId, "👤 {$label}\n\nشماره تلفن یا شناسه عددی بله فرد را وارد کنید.\nحساب او باید به سایت متصل باشد.", Keyboards::cancelOnly());
    }

    private function handleBotAdminInput(string $chatId, string $input, string $step, bool $isOwner): void
    {
        if (in_array($input, ['❌ لغو','🔙 بازگشت'], true)) {
            StateManager::clear($chatId);
            $this->showPanel($chatId, $isOwner);
            return;
        }
        if ($step === 'bot_admin_confirm') {
            $this->api->sendMessage($chatId, 'تأیید یا انصراف را زیر پیام قبلی انتخاب کنید.', Keyboards::cancelOnly());
            return;
        }
        $input = strtr(trim($input), ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
        $target = Database::resolveUserIdentifier($input);
        $targetId = (string)($target['chat_id'] ?? '');
        if ($targetId === '') { $this->api->sendMessage($chatId, '❌ حساب متصل به سایت پیدا نشد؛ شماره یا شناسه را دوباره وارد کنید.'); return; }
        $action = $step === 'bot_admin_add' ? 'add' : 'remove';
        if (Database::isOwner($targetId) || ($action === 'remove' && $targetId === $chatId)) {
            $this->api->sendMessage($chatId, '❌ حساب مالک محافظت شده است؛ حذف دسترسی خودتان هم از این بخش انجام نمی‌شود.');
            return;
        }
        $admin = Database::isAdmin($targetId);
        if (($action === 'add' && $admin) || ($action === 'remove' && !$admin)) {
            $this->api->sendMessage($chatId, $admin ? 'این فرد از قبل ادمین است؛ تغییری انجام نشد.' : 'این فرد ادمین نیست؛ تغییری انجام نشد.');
            return;
        }
        $name = (string)($target['fl_name'] ?? $targetId);
        StateManager::set($chatId, 'bot_admin_confirm', ['bot_admin_action'=>$action,'bot_admin_target'=>$targetId,'bot_admin_name'=>$name]);
        $label = $action === 'add' ? 'افزودن ادمین' : 'حذف ادمین';
        $this->api->sendInlineMessage($chatId, "{$label}: {$name}\n\nدسترسی مدیریت ربات با نقش «مدیر مجموعه» سایت مشترک است.\nآیا این تغییر را تأیید می‌کنید؟", [
            [['text'=>'✅ تأیید '.$label,'callback_data'=>'bot_admin_apply_'.$action.'_'.$targetId]],
            [['text'=>'انصراف','callback_data'=>'bot_admin_cancel']],
        ]);
    }

    private function confirmBotAdminChange(string $chatId, int $messageId, string $data, bool $isOwner): void
    {
        if (!Database::isAdmin($chatId) || StateManager::getStep($chatId) !== 'bot_admin_confirm') {
            $this->api->sendMessage($chatId, 'این درخواست منقضی شده یا دسترسی آن را ندارید.');
            return;
        }
        if ($data === 'bot_admin_cancel') {
            StateManager::clear($chatId);
            $this->api->editMessageText($chatId, $messageId, 'تغییر ادمین لغو شد.');
            $this->showPanel($chatId, $isOwner);
            return;
        }
        if (!preg_match('/^bot_admin_apply_(add|remove)_(\d+)$/D', $data, $match)) return;
        $saved = StateManager::getData($chatId);
        if (($saved['bot_admin_action'] ?? '') !== $match[1] || (string)($saved['bot_admin_target'] ?? '') !== $match[2]) {
            $this->api->sendMessage($chatId, 'این دکمه مربوط به درخواست فعلی نیست.');
            return;
        }
        $target = $match[2]; $add = $match[1] === 'add';
        if (Database::isOwner($target) || (!$add && $target === $chatId)) {
            $this->api->sendMessage($chatId, '❌ این حساب محافظت شده است.');
            return;
        }
        $ok = $add ? Database::addAdmin($target, $chatId) : Database::removeAdmin($target);
        $actual = Database::isAdmin($target);
        StateManager::clear($chatId);
        $message = $ok && $actual === $add ? ($add ? '✅ ادمین اضافه شد.' : '✅ ادمین حذف شد.') : '❌ تغییر کامل نشد؛ ممکن است حساب دارای نقش مدیریت دیگری در وردپرس باشد.';
        $this->api->editMessageText($chatId, $messageId, $message);
        $this->showPanel($chatId, $isOwner);
    }

    // ───── ارسال متن، یا فایل در صورت طولانی بودن از حد API ────────
    private function sendTextOrFile(string $chatId, string $text, string $filename, string $caption): void
    {
        if (strlen($text) > 3500) {
            $this->sendTemporaryTextFile($chatId, $text, $filename, $caption);
        } else {
            $this->api->sendMessage($chatId, $text);
        }
    }

    private function sendTemporaryTextFile(string $chatId, string $text, string $filename, string $caption): void
    {
        $file = tempnam(sys_get_temp_dir(), 'bale_report_');
        if ($file === false) {
            $this->api->sendMessage($chatId, '❌ ساخت فایل گزارش روی سرور انجام نشد.');
            return;
        }
        try {
            @chmod($file, 0600);
            if (file_put_contents($file, $text, LOCK_EX) === false) {
                $this->api->sendMessage($chatId, '❌ نوشتن فایل گزارش روی سرور انجام نشد.');
                return;
            }
            $name = preg_replace('/[^A-Za-z0-9._-]+/', '-', basename($filename)) ?: 'report.txt';
            $sent = $this->api->sendLocalDocument($chatId, $file, $caption, $name);
            if (empty($sent['ok'])) $this->api->sendMessage($chatId, '❌ ارسال فایل گزارش در بله انجام نشد؛ دوباره تلاش کنید.');
        } finally {
            if (is_file($file)) @unlink($file);
        }
    }

    // ───── لیست کاربران ──────────────────────────────────────────
    private function listUsers(string $chatId): void
    {
        $users = Database::getAllUsers();
        if (empty($users)) {
            $this->api->sendMessage($chatId, "👥 هیچ کاربری ثبت‌نام نکرده است.");
            return;
        }
        $text = "👥 <b>لیست کاربران ثبت‌نام‌شده</b> (" . count($users) . " نفر)\n\n";
        foreach ($users as $i => $u) {
            $blocked = $u['is_blocked'] ? ' 🚫' : '';
            $text .= ($i + 1) . ". <b>{$u['fl_name']}</b>{$blocked}\n";
            $text .= "   📞 {$u['phone']} | 🆔 <code>{$u['chat_id']}</code>\n\n";
        }
        $this->sendTextOrFile($chatId, $text, 'users-list.txt', "👥 لیست کاربران (" . count($users) . " نفر)");
    }

    // نگاشت کلید کوتاه فیلد ویرایش دوره به نام ستون واقعی در دیتابیس
    private function courseFieldColumn(string $field): string
    {
        return [
            'title' => 'title',
            'desc'  => 'description',
            'cap'   => 'capacity',
            'price' => 'price',
            'start' => 'start_date',
            'end'   => 'end_date',
        ][$field] ?? $field;
    }

    // ───── لیست دوره‌ها ──────────────────────────────────────────
    private function listCourses(string $chatId): void
    {
        $courses = Database::getAllCourses();
        if (empty($courses)) {
            $this->api->sendMessage($chatId, "📋 هیچ دوره‌ای ثبت نشده است.");
            return;
        }
        $this->api->sendInlineMessage(
            $chatId,
            "📋 <b>لیست دوره‌ها</b> (" . count($courses) . " مورد)\n\nروی دوره موردنظر بزنید:",
            Keyboards::courseAdminList($courses)
        );
    }

    // نمایش جزئیات یک دوره برای ادمین (بعد از انتخاب از لیست) — با ویرایش پیام موجود
    private function showCourseAdminDetail(string $chatId, int $msgId, int $courseId): void
    {
        $course = Database::getCourse($courseId);
        if (!$course) {
            $this->api->editMessageText($chatId, $msgId, "❌ دوره یافت نشد.");
            return;
        }
        $enrolls = Database::getCourseEnrollCount($courseId);
        $status  = $course['is_active'] ? '✅ فعال' : '❌ غیرفعال';
        $price   = (int)($course['price'] ?? 0);
        $text  = "📖 <b>{$course['title']}</b> [{$status}]\n";
        $text .= "📝 {$course['description']}\n";
        $text .= "📅 {$course['start_date']} تا {$course['end_date']}\n";
        $text .= "💰 " . ($price > 0 ? number_format($price) . " تومان" : "رایگان") . "\n";
        $text .= "👥 ظرفیت: {$course['capacity']} | ثبت‌نام: {$enrolls}";
        $this->api->editMessageText($chatId, $msgId, $text, Keyboards::courseAdminDetail($courseId));
    }

    // ───── ثبت‌نامی‌های یک دوره خاص ────────────────────────────────
    private function showCourseEnrollments(string $chatId, int $courseId): void
    {
        $course = Database::getCourse($courseId);
        if (!$course) {
            $this->api->sendMessage($chatId, "❌ دوره یافت نشد.");
            return;
        }
        $enrolls = Database::getEnrollments($courseId);
        if (empty($enrolls)) {
            $this->api->sendMessage($chatId, "👥 هنوز کسی در دوره «{$course['title']}» ثبت‌نام نکرده است.");
            return;
        }
        $text = "👥 <b>ثبت‌نامی‌های دوره: {$course['title']}</b> (" . count($enrolls) . " نفر)\n\n";
        foreach ($enrolls as $i => $e) {
            $status = match ($e['payment_status']) {
                'paid'    => '✅ پرداخت‌شده',
                'pending' => '⏳ در انتظار تأیید',
                default   => '🆓 رایگان',
            };
            $text .= "━━━━━━━━━━━━━━━━\n";
            $text .= ($i + 1) . ". 👤 {$e['fl_name']} | 📞 {$e['phone']}\n";
            $text .= "   🆔 <code>{$e['chat_id']}</code>\n";
            if (!empty($e['tracking_code'])) {
                $text .= "   🔢 کد پیگیری: <code>{$e['tracking_code']}</code>\n";
            }
            $text .= "   وضعیت: {$status} | 🗓 {$e['enrolled_at']}\n";
        }
        $this->sendTextOrFile($chatId, $text, "course-{$courseId}-enrollments.txt", "👥 ثبت‌نامی‌های «{$course['title']}» (" . count($enrolls) . " نفر)");
    }

    // ───── نوبت‌های رزرو‌شده ──────────────────────────────────────
    private function listAppointments(string $chatId): void
    {
        $appts = Database::getAllAppointments();
        if (empty($appts)) {
            $this->api->sendMessage($chatId, "📅 هیچ نوبتی رزرو نشده است.");
            return;
        }
        $text = "📅 <b>نوبت‌های رزرو‌شده</b> (" . count($appts) . " مورد)\n\n";
        foreach ($appts as $i => $a) {
            $dateLabel = preg_match('/^\d{4}-\d{2}-\d{2}$/', $a['date']) ? Keyboards::formatApptDate($a['date']) : $a['date'];
            $text .= "━━━━━━━━━━━━━━━━\n";
            $text .= ($i + 1) . ". 👤 {$a['fl_name']} | 📞 {$a['phone']}\n";
            $text .= "   📅 {$dateLabel} ⏰ {$a['time_slot']}\n";
            $text .= "   📝 " . ($a['description'] ?: '—') . "\n";
            $text .= "   🔢 کد پیگیری: {$a['tracking_code']}\n";
            $text .= "   🗓 ثبت در: {$a['created_at']}\n\n";
        }
        $this->sendTextOrFile($chatId, $text, 'appointments-list.txt', "📅 نوبت‌های رزرو‌شده (" . count($appts) . " مورد)");
    }

    // ───── لیست پرداخت‌های کاربران ────────────────────────────────
    private function listPayments(string $chatId): void
    {
        $payments = Database::getAllPayments();
        if (empty($payments)) {
            $this->api->sendMessage($chatId, "💳 هیچ پرداختی ثبت نشده است.");
            return;
        }

        // اگر تعداد کم باشد، با دکمه تأیید برای موارد در انتظار نمایش بده
        if (count($payments) <= 15) {
            foreach ($payments as $p) {
                $status = $p['payment_status'] === 'paid' ? '✅ تأییدشده' : '⏳ در انتظار تأیید';
                $price  = number_format((int)$p['price']);
                $text = "👤 {$p['fl_name']} | 📞 {$p['phone']}\n"
                      . "📖 دوره: {$p['course_title']}\n"
                      . "💰 مبلغ: {$price} تومان\n"
                      . "🔢 کد پیگیری: <code>{$p['tracking_code']}</code>\n"
                      . "وضعیت: {$status}\n"
                      . "📅 {$p['enrolled_at']}";
                $buttons = $p['payment_status'] === 'pending' ? Keyboards::paymentConfirmButton((int)$p['id']) : [];
                if (!empty($p['receipt_file_id'])) {
                    $buttons = array_merge($buttons, Keyboards::receiptViewButton((int)$p['id']));
                }
                $this->api->sendInlineMessage($chatId, $text, $buttons);
                usleep(80000);
            }
            return;
        }

        $text = "💳 <b>لیست پرداخت‌های کاربران</b> (" . count($payments) . " مورد)\n\n";
        foreach ($payments as $i => $p) {
            $status = $p['payment_status'] === 'paid' ? '✅ تأییدشده' : '⏳ در انتظار';
            $price  = number_format((int)$p['price']);
            $text .= "━━━━━━━━━━━━━━━━\n";
            $text .= ($i + 1) . ". 👤 {$p['fl_name']} | 📞 {$p['phone']}\n";
            $text .= "   📖 {$p['course_title']} | 💰 {$price} تومان\n";
            $text .= "   🔢 {$p['tracking_code']} | وضعیت: {$status}\n\n";
        }
        $this->sendTextOrFile($chatId, $text, 'payments-list.txt', "💳 لیست پرداخت‌ها (" . count($payments) . " مورد)");
    }

    // ───── تنظیمات پرداخت (روش پرداخت + شماره کارت) ────────────────
    private function showPaymentSettings(string $chatId): void
    {
        $method     = Database::getPaymentMethod();
        $methodName = match ($method) {
            'bale'  => 'درگاه آنلاین بله',
            'both'  => 'هر دو روش (کاربر خودش انتخاب می‌کند)',
            default => 'کارت‌به‌کارت (تأیید دستی)',
        };
        $cardNumber = Database::getPaymentCardNumber();
        $cardHolder = Database::getPaymentCardHolder();

        $text = "💰 <b>تنظیمات پرداخت</b>\n\n"
              . "روش فعلی: <b>{$methodName}</b>\n"
              . "💳 شماره کارت: <code>{$cardNumber}</code>\n"
              . "👤 به نام: " . ($cardHolder ?: '—');

        $this->api->sendInlineMessage($chatId, $text, Keyboards::paymentSettingsMenu($method));
    }

    private function handlePaymentCardNumber(string $chatId, string $text, bool $isOwner): void
    {
        if ($text === '❌ لغو') {
            StateManager::clear($chatId);
            $this->api->sendMessage($chatId, "❌ لغو شد.", Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1'));
            return;
        }
        $digits = preg_replace('/[^\d]/', '', $text);
        if (strlen($digits) < 16) {
            $this->api->sendMessage($chatId, "⚠️ شماره کارت باید حداقل ۱۶ رقم باشد. مجدداً وارد کنید:", Keyboards::cancelOnly());
            return;
        }
        Database::setPaymentCardNumber($text);
        StateManager::set($chatId, 'payment_card_holder');
        $this->api->sendMessage($chatId, "✅ شماره کارت ثبت شد.\n\nحالا <b>نام صاحب حساب</b> را وارد کنید:\n(یا «⏭ رد شدن» برای بدون نام)", Keyboards::skipBackCancel());
    }

    private function handlePaymentCardHolder(string $chatId, string $text, bool $isOwner): void
    {
        StateManager::clear($chatId);
        if ($text === '❌ لغو') {
            $this->api->sendMessage($chatId, "❌ لغو شد.", Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1'));
            return;
        }
        Database::setPaymentCardHolder($text === '⏭ رد شدن' ? '' : $text);
        $this->api->sendMessage($chatId, "✅ اطلاعات کارت با موفقیت به‌روزرسانی شد.", Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1'));
    }

    // ── ویرایش یکی از فیلدهای متنی/عددی یک دوره ──
    private function handleCourseEditField(string $chatId, string $text, bool $isOwner): void
    {
        $d = StateManager::getData($chatId);
        $courseId = (int)($d['edit_course_id'] ?? 0);
        $field    = (string)($d['edit_field'] ?? '');
        $column   = $this->courseFieldColumn($field);

        if ($text === '❌ لغو') {
            StateManager::clear($chatId);
            $this->api->sendMessage($chatId, "❌ لغو شد.", Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1'));
            return;
        }
        if (in_array($field, ['cap', 'price'], true) && !ctype_digit($text)) {
            $this->api->sendMessage($chatId, "⚠️ لطفاً یک عدد وارد کنید:", Keyboards::cancelOnly());
            return;
        }

        StateManager::clear($chatId);
        $ok = Database::updateCourseField($courseId, $column, $text);
        $course = Database::getCourse($courseId);
        $msg = $ok ? "✅ فیلد «{$column}» دوره «{$course['title']}» با موفقیت به‌روزرسانی شد." : "❌ خطا در به‌روزرسانی دوره.";
        $this->api->sendMessage($chatId, $msg, Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1'));
    }

    // ── ویرایش پیام تبلیغاتی یک دوره موجود ──
    private function handleCourseEditPromo(string $chatId, array $msg, string $text, bool $isOwner): void
    {
        $d = StateManager::getData($chatId);
        $courseId = (int)($d['edit_course_id'] ?? 0);

        if ($text === '❌ لغو') {
            StateManager::clear($chatId);
            $this->api->sendMessage($chatId, "❌ لغو شد.", Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1'));
            return;
        }

        if ($text === '🗑 حذف پیام تبلیغاتی') {
            Database::updateCourseField($courseId, 'promo_type', null);
            Database::updateCourseField($courseId, 'promo_content', null);
            Database::updateCourseField($courseId, 'promo_caption', null);
            StateManager::clear($chatId);
            $this->api->sendMessage($chatId, "✅ پیام تبلیغاتی این دوره حذف شد.", Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1'));
            return;
        }

        $promoType = null;
        $promoContent = null;
        $promoCaption = null;

        if (!empty($msg['photo'])) {
            $promoType    = 'photo';
            $promoContent = end($msg['photo'])['file_id'] ?? null;
            $promoCaption = $msg['caption'] ?? '';
        } elseif (!empty($msg['video'])) {
            $promoType    = 'video';
            $promoContent = $msg['video']['file_id'] ?? null;
            $promoCaption = $msg['caption'] ?? '';
        } elseif ($text !== '') {
            $promoType    = 'text';
            $promoContent = $text;
        } else {
            $this->api->sendMessage($chatId, "⚠️ لطفاً متن، عکس یا فیلم ارسال کنید:", Keyboards::removeOrCancel());
            return;
        }

        Database::updateCourseField($courseId, 'promo_type', $promoType);
        Database::updateCourseField($courseId, 'promo_content', $promoContent);
        Database::updateCourseField($courseId, 'promo_caption', $promoCaption);
        StateManager::clear($chatId);
        $this->api->sendMessage($chatId, "✅ پیام تبلیغاتی دوره با موفقیت به‌روزرسانی شد.", Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1'));
    }

    // ───── فایل کامل ثبت‌نامی‌ها ───────────────────────────────────
    private function sendRegistrantsFile(string $chatId): void
    {
        $users = Database::getAllUsers();
        if (empty($users)) {
            $this->api->sendMessage($chatId, "📋 هیچ کاربری ثبت‌نام نکرده است.");
            return;
        }
        $text = "لیست کامل ثبت‌نامی‌ها\n";
        $text .= "تعداد: " . count($users) . "\n";
        $text .= str_repeat("=", 50) . "\n\n";
        foreach ($users as $i => $u) {
            $text .= ($i + 1) . ". نام و نام خانوادگی: {$u['fl_name']}\n";
            $text .= "   شماره تلفن: {$u['phone']}\n";
            $text .= "   Chat ID: {$u['chat_id']}\n";
            $text .= "   کد ملی: " . ($u['id_card'] ?: '—') . "\n";
            $text .= "   تاریخ تولد: " . ($u['birthday'] ?: $u['birthdate']) . "\n";
            $text .= "   رشته تحصیلی: " . ($u['field_of_study'] ?: '—') . "\n";
            $text .= "   مقطع تحصیلی: " . ($u['education_level'] ?: '—') . "\n";
            $text .= "   آدرس: " . ($u['address'] ?: '—') . "\n";
            $text .= "   وضعیت: " . ($u['is_blocked'] ? 'بلاک‌شده' : 'فعال') . "\n";
            $text .= "   تاریخ ثبت‌نام: {$u['created_at']}\n";
            $text .= str_repeat("-", 50) . "\n\n";
        }

        $filename = 'registrants-full-' . date('Ymd-His') . '.txt';
        $this->sendTemporaryTextFile($chatId, $text, $filename, "📋 فایل کامل ثبت‌نامی‌ها (" . count($users) . " نفر)");
    }

    // ───── صندوق پیام‌ها ─────────────────────────────────────────
    private function showInbox(string $chatId): void
    {
        $messages = Database::getAllMessages(15);
        if (empty($messages)) {
            $this->api->sendMessage($chatId, "📭 صندوق پیام‌ها خالی است.");
            return;
        }
        foreach ($messages as $msg) {
            $readLabel  = $msg['is_read'] ? '✅' : '🔵 جدید';
            $replyLabel = $msg['reply'] ? "\n↩️ پاسخ داده شده: {$msg['reply']}" : '';
            $text = "{$readLabel} | 👤 <b>{$msg['fl_name']}</b>\n"
                  . "🆔 <code>{$msg['user_chat_id']}</code>\n"
                  . "📅 {$msg['created_at']}\n\n"
                  . "💬 {$msg['message']}"
                  . $replyLabel;

            $buttons = $msg['reply'] ? [] : [[['text' => '↩️ پاسخ دادن', 'callback_data' => "reply_msg_{$msg['id']}"]]];;
            $this->api->sendInlineMessage($chatId, $text, $buttons);
            usleep(100000);
        }
    }

    // ───── صدور گواهینامه ─────────────────────────────────────────
    private function startIssueCert(string $chatId): void
    {
        StateManager::set($chatId, 'cert_user_id');
        $this->api->sendMessage(
            $chatId,
            "🎓 <b>صدور گواهینامه</b>\n\nChat ID یا شماره تلفن کاربر موردنظر را وارد کنید:",
            Keyboards::cancelOnly()
        );
    }

    // ───── ثبت دوره جدید ─────────────────────────────────────────
    private function startAddCourse(string $chatId): void
    {
        StateManager::set($chatId, 'course_title');
        $this->api->sendMessage($chatId, "➕ <b>ثبت دوره جدید</b>\n\nعنوان دوره را وارد کنید:", Keyboards::cancelOnly());
    }

    // ───── انتشار خبر/اطلاعیه ────────────────────────────────────
    private function startPublishNews(string $chatId): void
    {
        $this->api->sendInlineMessage(
            $chatId,
            "📢 <b>انتشار محتوای جدید</b>\n\nنوع محتوا را انتخاب کنید:",
            Keyboards::newsTypeChoice()
        );
    }

    // ───── حذف دوره ──────────────────────────────────────────────
    private function startDeleteCourse(string $chatId): void
    {
        $courses = Database::getAllCourses();
        if (empty($courses)) {
            $this->api->sendMessage($chatId, "📋 هیچ دوره‌ای برای حذف وجود ندارد.");
            return;
        }
        $this->api->sendInlineMessage(
            $chatId,
            "🗑 <b>حذف دوره</b>\n\nدوره موردنظر برای حذف را انتخاب کنید:",
            Keyboards::courseDeleteList($courses)
        );
    }

    // ───── حذف خبر/اطلاعیه ────────────────────────────────────────
    private function startDeleteNews(string $chatId): void
    {
        $news = Database::getLatestNews(30);
        if (empty($news)) {
            $this->api->sendMessage($chatId, "📭 هیچ خبر یا اطلاعیه‌ای برای حذف وجود ندارد.");
            return;
        }
        $this->api->sendInlineMessage(
            $chatId,
            "🗑 <b>حذف خبر/اطلاعیه</b>\n\nمورد موردنظر برای حذف را انتخاب کنید:",
            Keyboards::newsDeleteList($news)
        );
    }

    // ───── منوی ارسال پیام (همگانی / تکی) ───────────────────────
    private function showMessagingMenu(string $chatId): void
    {
        $this->api->sendInlineMessage(
            $chatId,
            "📨 <b>ارسال پیام</b>\n\nنوع پیام را انتخاب کنید:",
            Keyboards::messagingMenu()
        );
    }

    // ───── لیست پیام‌های پاسخ‌داده‌شده (به‌صورت فایل) ─────────────
    private function sendRepliedMessagesFile(string $chatId): void
    {
        $messages = Database::getRepliedMessages();
        if (empty($messages)) {
            $this->api->sendMessage($chatId, "📭 هنوز هیچ پیامی پاسخ داده نشده است.");
            return;
        }

        $text = "لیست پیام‌های پاسخ‌داده‌شده\n";
        $text .= "تعداد: " . count($messages) . "\n";
        $text .= str_repeat("=", 40) . "\n\n";
        foreach ($messages as $i => $m) {
            $text .= ($i + 1) . ". کاربر: {$m['fl_name']} | تلفن: " . ($m['phone'] ?: '—') . " | Chat ID: {$m['user_chat_id']}\n";
            $text .= "تاریخ پیام: {$m['created_at']}\n";
            $text .= "پیام کاربر: {$m['message']}\n";
            $text .= "پاسخ ادمین ({$m['replied_by']}) در {$m['replied_at']}:\n{$m['reply']}\n";
            $text .= str_repeat("-", 40) . "\n\n";
        }

        $filename = 'replied-messages-' . date('Ymd-His') . '.txt';
        $this->sendTemporaryTextFile($chatId, $text, $filename, "📑 لیست پیام‌های پاسخ‌داده‌شده (" . count($messages) . " مورد)");
    }

    // ───── افزودن ادمین ──────────────────────────────────────────
    private function startAddAdmin(string $chatId): void
    {
        StateManager::set($chatId, 'add_admin_id');
        $this->api->sendMessage(
            $chatId,
            "👤 <b>افزودن/حذف ادمین</b>\n\nآیدی عددی (Chat ID) یا شماره تلفن کاربر را وارد کنید:\n(اگر کاربر از قبل ادمین باشد، از ادمینی خارج می‌شود)",
            Keyboards::cancelOnly()
        );
    }

    // ───── بلاک کاربر ────────────────────────────────────────────
    private function startBlockUser(string $chatId): void
    {
        StateManager::set($chatId, 'block_user_id');
        $this->api->sendMessage($chatId, "🚫 <b>بلاک/آنبلاک کاربر</b>\n\nآیدی عددی (Chat ID) یا شماره تلفن کاربر را وارد کنید:", Keyboards::cancelOnly());
    }

    // ───── مدیریت مراحل ──────────────────────────────────────────
    private function handleStep(string $chatId, string $text, string $step, array $user, bool $isOwner): void
    {
        if ($text === '❌ لغو') {
            StateManager::clear($chatId);
            $this->api->sendMessage($chatId, "❌ لغو شد.", Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1'));
            return;
        }

        // ── پاسخ به کاربر ──
        if (str_starts_with($step, 'admin_reply_')) {
            $this->handleAdminReply($chatId, $text, $step, $isOwner);
            return;
        }

        match (true) {
            // ── دوره ──
            $step === 'course_title' => $this->handleCourseTitle($chatId, $text),
            $step === 'course_desc'  => $this->handleCourseDesc($chatId, $text),
            $step === 'course_cap'   => $this->handleCourseCapacity($chatId, $text),
            $step === 'course_price' => $this->handleCoursePrice($chatId, $text),
            $step === 'course_start' => $this->handleCourseStart($chatId, $text),
            $step === 'course_end'   => $this->handleCourseEnd($chatId, $text, $isOwner),

            // ── خبر ──
            $step === 'news_title'   => $this->handleNewsTitle($chatId, $text),
            $step === 'news_content' => $this->handleNewsContent($chatId, $text, $isOwner),

            // ── پیام همگانی ──
            $step === 'broadcast_text' => $this->handleBroadcast($chatId, $text, $isOwner),

            // ── پیام تکی ──
            $step === 'single_msg_target' => $this->handleSingleMsgTarget($chatId, $text, $isOwner),
            $step === 'single_msg_text'   => $this->handleSingleMsgText($chatId, $text, $isOwner),

            // ── افزودن ادمین ──
            $step === 'add_admin_id' => $this->handleAddAdmin($chatId, $text, $isOwner),

            // ── بلاک ──
            $step === 'block_user_id' => $this->handleBlockUser($chatId, $text, $isOwner),

            // ── گواهینامه ──
            $step === 'cert_user_id'  => $this->handleCertUserId($chatId, $text),
            $step === 'cert_title'    => $this->handleCertTitle($chatId, $text),
            $step === 'cert_date'     => $this->handleCertDate($chatId, $text, $isOwner),

            // ── تنظیمات پرداخت ──
            $step === 'payment_card_number' => $this->handlePaymentCardNumber($chatId, $text, $isOwner),
            $step === 'payment_card_holder' => $this->handlePaymentCardHolder($chatId, $text, $isOwner),

            // ── ویرایش دوره ──
            $step === 'course_edit_field' => $this->handleCourseEditField($chatId, $text, $isOwner),

            default => null,
        };
    }

    // ── مراحل دوره ──
    private function handleCourseTitle(string $chatId, string $text): void
    {
        StateManager::set($chatId, 'course_desc', ['title' => $text]);
        $this->api->sendMessage($chatId, "توضیحات دوره را وارد کنید:", Keyboards::cancelOnly());
    }
    private function handleCourseDesc(string $chatId, string $text): void
    {
        StateManager::set($chatId, 'course_promo', ['description' => $text]);
        $this->api->sendMessage(
            $chatId,
            "📣 <b>پیام تبلیغاتی دوره</b>\n\nیک پیام (متن، یا عکس/فیلم همراه با کپشن) ارسال کنید تا وقتی کاربر روی عنوان این دوره بزند، اول این پیام و بعد توضیحات و دکمه خرید نشان داده شود.\n\n(برای رد شدن، «⏭ رد شدن» را بزنید)",
            Keyboards::skipOrCancel()
        );
    }

    // ── دریافت پیام تبلیغاتی دوره (متن یا رسانه با کپشن) ──
    private function handleCoursePromo(string $chatId, array $msg, string $text): void
    {
        if ($text === '❌ لغو') {
            StateManager::clear($chatId);
            $this->api->sendMessage($chatId, "❌ لغو شد.");
            return;
        }

        $promoType = null;
        $promoContent = null;
        $promoCaption = null;

        if ($text === '⏭ رد شدن') {
            // بدون پیام تبلیغاتی
        } elseif (!empty($msg['photo'])) {
            $promoType    = 'photo';
            $promoContent = end($msg['photo'])['file_id'] ?? null;
            $promoCaption = $msg['caption'] ?? '';
        } elseif (!empty($msg['video'])) {
            $promoType    = 'video';
            $promoContent = $msg['video']['file_id'] ?? null;
            $promoCaption = $msg['caption'] ?? '';
        } elseif ($text !== '') {
            $promoType    = 'text';
            $promoContent = $text;
        } else {
            $this->api->sendMessage($chatId, "⚠️ لطفاً متن، عکس یا فیلم ارسال کنید، یا «⏭ رد شدن» را بزنید:", Keyboards::skipOrCancel());
            return;
        }

        StateManager::set($chatId, 'course_cap', [
            'promo_type'    => $promoType,
            'promo_content' => $promoContent,
            'promo_caption' => $promoCaption,
        ]);
        $this->api->sendMessage($chatId, "ظرفیت دوره (عدد) را وارد کنید:", Keyboards::cancelOnly());
    }
    private function handleCourseCapacity(string $chatId, string $text): void
    {
        if (!ctype_digit($text)) { $this->api->sendMessage($chatId, "⚠️ لطفاً یک عدد وارد کنید:"); return; }
        StateManager::set($chatId, 'course_price', ['capacity' => (int)$text]);
        $this->api->sendMessage($chatId, "💰 هزینه دوره را به تومان وارد کنید (برای رایگان عدد 0 بزنید):", Keyboards::cancelOnly());
    }
    private function handleCoursePrice(string $chatId, string $text): void
    {
        if (!ctype_digit($text)) { $this->api->sendMessage($chatId, "⚠️ لطفاً عدد وارد کنید:"); return; }
        StateManager::set($chatId, 'course_start', ['price' => (int)$text]);
        $this->api->sendMessage($chatId, "تاریخ شروع دوره را وارد کنید (مثال: ۱۴۰۳/۰۷/۰۱):", Keyboards::cancelOnly());
    }
    private function handleCourseStart(string $chatId, string $text): void
    {
        StateManager::set($chatId, 'course_end', ['start_date' => $text]);
        $this->api->sendMessage($chatId, "تاریخ پایان دوره را وارد کنید:", Keyboards::cancelOnly());
    }
    private function handleCourseEnd(string $chatId, string $text, bool $isOwner): void
    {
        $d = StateManager::getData($chatId);
        StateManager::clear($chatId);
        $ok  = Database::createCourse(
            $d['title'], $d['description'], $d['capacity'], $d['price'] ?? 0, $d['start_date'], $text,
            $d['promo_type'] ?? null, $d['promo_content'] ?? null, $d['promo_caption'] ?? null
        );
        $msg = $ok ? "✅ دوره «{$d['title']}» با موفقیت ثبت شد!" : "❌ خطا در ثبت دوره.";
        $this->api->sendMessage($chatId, $msg, Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1'));
    }

    // ── مراحل خبر ──
    private function handleNewsTitle(string $chatId, string $text): void
    {
        $d = StateManager::getData($chatId);
        $type  = $d['news_type'] ?? 'news';
        $label = $type === 'announcement' ? 'اطلاعیه' : 'خبر';
        StateManager::set($chatId, 'news_content', ['title' => $text]);
        $this->api->sendMessage($chatId, "متن {$label} را وارد کنید:", Keyboards::cancelOnly());
    }
    private function handleNewsContent(string $chatId, string $text, bool $isOwner): void
    {
        $d = StateManager::getData($chatId);
        StateManager::clear($chatId);
        $type  = $d['news_type'] ?? 'news';
        $label = $type === 'announcement' ? 'اطلاعیه' : 'خبر';
        Database::createNews($d['title'], $text, $chatId, $type);
        $this->api->sendMessage($chatId, "✅ {$label} با موفقیت منتشر شد!", Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1'));
    }

    // ── پیام همگانی ──
    private function handleBroadcast(string $chatId, string $text, bool $isOwner): void
    {
        StateManager::clear($chatId);
        $broadText = $text;
        $users     = Database::getAllUsers();
        $chatIds   = array_values(array_filter(array_map(
            static fn($u) => empty($u['is_blocked']) ? trim((string)($u['chat_id'] ?? '')) : '',
            $users
        )));
        $this->api->sendMessage($chatId, "⏳ در حال ارسال به " . count($chatIds) . " کاربر...");
        $res = $this->api->broadcast($chatIds, $broadText);
        $this->api->sendMessage(
            $chatId,
            "📣 پیام همگانی تمام شد!\n✅ موفق: {$res['sent']}\n❌ ناموفق: {$res['failed']}",
            Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1')
        );
    }

    // ── پیام تکی: مرحله ۱ — یافتن کاربر ──
    private function handleSingleMsgTarget(string $chatId, string $text, bool $isOwner): void
    {
        $target = Database::resolveUserIdentifier($text);
        if (!$target) {
            $this->api->sendMessage($chatId, "❌ کاربری با این آیدی/شماره تلفن یافت نشد. مجدداً وارد کنید:", Keyboards::cancelOnly());
            return;
        }
        StateManager::set($chatId, 'single_msg_text', [
            'single_target_chat_id' => (string)$target['chat_id'],
            'single_target_name'    => $target['fl_name'],
        ]);
        $this->api->sendMessage(
            $chatId,
            "👤 کاربر: <b>{$target['fl_name']}</b>\n🆔 <code>{$target['chat_id']}</code>\n\nمتن پیام را بنویسید:",
            Keyboards::cancelOnly()
        );
    }

    // ── پیام تکی: مرحله ۲ — ارسال پیام ──
    private function handleSingleMsgText(string $chatId, string $text, bool $isOwner): void
    {
        $d = StateManager::getData($chatId);
        StateManager::clear($chatId);
        $targetId = $d['single_target_chat_id'] ?? null;
        $name     = $d['single_target_name'] ?? '';

        if (!$targetId) {
            $this->api->sendMessage($chatId, "❌ خطا در یافتن کاربر.", Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1'));
            return;
        }

        $this->api->sendMessage($targetId, "📩 <b>پیام از مدیریت:</b>\n\n{$text}");
        $this->api->sendMessage(
            $chatId,
            "✅ پیام برای <b>{$name}</b> ارسال شد.",
            Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1')
        );
    }

    // ── افزودن ادمین ──
    private function handleAddAdmin(string $chatId, string $input, bool $isOwner): void
    {
        StateManager::clear($chatId);

        $target = Database::resolveUserIdentifier($input);
        $newAdminId = $target['chat_id'] ?? null;

        if (!$newAdminId) {
            $this->api->sendMessage(
                $chatId,
                "❌ کاربر متصل به سایت پیدا نشد. ابتدا باید حساب بله او به حساب کاربری سایت وصل شود.",
                Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1')
            );
            return;
        }

        $name = $target['fl_name'] ?? null;
        $who  = $name ? "{$name} (<code>{$newAdminId}</code>)" : "<code>{$newAdminId}</code>";

        // اگر این فرد مالک ربات است، نمی‌توان او را از ادمینی خارج کرد
        if (Database::isOwner((string)$newAdminId)) {
            $this->api->sendMessage(
                $chatId,
                "❌ نمی‌توانید مالک ربات را از حالت ادمین خارج کنید.",
                Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1')
            );
            return;
        }

        // اگر از قبل ادمین است → حذف از ادمینی (toggle)
        if (Database::isAdmin((string)$newAdminId)) {
            $removed = Database::removeAdmin((string)$newAdminId);
            $msg = $removed ? "✅ {$who} از ادمینی خارج شد." : "❌ خطا در حذف ادمین.";
            $this->api->sendMessage($chatId, $msg, Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1'));

            if ($removed) {
                $this->api->sendMessage(
                    (string)$newAdminId,
                    "ℹ️ <b>اطلاع‌رسانی</b>\n\nدسترسی مدیریت شما در ربات لغو شد و دیگر به پنل مدیریت دسترسی ندارید.",
                    Keyboards::userMain()
                );
            }
            return;
        }

        // در غیر این صورت → افزودن به ادمینی
        $ok  = Database::addAdmin((string)$newAdminId, $chatId);
        $msg = $ok ? "✅ ادمین جدید اضافه شد: {$who}" : "⚠️ خطا در افزودن ادمین.";
        $this->api->sendMessage($chatId, $msg, Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1'));

        if ($ok) {
            $this->api->sendMessage(
                (string)$newAdminId,
                "🎉🥳 <b>تبریک!</b>\n\n"
                . "شما به‌عنوان <b>ادمین جدید</b> ربات منصوب شدید! ✨\n"
                . "از این پس به پنل مدیریت دسترسی دارید و می‌توانید دوره‌ها، اخبار و اطلاعیه‌ها، کاربران، نوبت‌دهی و پیام‌های کاربران را مدیریت کنید.\n\n"
                . "برای شروع، از منوی پایین گزینه «⚙️ پنل مدیریت» را انتخاب کنید 👇",
                Keyboards::adminMain(false)
            );
        }
    }

    // ── بلاک کاربر ──
    private function handleBlockUser(string $chatId, string $input, bool $isOwner): void
    {
        StateManager::clear($chatId);
        $target = Database::resolveUserIdentifier($input);
        if (!$target) {
            $this->api->sendMessage($chatId, "❌ کاربر یافت نشد.", Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1'));
            return;
        }
        $newStatus = $target['is_blocked'] ? 0 : 1;
        Database::blockUser((string)$target['chat_id'], $newStatus);
        $label = $newStatus ? "🚫 بلاک شد" : "✅ آنبلاک شد";
        $this->api->sendMessage(
            $chatId,
            "کاربر <b>{$target['fl_name']}</b> {$label}.",
            Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1')
        );
    }

    // ── پاسخ ادمین به کاربر ──
    private function handleAdminReply(string $chatId, string $text, string $step, bool $isOwner): void
    {
        $data     = StateManager::getData($chatId);
        $msgId    = (int)str_replace('admin_reply_', '', $step);
        $targetId = $data['target_chat_id'] ?? null;

        StateManager::clear($chatId);

        if (!$targetId) {
            $this->api->sendMessage($chatId, "❌ خطا در یافتن کاربر.", Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1'));
            return;
        }

        Database::replyToMessage($msgId, $text, $chatId);
        Database::openOrCreateChat((int)$targetId);

        // ارسال پاسخ به کاربر همراه با گزینه‌های تعاملی ادامه گفتگو
        $this->api->sendInlineMessage(
            $targetId,
            "📩 <b>پاسخ از مدیریت:</b>\n\n{$text}",
            Keyboards::contactReplyOptions()
        );

        // تأیید به ادمین همراه با دکمه بستن چت
        $this->api->sendInlineMessage(
            $chatId,
            "✅ پاسخ با موفقیت ارسال شد.",
            Keyboards::adminCloseChat((string)$targetId)
        );
    }

    // ── مراحل گواهینامه ──
    private function handleCertUserId(string $chatId, string $text): void
    {
        $target = Database::resolveUserIdentifier($text);
        if (!$target) {
            $this->api->sendMessage($chatId, "❌ کاربری با این Chat ID/شماره تلفن یافت نشد. مجدداً وارد کنید:", Keyboards::cancelOnly());
            return;
        }
        StateManager::set($chatId, 'cert_title', [
            'cert_user_chat_id' => (string)$target['chat_id'],
            'cert_user_name'    => $target['fl_name'],
        ]);
        $this->api->sendMessage(
            $chatId,
            "👤 کاربر: <b>{$target['fl_name']}</b>\n\nعنوان گواهینامه را وارد کنید:\nمثال: گواهینامه شرکت در دوره Python مقدماتی",
            Keyboards::cancelOnly()
        );
    }

    private function handleCertTitle(string $chatId, string $text): void
    {
        StateManager::set($chatId, 'cert_date', ['cert_title' => $text]);
        $today = date('Y/m/d');
        $this->api->sendMessage(
            $chatId,
            "تاریخ صدور گواهینامه را وارد کنید:\nمثال: ۱۴۰۳/۰۷/۰۱\n\n(یا عبارت <b>امروز</b> برای تاریخ {$today})",
            Keyboards::cancelOnly()
        );
    }

    private function handleCertDate(string $chatId, string $text, bool $isOwner): void
    {
        $issueDate = ($text === 'امروز') ? date('Y/m/d') : $text;
        StateManager::set($chatId, 'cert_pdf_wait', ['cert_issue_date' => $issueDate]);
        $this->api->sendInlineMessage(
            $chatId,
            "📅 تاریخ صدور: <b>{$issueDate}</b>\n\nآیا می‌خواهید فایل PDF گواهینامه را همراه آن برای کاربر ارسال کنید؟",
            Keyboards::certPdfChoice()
        );
    }

    // ── دریافت فایل PDF گواهینامه از ادمین ──
    private function handleCertPdfUpload(string $chatId, array $document, bool $isOwner): void
    {
        $fileId = $document['file_id'] ?? null;
        $mime   = $document['mime_type'] ?? '';
        $name   = $document['file_name'] ?? '';

        if (!$fileId) {
            $this->api->sendMessage($chatId, "❌ دریافت فایل ناموفق بود. مجدداً ارسال کنید:", Keyboards::cancelOnly());
            return;
        }
        if ($mime && $mime !== 'application/pdf' && !str_ends_with(strtolower($name), '.pdf')) {
            $this->api->sendMessage($chatId, "⚠️ لطفاً فقط فایل با فرمت PDF ارسال کنید:", Keyboards::cancelOnly());
            return;
        }

        $this->finalizeCertificate($chatId, $isOwner, $fileId, $name);
    }

    // ── نهایی‌سازی صدور گواهینامه (با یا بدون PDF) ──
    private function finalizeCertificate(string $chatId, bool $isOwner, ?string $pdfFileId, string $fileName = ''): void
    {
        $d = StateManager::getData($chatId);
        $attachmentId = 0;
        if ($pdfFileId) {
            $uploaded = MediaSync::transfer($this->api, $pdfFileId, 'certificate', 0, $fileName, 10 * 1024 * 1024);
            if (!$uploaded || empty($uploaded['attachment_id'])) {
                $this->api->sendMessage($chatId, "❌ انتقال PDF به رسانه سایت انجام نشد؛ فایل PDF معتبر و کوچک‌تر از ۱۰ مگابایت بفرستید:", Keyboards::cancelOnly());
                return;
            }
            $attachmentId = (int)$uploaded['attachment_id'];
        }
        StateManager::clear($chatId);

        $issueDate = $d['cert_issue_date'] ?? date('Y/m/d');
        $certNum   = Database::issueCertificate(
            (int)$d['cert_user_chat_id'],
            null,
            $d['cert_title'],
            $issueDate,
            $chatId,
            $pdfFileId,
            $attachmentId
        );

        if ($certNum) {
            // اطلاع به کاربر
            $this->api->sendMessage(
                $d['cert_user_chat_id'],
                "🎓 <b>گواهینامه صادر شد!</b>\n\n"
                . "📜 عنوان: {$d['cert_title']}\n"
                . "🔢 شماره: <code>{$certNum}</code>\n"
                . "📅 تاریخ: {$issueDate}\n\n"
                . "تبریک! 🎉"
            );
            if ($pdfFileId) {
                $this->api->sendDocument($d['cert_user_chat_id'], $pdfFileId, "📄 فایل گواهینامه: {$certNum}");
            }
            $this->api->sendMessage(
                $chatId,
                "✅ گواهینامه با شماره <code>{$certNum}</code> برای <b>{$d['cert_user_name']}</b> صادر و ارسال شد."
                . ($pdfFileId ? "\n📎 فایل PDF نیز برای کاربر ارسال شد." : ""),
                Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1')
            );
        } else {
            $this->api->sendMessage($chatId, "❌ خطا در صدور گواهینامه.", Keyboards::adminPanel($isOwner, Database::getSetting('bot_active') === '1'));
        }
    }

    private function backToMain(string $chatId, array $user, bool $isOwner): void
    {
        $userHandler = new UserHandler($this->api);
        $userHandler->sendMainMenu($chatId, $user);
    }
}
