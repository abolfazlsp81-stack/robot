<?php
// config/config.php
// هیچ کلید محرمانه‌ای را در این فایل عمومی/ZIP قرار ندهید.

declare(strict_types=1);

$env = static function (string $name, string $default = ''): string {
    $value = getenv($name);
    return $value === false ? $default : trim((string) $value);
};

$config = [
    'bot_token' => $env('BALE_BOT_TOKEN'),
    'api_base' => $env('BALE_API_BASE', 'https://tapi.bale.ai/bot'),
    'payment_token' => $env('BALE_PAYMENT_TOKEN'),
    // منبع یکتای اطلاعات ربات: سایت وردپرسی دارای Modern Profile Hub.
    'site_url' => $env('MPH_SITE_URL'),
    'site_sync_secret' => $env('MPH_SITE_SYNC_SECRET'),
    'site_connect_timeout' => 5,
    'site_timeout' => 20,
    // پایداری زیر فشار (SiteGate): حداکثر تماس هم‌زمان با سایت، مهلت صف، تعداد تلاش و قطع‌کننده
    'site_max_concurrent' => 4,
    'site_queue_wait' => 8,
    'site_max_attempts' => 3,
    'site_retry_budget' => 10,
    'site_circuit_threshold' => 5,
    'site_circuit_cooldown' => 6,

    // این مقدار ۳۲ کاراکتری یا بلندتر باید در URL وب‌هوک با ?key=... قرار بگیرد.
    'webhook_secret' => $env('BALE_WEBHOOK_SECRET'),
    'debug' => filter_var($env('BALE_DEBUG', '0'), FILTER_VALIDATE_BOOLEAN),

    'messages' => [
        'welcome_new' => "👋 سلام! برای استفاده از ربات، حساب بله خود را به حساب سایت متصل کنید.",
        'bot_off' => "🔴 ربات در حال حاضر غیرفعال است.\nلطفاً بعداً مراجعه کنید.",
        'blocked' => "🚫 دسترسی شما به ربات مسدود شده است.\nبرای اطلاعات بیشتر با پشتیبانی تماس بگیرید.",
        'registered_ok' => "✅ حساب شما با سایت همگام شد.",
        'not_registered' => "⚠️ حساب بله شما هنوز به سایت متصل نشده است.",
        'site_unavailable' => "⚠️ سایت دیر پاسخ داد. چند ثانیه بعد دوباره بزنید.",
        'site_busy' => "⏳ درخواست‌ها در این لحظه زیاد است؛ چند ثانیه صبر کنید و دوباره بزنید.",
        'queued' => "⏳ سایت لحظه‌ای شلوغ است؛ درخواست شما ثبت شد و به‌زودی خودکار انجام می‌شود.",
        'busy_prev' => "⏳ درخواست قبلی شما هنوز در حال انجام است…",
    ],
];

// برای هاست‌هایی که Environment Variable ندارند، config/local.php بسازید.
$localFile = __DIR__ . '/local.php';
if (is_file($localFile)) {
    $local = require $localFile;
    if (is_array($local)) {
        $config = array_replace_recursive($config, $local);
    }
}

return $config;
