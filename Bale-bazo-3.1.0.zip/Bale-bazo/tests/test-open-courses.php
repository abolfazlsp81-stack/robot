<?php
// آزمون «دوره‌های در حال ثبت‌نام»، کش، نشان ↗ و لینک بخش‌های سایت (بدون شبکه).
declare(strict_types=1);
define('BASE_DIR', dirname(__DIR__));
require dirname(__DIR__) . '/helpers/BaleText.php';
require dirname(__DIR__) . '/helpers/Cache.php';
require dirname(__DIR__) . '/helpers/Keyboards.php';
class SiteSyncException extends RuntimeException { public int $st = 503; public string $rc = 'network_error'; public function getStatus(): int { return $this->st; } public function getRemoteCode(): string { return $this->rc; } }
class SiteClient {
    public static array $calls = []; public static array $reply = []; public static bool $fail = false; public static string $actor = '555';
    public static function call(string $method, array $params = [], bool $cache = false) {
        self::$calls[] = $method; if (self::$fail) throw new SiteSyncException('x');
        if (!isset(self::$reply[$method])) { $e = new SiteSyncException('missing'); $e->st = 404; $e->rc = 'method_not_allowed'; throw $e; }
        return self::$reply[$method];
    }
    public static function actorChatId(): string { return self::$actor; }
    public static function userMessage($e, array $m, bool $q = false): string { return 'MSG'; }
}
class BaleApi {
    public array $log = [];
    public function editMessageText($c, $m, $t, $k = []) { $this->log[] = ['edit', $m, $t, $k]; return ['ok' => true]; }
    public function sendInlineMessage($c, $t, $k = []) { $this->log[] = ['send', 0, $t, $k]; return ['ok' => true]; }
    public function sendMessage($c, $t, $k = []) { return $this->sendInlineMessage($c, $t, $k); }
    public function answerCallbackQuery($id, $t = '', $a = false) { $this->log[] = ['answer', $id, $t, $a]; return ['ok' => true]; }
}
class NativeHandler { public static array $cb = []; public function __construct($api) {} public function callback($chat, $data) { self::$cb[] = $data; return true; } }
require dirname(__DIR__) . '/database/Database.php';
require dirname(__DIR__) . '/handlers/OpenCoursesHandler.php';
require dirname(__DIR__) . '/handlers/MyCoursesHandler.php';
$n = 0; function check($v, $m) { global $n; $n++; if (!$v) throw new RuntimeException($m); }

Cache::$disableApcu = true;
$tmp = sys_get_temp_dir() . '/bb3-test-' . bin2hex(random_bytes(4)); mkdir($tmp, 0700); Cache::reset($tmp);

// کش
Cache::set('k', ['a' => 1], 30); Cache::reset($tmp);
check(Cache::get('k') === ['a' => 1], 'file cache round trip');
Cache::set('short', 1, 1); Cache::reset($tmp); sleep(2); check(Cache::get('short') === null, 'expired cache entry is ignored');
Cache::forget('k'); check(Cache::get('k') === null, 'forget works');
check((fileperms($tmp) & 0777) === 0700, 'cache dir is private');

// داده
$course = ['id' => 100, 'title' => 'دورهٔ تست', 'excerpt' => 'توضیح کوتاه', 'url' => 'https://s.test/c/100', 'start_date' => '1405/08/01', 'end_date' => '', 'min_price' => 900000, 'enrolled' => false,
  'modes' => [['mode' => 'online', 'label' => 'آنلاین', 'product_id' => 12, 'price' => 2000000, 'full' => false, 'remaining' => 7], ['mode' => 'inperson', 'label' => 'حضوری', 'product_id' => 11, 'price' => 5000000, 'full' => true, 'remaining' => 0, 'start' => 'شنبه ۱۰', 'address' => 'تهران'], ['mode' => 'offline', 'label' => 'آفلاین', 'product_id' => 13, 'price' => 0, 'full' => false, 'remaining' => null]]];
$many = []; for ($i = 1; $i <= 14; $i++) $many[] = array_merge($course, ['id' => 200 + $i, 'title' => 'دوره ' . $i, 'enrolled' => $i === 2]);
SiteClient::$reply['openCourses'] = ['items' => array_merge([$course], $many), 'archive_url' => 'https://s.test/courses/'];

$api = new BaleApi(); $h = new OpenCoursesHandler($api);
$h->show('555');
check(SiteClient::$calls === ['openCourses'], 'list needs exactly one site request');
[$kind, , $text, $kb] = $api->log[0];
check($kind === 'send' && strpos($text, '15 دوره') !== false, 'list message counts courses');
check(count(array_filter($kb, fn($r) => isset($r[0]['callback_data']) && strpos($r[0]['callback_data'], 'oc:d:') === 0)) === 6, 'first page has 6 courses');
$flat = array_merge(...$kb);
check(in_array('oc:l:2', array_column($flat, 'callback_data'), true), 'pagination next present');
check(in_array('https://s.test/courses/', array_column($flat, 'url'), true), 'site archive link present');
foreach ($flat as $b) check(strlen($b['callback_data'] ?? '') <= 64, 'callback_data within 64 bytes');

// کش: بار دوم بدون تماس با سایت
SiteClient::$calls = []; $api->log = [];
$h->callback('555', 77, 'oc:l:2', 'cb1');
check(SiteClient::$calls === [], 'second view comes from the 30s cache');
check($api->log[0][0] === 'edit' && $api->log[0][1] === 77, 'navigation edits the same message');
$h->callback('555', 77, 'oc:d:100:2', 'cb2');
check(SiteClient::$calls === [], 'detail needs no site request');
[, , $dt, $dk] = $api->log[1];
check(strpos($dt, 'آنلاین — 2,000,000 تومان — 7 جای خالی') !== false && strpos($dt, 'ظرفیت تکمیل') !== false && strpos($dt, 'رایگان') !== false, 'detail shows prices, seats, full and free');
$dflat = array_merge(...$dk); $cbs = array_column($dflat, 'callback_data');
check(in_array('oc:b:12', $cbs, true) && in_array('oc:b:13', $cbs, true) && !in_array('oc:b:11', $cbs, true), 'only open modes can be bought');
check(in_array('oc:l:2', $cbs, true), 'back goes to the right page');
check(in_array('https://s.test/c/100', array_column($dflat, 'url'), true), 'course page link present');
$txt = $h->detailText(array_merge($course, ['enrolled' => true])); check(strpos($txt, 'ثبت‌نام کرده‌اید') !== false, 'enrolled badge');
check(in_array('noop', array_column(array_merge(...$h->detailKeyboard(array_merge($course, ['enrolled' => true]), 1)), 'callback_data'), true), 'enrolled user gets no buy button');

// خرید
$api->log = []; NativeHandler::$cb = [];
$h->callback('555', 77, 'oc:b:12', 'cb3');
check(NativeHandler::$cb === ['n:add:12'], 'buy adds the product to the site cart through the existing flow');
$h->callback('555', 77, 'oc:b:11', 'cb4');
check(NativeHandler::$cb === ['n:add:12'] && end($api->log)[0] === 'answer' && end($api->log)[3] === true, 'full mode shows an alert and does not add');
Cache::reset($tmp); SiteClient::$calls = [];
$h->callback('555', 77, 'oc:d:9999:1', 'cb5');
check(strpos(end($api->log)[2], 'دیگر برای ثبت‌نام باز نیست') !== false, 'closed course explained');

// فهرست خالی و خطا
Cache::reset($tmp); foreach (glob("$tmp/*") as $f) unlink($f); SiteClient::$reply['openCourses'] = ['items' => []]; $api->log = [];
$h->show('555', 1, 5, true); check(strpos(end($api->log)[2], 'دوره‌ای برای ثبت‌نام باز نیست') !== false, 'empty list message');
SiteClient::$fail = true; $api->log = [];
// خطا + فهرست ذخیره‌شدهٔ قبلی → فهرست قدیمی با هشدار (نه شکست)
Cache::reset($tmp); foreach (glob("$tmp/*") as $f) unlink($f);
SiteClient::$fail = false; SiteClient::$reply['openCourses'] = ['items' => [$course], 'archive_url' => '']; Database::openCourses(true);
Cache::forget('oc:555'); SiteClient::$fail = true;
$h->show('555', 1, 5, false); check(strpos(end($api->log)[2], 'چند دقیقه پیش ذخیره شده') !== false, 'when the site fails the last good list is shown with a warning');
Cache::forget('ocs:555'); Cache::forget('oc:555'); $api->log = []; $h->show('555', 1, 5, true); check(strpos(end($api->log)[2], 'سایت دیر پاسخ') !== false, 'site failure is explained, not silent');
SiteClient::$fail = false;
// افزونهٔ قدیمی (متد وجود ندارد) → null
unset(SiteClient::$reply['openCourses']); foreach (glob("$tmp/*") as $f) unlink($f); Cache::reset($tmp);
check(Database::openCourses(true) === null, 'old plugin returns null (legacy list is used)');

// منو
$user = ['id' => 1, 'chat_id' => '555', 'fl_name' => 'x', 'active_mode' => 'user', 'modes' => [['id' => 'user', 'title' => 'کاربر']],
  'menu_items' => [['id' => 'profile', 'title' => 'نمایه من', 'url' => ''], ['id' => 'my_exams', 'title' => 'آزمون‌های من', 'url' => ''], ['id' => 'forum_x', 'title' => 'یک بخش تازهٔ سایت', 'url' => '']]];
Keyboards::setUserContext($user);
$labels = array_merge(...array_map(fn($r) => array_column($r, 'text'), Keyboards::userMain()));
check($labels[0] === OpenCoursesHandler::LABEL && $labels[0] === Keyboards::OPEN_COURSES, 'open-courses button is first');
$p = array_values(array_filter($labels, fn($l) => strpos($l, 'نمایه من') !== false)); check(count($p) === 1 && strpos($p[0], '↗') === false, 'native panel has no link mark');
$q = array_values(array_filter($labels, fn($l) => strpos($l, 'آزمون') !== false)); check(count($q) === 1 && strpos($q[0], '↗') !== false, 'site-only panel is marked ↗');
$r = array_values(array_filter($labels, fn($l) => strpos($l, 'تازه') !== false)); check(count($r) === 1 && strpos($r[0], '↗') !== false, 'new site components become links automatically');
check(Keyboards::resolveSiteSelection($q[0])['id'] === 'my_exams', 'marked label resolves to its panel');
check(Keyboards::resolveSiteSelection(Keyboards::OPEN_COURSES)['type'] === 'open_courses', 'button resolves');

// panelLink
SiteClient::$reply['panelLink'] = ['url' => 'https://s.test/?mph_bale_login=' . str_repeat('a', 48), 'target' => 'https://s.test/account/', 'login' => true];
$pl = Database::panelLink('user', 'my_exams'); check($pl && $pl['login'] === true, 'panelLink parsed');
SiteClient::$reply['panelLink'] = []; check(Database::panelLink('user', 'x') === null, 'empty link answer -> null (fallback used)');

// ── منوی ربات = منوی سایت (گروه‌ها، بدون پیشخوان) ──
$tree = [
  ['id' => 'dashboard', 'title' => 'پیشخوان', 'emoji' => '🏠', 'type' => 'panel', 'mode' => 'user', 'url' => ''],
  ['id' => 'profile', 'title' => 'نمایه من', 'emoji' => '👤', 'type' => 'panel', 'mode' => 'user', 'url' => ''],
  ['id' => 'grp_my_courses', 'title' => 'دوره‌های من', 'emoji' => '📚', 'hint' => 'آنلاین، آفلاین، حضوری', 'type' => 'group', 'children' => [
      ['id' => 'online_courses', 'title' => 'دوره‌های آنلاین', 'emoji' => '💻', 'mode' => 'user', 'url' => ''],
      ['id' => 'dashboard', 'title' => 'پیشخوان', 'emoji' => '🏠', 'mode' => 'user'],
      ['id' => 'my_exams', 'title' => 'آزمون‌های من', 'emoji' => '📝', 'mode' => 'user', 'url' => 'https://s.test/x']]],
  ['id' => 'grp_gone', 'title' => 'فقط پیشخوان', 'children' => [['id' => 'dashboard', 'title' => 'پیشخوان']]],
  ['id' => 'reminders', 'title' => 'یادآوری‌ها', 'emoji' => '⏰', 'type' => 'panel', 'mode' => 'user', 'url' => ''],
];
$ctx = ['id' => 1, 'chat_id' => '555', 'fl_name' => 'x', 'active_mode' => 'user', 'modes' => [['id' => 'user', 'title' => 'کاربر']], 'menu_tree' => $tree, 'menu_items' => []];
Keyboards::setUserContext($ctx);
$kb = Keyboards::userMain(); $all = array_merge(...array_map(fn($r) => array_column($r, 'text'), $kb));
check(!array_filter($all, fn($l) => strpos($l, 'پیشخوان') !== false), 'the dashboard button is gone from the bot menu');
check($all === [OpenCoursesHandler::LABEL, '🎭 نقش‌ها', '👤 نمایه من', '📚 دوره‌های من', '⏰ یادآوری‌ها ↗'], 'menu = site order: ' . implode(' | ', $all));
$g = Keyboards::resolveSiteSelection('📚 دوره‌های من');
check($g['type'] === 'group' && $g['id'] === 'grp_my_courses', 'group label resolves to a group');
$gk = Keyboards::groupKeyboard(Keyboards::findEntry('grp_my_courses')['entry']);
check(array_column(array_merge(...$gk), 'callback_data') === ['mp:online_courses', 'mp:my_exams', 'back_main'], 'group page lists children (no dashboard) with mp: callbacks');
check(array_column(array_merge(...$gk), 'text')[0] === '💻 دوره‌های آنلاین' && array_column(array_merge(...$gk), 'text')[1] === '📝 آزمون‌های من ↗', 'native children plain, site-only children marked ↗');
check(Keyboards::findEntry('dashboard') === null && Keyboards::findEntry('nope') === null, 'dashboard and unknown ids cannot be opened via callbacks');
check(Keyboards::findEntry('my_exams')['url'] === 'https://s.test/x' && Keyboards::findEntry('my_exams')['type'] === 'panel', 'child resolves to a panel selection');
// افزونهٔ قدیمی (فقط فهرست تخت) هم داشبورد را نشان نمی‌دهد
Keyboards::setUserContext(array_merge($ctx, ['menu_tree' => null, 'menu_items' => [['id' => 'dashboard', 'title' => 'پیشخوان'], ['id' => 'profile', 'title' => 'نمایه من', 'emoji' => '👤']]]));
check(array_merge(...array_map(fn($r) => array_column($r, 'text'), Keyboards::userMain())) === [OpenCoursesHandler::LABEL, '🎭 نقش‌ها', '👤 نمایه من'], 'legacy flat menu also hides the dashboard');

// ── دوره‌های من ──
SiteClient::$reply['myCourses'] = ['items' => array_map(fn($i) => ['course_id' => $i, 'title' => 'دورهٔ ' . $i, 'delivery_mode' => $i % 2 ? 'online' : 'offline', 'delivery_label' => $i % 2 ? 'آنلاین' : 'آفلاین', 'payment_status' => $i === 1 ? 'pending' : 'paid', 'start_date' => '1405/08/0' . ($i % 9), 'tracking_code' => 'T' . $i], range(1, 9))];
$mc = new MyCoursesHandler($api); $api->log = []; SiteClient::$calls = [];
$mc->show('555');
[$k, , $mt, $mk] = $api->log[0];
check($k === 'send' && strpos($mt, 'دوره‌های من (9)') !== false && strpos($mt, 'در انتظار پرداخت') !== false, 'my courses list shows count and pending payment');
check(SiteClient::$calls === ['myCourses'], 'one lightweight request');
check(in_array('mc:on:1', array_column(array_merge(...$mk), 'callback_data'), true) && in_array('mc:all:2', array_column(array_merge(...$mk), 'callback_data'), true), 'filters and paging use short callbacks');
$api->log = []; $mc->callback('555', 44, 'mc:all:2'); check($api->log[0][0] === 'edit' && $api->log[0][1] === 44 && strpos($api->log[0][2], '7. ') !== false, 'paging edits the same message');
$api->log = []; $mc->callback('555', 44, 'mc:on:1'); check(strpos($api->log[0][2], 'آنلاین') !== false, 'filter keeps the chosen mode');
check(MyCoursesHandler::PANEL_MODES['online_courses'] === 'online' && MyCoursesHandler::PANEL_MODES['course_content'] === 'offline' && MyCoursesHandler::PANEL_MODES['enrolled_courses'] === '', 'site panels map to filters');
foreach (['online_courses', 'course_content', 'inperson_courses', 'enrolled_courses'] as $pid) check(in_array($pid, Keyboards::NATIVE_PANELS, true), "$pid is shown natively");
SiteClient::$fail = true; $api->log = []; $mc->show('555'); check(end($api->log)[2] === 'MSG', 'failure shows a friendly message with retry'); SiteClient::$fail = false;
foreach (glob("$tmp/*") as $f) unlink($f); rmdir($tmp);
echo "Open courses / cache / links: {$n} assertions passed.\n";
