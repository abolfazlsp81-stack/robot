<?php
declare(strict_types=1);
require dirname(__DIR__).'/helpers/BaleText.php';
require dirname(__DIR__).'/helpers/Keyboards.php';
class BaleApi {
    public array $sent=[]; public int $answered=0;
    public function sendMessage($id,$text,$kb=[]){$this->sent[]=[$id,$text,$kb];return ['ok'=>true];}
    public function sendInlineMessage($id,$text,$kb=[]){return $this->sendMessage($id,$text,$kb);}
    public function editMessageText($id,$msg,$text,$kb=[]){return $this->sendMessage($id,$text,$kb);}
    public array $ids=[];
    public function answerCallbackQueryIfPending($id){return $this->answerCallbackQuery($id);}
    public function answerCallbackQuery($id,$t='',$a=false){if(isset($this->ids[$id]))return ['ok'=>true];$this->ids[$id]=1;$this->answered++;return ['ok'=>true];}
}
class Database {
    public static array $users=[],$states=[],$admins=['1'=>true],$changes=[];public static string $active='1';
    public static function stateGet($id){return self::$states[$id]??['step'=>null,'data'=>[]];}
    public static function stateSet($id,$step,$data){self::$states[$id]=['step'=>$step,'data'=>$data];return true;}
    public static function stateClear($id){unset(self::$states[$id]);return true;}
    public static function setActiveMode($id,$mode){$allowed=array_column(self::$users[$id]['modes'],'id');if(!in_array($mode,$allowed,true))return false;self::$users[$id]['active_mode']=$mode;self::$users[$id]['active_mode_title']=$mode;self::$users[$id]['menu_items']=[['id'=>'dashboard','title'=>'منوی '.$mode]];return true;}
    public static function refreshContext($id){return ['user'=>self::$users[$id],'is_admin'=>self::isAdmin($id),'is_owner'=>self::isOwner($id)];}
    public static function getUser($id){return self::$users[$id]??null;}
    public static function getSetting($key){return self::$active;}
    public static function setSetting($key,$v){self::$active=$v;}
    public static function resolveUserIdentifier($id){return self::$users[$id]??null;}
    public static function isAdmin($id){return self::$admins[$id]??false;}
    public static function isOwner($id){return $id==='1';}
    public static function addAdmin($id,$by){self::$changes[]='add:'.$id;self::$admins[$id]=true;return true;}
    public static function removeAdmin($id){self::$changes[]='remove:'.$id;self::$admins[$id]=false;return true;}
}
require dirname(__DIR__).'/helpers/StateManager.php';
require dirname(__DIR__).'/handlers/UserHandler.php';
require dirname(__DIR__).'/handlers/AdminHandler.php';
$n=0;function check($value,$message){global $n;$n++;if(!$value)throw new RuntimeException($message);}
$u=['id'=>1,'chat_id'=>'1','fl_name'=>'نمونه','active_mode'=>'user','modes'=>[['id'=>'user','title'=>'کاربر'],['id'=>'instructor','title'=>'مدرس']],'menu_items'=>[['id'=>'dashboard','title'=>'پیشخوان'],['id'=>'profile','title'=>'نمایه من']]];
Database::$users=['1'=>$u,'2'=>array_merge($u,['id'=>2,'chat_id'=>'2','fl_name'=>'مدیر جدید'])];
Keyboards::setUserContext($u);
$main=Keyboards::userMain();$labels=array_merge(...array_map(fn($row)=>array_column($row,'text'),$main));
check(in_array('🎭 نقش‌ها',$labels,true),'Roles entry missing');
check(count($labels)===3 && $labels[0]===Keyboards::OPEN_COURSES,'Main keyboard must be: open courses, roles, one menu item');
$roles=array_merge(...Keyboards::rolesMenu());
check(array_column($roles,'callback_data')===['site_role_user','site_role_instructor','back_main'],'Locked role shown');
check(Keyboards::resolveSiteSelection('🎭 نقش‌ها')['type']==='roles','Roles selection missing');
$settings=array_merge(...Keyboards::adminPanel(false,true));
check(array_column($settings,'text')===['🔴 خاموش کردن ربات','➕ افزودن ادمین','➖ حذف ادمین','🔙 بازگشت'],'Settings not restricted');
check(Keyboards::adminPanel(false,false)[0][0]['text']==='🟢 روشن کردن ربات','Bot cannot be enabled again');
$api=new BaleApi;$handler=new UserHandler($api);
$cbn=0;$callback=function($data)use(&$cbn){return ['callback_query'=>['id'=>'cb'.(++$cbn),'message'=>['chat'=>['id'=>'1'],'message_id'=>9],'data'=>$data]];};
$handler->handleCallback($callback('site_role_instructor'),$u);
check(Database::$users['1']['active_mode']==='instructor','Role switch failed');
check(strpos(end($api->sent)[1],'instructor')!==false,'New role menu missing');
$handler->handleCallback($callback('site_role_manager'),$u);
check(Database::$users['1']['active_mode']==='instructor','Unavailable role granted');
check($api->answered===2,'Role callbacks not acknowledged');
// گروه‌های منوی سایت: mg:<گروه> فرزندان را نشان می‌دهد؛ mp:<بخش> فقط بخش‌های همین منو را باز می‌کند.
$tu=array_merge($u,['menu_tree'=>[['id'=>'grp_x','title'=>'دوره‌های من','emoji'=>'📚','type'=>'group','children'=>[['id'=>'my_exams','title'=>'آزمون‌ها','mode'=>'user','url'=>'']]]],'menu_items'=>[]]);
$before=count($api->sent);$handler->handleCallback($callback('mg:grp_x'),$tu);
check(count($api->sent)===$before+1 && strpos(end($api->sent)[1],'یکی را انتخاب کنید')!==false && end($api->sent)[2][0][0]['callback_data']==='mp:my_exams','Group page not shown');
$before=count($api->sent);$handler->handleCallback($callback('mp:evil_panel'),$tu);
check(count($api->sent)===$before,'A panel outside the user menu was opened');
$admin=new AdminHandler($api);$message=fn($text)=>['message'=>['chat'=>['id'=>'1'],'text'=>$text]];
$admin->handle($message('🔴 خاموش کردن ربات'),$u,true);$admin->handle($message('🔴 خاموش کردن ربات'),$u,true);
check(Database::$active==='0','Replayed off action toggled bot on');
$admin->handle($message('🟢 روشن کردن ربات'),$u,true);check(Database::$active==='1','Enable failed');
$admin->handle($message('➕ افزودن ادمین'),$u,true);$admin->handle($message('۲'),$u,true);
check(StateManager::getStep('1')==='bot_admin_confirm' && !Database::isAdmin('2'),'Admin changed before confirmation');
$admin->handleCallback($callback('bot_admin_apply_add_3'),$u,true);check(count(Database::$changes)===0,'Tampered target accepted');
$admin->handleCallback($callback('bot_admin_apply_add_2'),$u,true);check(Database::isAdmin('2'),'Add failed');
$admin->handleCallback($callback('bot_admin_apply_add_2'),$u,true);check(count(Database::$changes)===1,'Repeated confirmation changed role again');
$admin->handle($message('➖ حذف ادمین'),$u,true);$admin->handle($message('2'),$u,true);$admin->handleCallback($callback('bot_admin_apply_remove_2'),$u,true);check(!Database::isAdmin('2'),'Remove failed');
$admin->handle($message('➖ حذف ادمین'),$u,true);$admin->handle($message('1'),$u,true);check(StateManager::getStep('1')==='bot_admin_remove','Owner was not protected');
check(BaleText::plain('<b>سلام</b> <strong>دوست</strong>')==='سلام دوست','Bold tag leaked');
check(BaleText::plain("<p>یک</p><p>دو<br>سه</p>")==="یک\nدو\nسه",'Paragraph breaks lost');
check(BaleText::plain('<a href="https://example.invalid/?a=1&amp;b=2">کلاس</a>')==='کلاس (https://example.invalid/?a=1&b=2)','Link lost');
check(BaleText::plain('2 < 5 &amp; 9 > 7')==='2 < 5 & 9 > 7','Plain content damaged');
check(BaleText::plain('&lt;example&gt;')==='<example>','Escaped user text lost');
$p=BaleText::payload('sendPhoto',['caption'=>'<b>پیوست</b>','photo'=>'FAKE_ID','parse_mode'=>'HTML']);
check($p['caption']==='پیوست' && $p['photo']==='FAKE_ID' && !isset($p['parse_mode']),'Media caption not normalized');
$p=BaleText::payload('sendMessage',['text'=>'*keep*','parse_mode'=>'Markdown']);check($p['text']==='*keep*' && $p['parse_mode']==='Markdown','Explicit non-HTML mode changed');
echo "Menus, roles, admin confirmation and text: {$n} assertions passed.\n";
