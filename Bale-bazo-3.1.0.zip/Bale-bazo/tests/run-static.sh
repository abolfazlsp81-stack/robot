#!/usr/bin/env bash
set -euo pipefail

bot_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
php_count=0

if command -v php >/dev/null 2>&1; then
  while IFS= read -r -d '' file; do
    php -l "$file" >/dev/null
    php_count=$((php_count + 1))
  done < <(find "$bot_root" -type f -name '*.php' -print0)
else
  printf 'PHP CLI is unavailable; PHP lint skipped in this environment.\n' >&2
fi

node "$bot_root/tests/php-balance.js"

required=(
  helpers/SiteClient.php
  helpers/MediaSync.php
  database/Database.php
  config/local.example.php
  README-FA.md
)
for relative in "${required[@]}"; do
  test -s "$bot_root/$relative" || { printf 'Missing required file: %s\n' "$relative" >&2; exit 1; }
done

if rg -n --glob '*.php' 'SQLite3|sqlite:|new[[:space:]]+PDO' "$bot_root" >/dev/null; then
  printf 'A local database dependency is still present.\n' >&2
  exit 1
fi

rg -n "mph-bale/v1/rpc|hash_hmac\('sha256'|X-MPH-Nonce" "$bot_root/helpers/SiteClient.php" >/dev/null || { printf 'Signed site client is incomplete.\n' >&2; exit 1; }
rg -n "claimUpdate" "$bot_root/index.php" "$bot_root/database/Database.php" >/dev/null || { printf 'Webhook idempotency is missing.\n' >&2; exit 1; }
rg -n "MediaSync::transfer" "$bot_root/handlers" >/dev/null || { printf 'Real media transfer is missing.\n' >&2; exit 1; }
rg -n "inquireTransaction|verifiedTransaction" "$bot_root/helpers/BaleApi.php" "$bot_root/handlers/UserHandler.php" >/dev/null || { printf 'Wallet transaction verification is missing.\n' >&2; exit 1; }
rg -n "answerCallbackQueryIfPending|finally" "$bot_root/helpers/BaleApi.php" "$bot_root/handlers/UserHandler.php" "$bot_root/handlers/AdminHandler.php" >/dev/null || { printf 'Callback acknowledgement guard is missing.\n' >&2; exit 1; }
rg -n "request_contact.*true|linkAccount" "$bot_root/helpers/Keyboards.php" "$bot_root/handlers/RegisterHandler.php" "$bot_root/database/Database.php" >/dev/null || { printf 'Verified Bale contact linking is missing.\n' >&2; exit 1; }
rg -n "mph_order_|access_synced|inquireTransaction" "$bot_root/index.php" "$bot_root/handlers/UserHandler.php" >/dev/null || { printf 'Exact-order payment reconciliation is missing.\n' >&2; exit 1; }
if rg -n "'currency'[[:space:]]*=>" "$bot_root/helpers/BaleApi.php" >/dev/null; then
  printf 'sendInvoice contains an unsupported currency request field.\n' >&2
  exit 1
fi
precheckout_line="$(rg -n 'if \(isset\(.*pre_checkout_query' "$bot_root/index.php" | head -1 | cut -d: -f1)"
claim_line="$(rg -n 'Database::bootstrap\(' "$bot_root/index.php" | head -1 | cut -d: -f1)"
test -n "$precheckout_line" && test -n "$claim_line" && test "$precheckout_line" -lt "$claim_line" || { printf 'Pre-checkout must be answered before generic update claiming.\n' >&2; exit 1; }

# local.php is the user's private deployment configuration, intentionally retained.
# Public PHP sources must still contain no credential literals.
if rg -n -P --glob '*.php' --glob '!**/config/local.php' '[0-9]{7,}:[A-Za-z0-9_-]{20,}|WALLET-(?!TEST)[A-Za-z0-9_-]{12,}' "$bot_root" >/dev/null; then
  printf 'A credential-like literal is present in PHP source.\n' >&2
  exit 1
fi

if command -v php >/dev/null 2>&1; then
  php "$bot_root/tests/test-register-security.php" >/dev/null
  php "$bot_root/tests/test-payment-reconciliation.php" >/dev/null
  php "$bot_root/tests/test-bootstrap.php" >/dev/null
  php "$bot_root/tests/test-menu-text.php" >/dev/null
  php "$bot_root/tests/test-open-courses.php" >/dev/null
  php "$bot_root/tests/test-resilience.php" >/dev/null
fi

printf 'Bot static suite completed: %d PHP files linted.\n' "$php_count"
