<?php
// آزمون پایداری زیر فشار: دروازهٔ ترافیک، تلاش دوباره، قطع‌کننده و صف هر کاربر (بدون شبکه).
declare(strict_types=1);
define('BASE_DIR', dirname(__DIR__) . '/tests/.resilience-' . bin2hex(random_bytes(3)));
require dirname(__DIR__) . '/helpers/SiteClient.php';
require dirname(__DIR__) . '/helpers/ChatLock.php';
$n = 0; function check($v, $m) { global $n; $n++; if (!$v) throw new RuntimeException($m); }
$tmp = sys_get_temp_dir() . '/bb3-res-' . bin2hex(random_bytes(4)); mkdir($tmp, 0700); Cache::reset($tmp); Cache::$disableApcu = true;
$cfg = ['site_url' => 'https://s.test', 'site_sync_secret' => str_repeat('k', 40), 'site_max_concurrent' => 2, 'site_queue_wait' => 1, 'site_max_attempts' => 3, 'site_retry_budget' => 10, 'site_circuit_threshold' => 4, 'site_circuit_cooldown' => 2];
SiteClient::configure($cfg); SiteClient::setActorChatId('555');
$slept = []; SiteGate::$sleeper = function (int $ms) use (&$slept) { $slept[] = $ms; };
function ok($data) { return ['raw' => json_encode(['success' => true, 'data' => $data]), 'error' => '', 'errno' => 0, 'status' => 200, 'retry_after' => 0]; }
function net($errno = 28) { return ['raw' => false, 'error' => 'timeout', 'errno' => $errno, 'status' => 0, 'retry_after' => 0]; }
function http($status, $body = '<html>busy</html>', $ra = 0) { return ['raw' => $body, 'error' => '', 'errno' => 0, 'status' => $status, 'retry_after' => $ra]; }
function remote($code, $status = 503) { return ['raw' => json_encode(['success' => false, 'error' => ['code' => $code, 'message' => 'm']]), 'error' => '', 'errno' => 0, 'status' => $status, 'retry_after' => 0]; }
function script(array $replies, &$calls) { $calls = 0; SiteClient::$transportOverride = function ($m, $p) use (&$replies, &$calls) { $calls++; return array_shift($replies) ?? ok('late'); }; }
function reset_state() { global $tmp, $slept; foreach (glob("$tmp/*") as $f) @unlink($f); Cache::reset($tmp); $slept = []; }

// ── طبقه‌بندی پاسخ‌ها ──
check(SiteClient::interpret(ok(1))['kind'] === 'ok', 'success');
check(SiteClient::interpret(net())['kind'] === 'transient', 'timeout is transient');
check(SiteClient::interpret(net(7))['not_processed'] === true && SiteClient::interpret(net(28))['not_processed'] === false, 'connect errors never reached WordPress; timeouts might have');
check(SiteClient::interpret(http(503))['kind'] === 'transient' && SiteClient::interpret(http(503))['not_processed'] === true, 'host 503 page: transient, not processed');
check(SiteClient::interpret(http(508))['kind'] === 'transient', 'resource limit page is transient');
check(SiteClient::interpret(http(404, '<html>'))['kind'] === 'remote', 'a real 404 is not retried');
check(SiteClient::interpret(remote('forbidden', 403))['kind'] === 'remote', 'application errors are not retried');
check(SiteClient::interpret(remote('conversation_busy'))['kind'] === 'busy', 'busy conversation is its own class');
check(SiteClient::interpret(remote('storage_unavailable'))['kind'] === 'transient', 'storage hiccup is transient');
check(SiteClient::isMutation('cart_x') === false && SiteClient::isMutation('createNews') === true && SiteClient::isMutation('native', ['op' => 'checkout']) === true && SiteClient::isMutation('native', ['op' => 'orders']) === false, 'mutation detection mirrors the plugin');

// ── تلاش دوباره ──
reset_state(); script([net(), http(503), ok(['v' => 1])], $calls);
check(SiteClient::call('getUser', ['x' => 1]) === ['v' => 1] && $calls === 3, 'read retried until it succeeds');
check(count($slept) === 2 && $slept[1] > $slept[0] * 1.2, 'back-off grows between attempts: ' . implode(',', $slept));
reset_state(); script([net(), net(), net(), ok(1)], $calls);
try { SiteClient::call('getUser'); check(false, 'must fail after max attempts'); } catch (SiteSyncException $e) { check($e->getRemoteCode() === 'network_error' && $calls === 3, 'gives up after max attempts'); }
reset_state(); script([net(28), ok(1)], $calls);
try { SiteClient::call('createNews', ['t' => 1]); check(false, 'unsafe'); } catch (SiteSyncException $e) { check($calls === 1, 'mutation without a job receipt is not blindly repeated after a timeout'); }
reset_state(); script([net(7), ok('done')], $calls);
check(SiteClient::call('createNews', ['t' => 2]) === 'done' && $calls === 2, 'mutation IS repeated when the request never connected');
SiteClient::setJob('77', 'tok'); reset_state(); script([net(28), ok('done')], $calls);
check(SiteClient::call('createNews', ['t' => 3]) === 'done' && $calls === 2, 'mutation inside a job is repeated safely (server receipt)');
SiteClient::setJob('', '');
reset_state(); script([remote('forbidden', 403), ok(1)], $calls);
try { SiteClient::call('getUser', ['y' => 1]); } catch (SiteSyncException $e) { check($calls === 1 && $e->getRemoteCode() === 'forbidden', 'application error is returned immediately'); }
reset_state(); script([remote('conversation_busy'), remote('conversation_busy'), ok('free')], $calls);
check(SiteClient::call('beginUpdate', ['update_id' => '1']) === 'free' && $calls === 3, 'busy conversation waits and retries');
check(Cache::get('sg:f') === null, 'busy conversation is not counted as a site failure');
check($slept[0] >= 400, 'busy waits longer than ordinary retries');
reset_state(); script([http(503, '<html>', 2), ok(1)], $calls);
SiteClient::call('getUser', ['z' => 1]); check($slept[0] >= 2000, 'Retry-After is honoured');
reset_state(); SiteClient::configure(array_replace($cfg, ['site_retry_budget' => 2])); script([http(503, '<html>', 9), ok(1)], $calls);
try { SiteClient::call('getUser', ['b' => 1]); check(false, 'budget'); } catch (SiteSyncException $e) { check($calls === 1, 'a wait longer than the retry budget is not attempted'); }
SiteClient::configure($cfg);

// ── قطع‌کننده ──
reset_state(); script(array_fill(0, 40, net()), $calls);
for ($i = 0; $i < 3; $i++) { try { SiteClient::call('getUser', ['i' => $i]); } catch (SiteSyncException $e) {} }
$before = $calls;
try { SiteClient::call('getUser', ['i' => 99]); check(false, 'breaker should be open'); } catch (SiteSyncException $e) { check($e->getRemoteCode() === 'site_busy' && $calls === $before, 'open breaker fails fast without touching the site'); }
check(strpos(SiteClient::userMessage($e, ['site_busy' => 'BUSY', 'site_unavailable' => 'DOWN']), 'BUSY') === 0, 'friendly busy message');
sleep(3); // پس از سرد شدن، فقط یک تماس آزمایشی اجازه می‌گیرد
SiteClient::$transportOverride = function () use (&$calls) { $calls++; return ok('back'); };
check(SiteClient::call('getUser', ['i' => 100]) === 'back', 'probe call goes through after cooldown');
check(Cache::get('sg:open') === null, 'success closes the breaker');

// ── محدودیت هم‌زمانی ──
reset_state();
$a = SiteGate::acquire(); $b = SiteGate::acquire();
check(is_resource($a) && is_resource($b), 'two slots available');
$t0 = microtime(true); $c = SiteGate::acquire();
check($c === null && microtime(true) - $t0 >= 0.9, 'third caller waits for the queue window and then reports busy');
SiteGate::release($a); $d = SiteGate::acquire(); check(is_resource($d), 'a released slot is reusable');
SiteGate::release($b); SiteGate::release($d);

// ── صف هر کاربر ──
check(ChatLock::acquire('900', 0.1) === true, 'first message of a chat gets the lock');
$proc = proc_open([PHP_BINARY, '-r', 'define("BASE_DIR", ' . var_export(BASE_DIR, true) . '); require ' . var_export(dirname(__DIR__) . '/helpers/ChatLock.php', true) . '; exit(ChatLock::acquire("900", 0.3) ? 0 : 7);'], [], $pipes);
check(proc_close($proc) === 7, 'a second message of the same chat waits and times out while the first runs');
$other = proc_open([PHP_BINARY, '-r', 'define("BASE_DIR", ' . var_export(BASE_DIR, true) . '); require ' . var_export(dirname(__DIR__) . '/helpers/ChatLock.php', true) . '; exit(ChatLock::acquire("901", 0.3) ? 0 : 7);'], [], $pipes2);
check(proc_close($other) === 0, 'other chats are not blocked');
ChatLock::release();
$proc = proc_open([PHP_BINARY, '-r', 'define("BASE_DIR", ' . var_export(BASE_DIR, true) . '); require ' . var_export(dirname(__DIR__) . '/helpers/ChatLock.php', true) . '; exit(ChatLock::acquire("900", 0.3) ? 0 : 7);'], [], $pipes3);
check(proc_close($proc) === 0, 'the lock is free again after release');

foreach (glob("$tmp/*") as $f) @unlink($f); @rmdir($tmp);
echo "Resilience (gate, retry, breaker, per-chat queue): {$n} assertions passed.\n";
