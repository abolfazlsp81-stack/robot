<?php
// handlers/OpenCoursesHandler.php — «📝 دوره‌های در حال ثبت‌نام»
//
// سرعت: فهرست با یک درخواست از سایت می‌آید (و ۳۰ ثانیه کش می‌شود)؛ جزئیات هر دوره از همان فهرست ساخته
// می‌شود (بدون درخواست تازه) و ناوبری با ویرایش همان پیام انجام می‌شود، نه ارسال پیام تازه.
declare(strict_types=1);

final class OpenCoursesHandler
{
    public const LABEL = '📝 دوره‌های در حال ثبت‌نام';
    private const PAGE_SIZE = 6;

    private BaleApi $api;

    public function __construct(BaleApi $api) { $this->api = $api; }

    private function money(int $toman): string { return $toman > 0 ? number_format($toman) . ' تومان' : 'رایگان'; }

    private function home(): array { return [['text' => '🏠 خانه', 'callback_data' => 'back_main']]; }

    private function put(string $chatId, int $msgId, string $text, array $keyboard): void
    {
        if ($msgId > 0) {
            $res = $this->api->editMessageText($chatId, $msgId, $text, $keyboard);
            if (!empty($res['ok'])) return;
            // پیام قابل ویرایش نیست (قدیمی یا حذف‌شده): پیام تازه
        }
        $this->api->sendInlineMessage($chatId, $text, $keyboard);
    }

    /** نمایش فهرست دوره‌ها؛ $msgId>0 یعنی همان پیام را ویرایش کن. */
    public function show(string $chatId, int $page = 1, int $msgId = 0, bool $fresh = false): void
    {
        try {
            $data = Database::openCourses($fresh);
        } catch (SiteSyncException $e) {
            $this->put($chatId, $msgId, '⚠️ سایت دیر پاسخ داد؛ چند ثانیه بعد دوباره امتحان کنید.', [[['text' => '🔄 تلاش دوباره', 'callback_data' => 'oc:r']], $this->home()]);
            return;
        }
        if ($data === null) { $this->legacyList($chatId, $msgId); return; }

        $items = array_values((array)$data['items']);
        $archive = (string)($data['archive_url'] ?? '');
        $footer = [];
        if ($archive !== '') $footer[] = [['text' => '🌐 همهٔ دوره‌ها در سایت', 'url' => $archive]];
        if (!$items) {
            $footer[] = [['text' => '🔄 به‌روزرسانی', 'callback_data' => 'oc:r']];
            $footer[] = $this->home();
            $this->put($chatId, $msgId, "📝 دوره‌های در حال ثبت‌نام\n\nدر حال حاضر دوره‌ای برای ثبت‌نام باز نیست. به‌زودی دوره‌های تازه اضافه می‌شوند.", $footer);
            return;
        }
        $pages = max(1, (int)ceil(count($items) / self::PAGE_SIZE));
        $page = min(max(1, $page), $pages);
        $slice = array_slice($items, ($page - 1) * self::PAGE_SIZE, self::PAGE_SIZE);
        $rows = [];
        foreach ($slice as $course) {
            $mark = !empty($course['enrolled']) ? '✅ ' : '📖 ';
            $price = (int)($course['min_price'] ?? 0);
            $label = $mark . $this->short((string)$course['title'], 38) . ' — ' . ($price > 0 ? 'از ' . number_format($price) . ' ت' : 'رایگان');
            $rows[] = [['text' => $label, 'callback_data' => 'oc:d:' . (int)$course['id'] . ':' . $page]];
        }
        if ($pages > 1) {
            $nav = [];
            if ($page > 1) $nav[] = ['text' => '◀ قبلی', 'callback_data' => 'oc:l:' . ($page - 1)];
            $nav[] = ['text' => $page . ' / ' . $pages, 'callback_data' => 'noop'];
            if ($page < $pages) $nav[] = ['text' => 'بعدی ▶', 'callback_data' => 'oc:l:' . ($page + 1)];
            $rows[] = $nav;
        }
        foreach ($footer as $row) $rows[] = $row;
        $rows[] = [['text' => '🔄 به‌روزرسانی', 'callback_data' => 'oc:r'], $this->home()[0]];
        $text = "📝 دوره‌های در حال ثبت‌نام\n\n" . count($items) . " دوره برای ثبت‌نام باز است. برای دیدن جزئیات و ثبت‌نام، یکی را انتخاب کنید:";
        if (!empty($data['stale'])) $text .= "\n\n⚠️ سایت شلوغ است؛ این فهرست چند دقیقه پیش ذخیره شده است. با «به‌روزرسانی» دوباره بررسی کنید.";
        $this->put($chatId, $msgId, $text, $rows);
    }

    /** جزئیات یک دوره از روی فهرست کش‌شده (بدون تماس تازه با سایت). */
    public function detail(string $chatId, int $msgId, int $courseId, int $page = 1): void
    {
        try {
            $data = Database::openCourses(false);
        } catch (SiteSyncException $e) {
            $this->put($chatId, $msgId, '⚠️ سایت دیر پاسخ داد؛ چند ثانیه بعد دوباره امتحان کنید.', [[['text' => '↩ فهرست دوره‌ها', 'callback_data' => 'oc:l:' . $page]], $this->home()]);
            return;
        }
        $course = null;
        foreach ((array)($data['items'] ?? []) as $c) if ((int)$c['id'] === $courseId) { $course = $c; break; }
        if (!$course) {
            $this->put($chatId, $msgId, "این دوره دیگر برای ثبت‌نام باز نیست.", [[['text' => '↩ فهرست دوره‌ها', 'callback_data' => 'oc:r']], $this->home()]);
            return;
        }
        $this->put($chatId, $msgId, $this->detailText($course), $this->detailKeyboard($course, $page));
    }

    public function detailText(array $course): string
    {
        $text = '📖 ' . $course['title'];
        if (!empty($course['enrolled'])) $text .= "\n✅ شما در این دوره ثبت‌نام کرده‌اید.";
        $excerpt = trim((string)($course['excerpt'] ?? ''));
        if ($excerpt !== '') $text .= "\n\n" . $excerpt;
        $text .= "\n";
        if (trim((string)($course['start_date'] ?? '')) !== '') $text .= "\n📅 شروع: " . $course['start_date'];
        if (trim((string)($course['end_date'] ?? '')) !== '') $text .= "\n📅 پایان: " . $course['end_date'];
        $text .= "\n\n📦 شیوه‌های ثبت‌نام:";
        foreach ((array)$course['modes'] as $mode) {
            $icon = ['offline' => '🎬', 'online' => '💻', 'inperson' => '📍'][(string)($mode['mode'] ?? '')] ?? '🔹';
            $line = "\n{$icon} " . ($mode['label'] ?: 'دوره') . ' — ' . $this->money((int)($mode['price'] ?? 0));
            if (!empty($mode['full'])) $line .= ' — 🚫 ظرفیت تکمیل';
            elseif (isset($mode['remaining']) && $mode['remaining'] !== null) $line .= ' — ' . (int)$mode['remaining'] . ' جای خالی';
            if (($mode['mode'] ?? '') === 'inperson') {
                if (trim((string)($mode['start'] ?? '')) !== '') $line .= "\n   🕒 " . $mode['start'];
                if (trim((string)($mode['address'] ?? '')) !== '') $line .= "\n   🗺 " . $mode['address'];
            }
            $text .= $line;
        }
        return mb_substr($text, 0, 3900);
    }

    public function detailKeyboard(array $course, int $page): array
    {
        $rows = [];
        if (!empty($course['enrolled'])) {
            $rows[] = [['text' => '✅ ثبت‌نام شده‌اید', 'callback_data' => 'noop']];
        } else {
            foreach ((array)$course['modes'] as $mode) {
                $label = trim((string)$mode['label']) ?: 'دوره';
                if (!empty($mode['full'])) { $rows[] = [['text' => '🚫 ' . $label . ' — ظرفیت تکمیل', 'callback_data' => 'noop']]; continue; }
                $rows[] = [['text' => '🛒 ثبت‌نام ' . $label . ' — ' . $this->money((int)$mode['price']), 'callback_data' => 'oc:b:' . (int)$mode['product_id']]];
            }
        }
        if (!empty($course['url'])) $rows[] = [['text' => '🌐 صفحهٔ دوره در سایت', 'url' => (string)$course['url']]];
        $rows[] = [['text' => '↩ فهرست دوره‌ها', 'callback_data' => 'oc:l:' . max(1, $page)], $this->home()[0]];
        return $rows;
    }

    /** شروع ثبت‌نام یک شیوه: افزودن به سبد همان سایت و ادامه در جریان پرداخت موجود. */
    public function buy(string $chatId, string $cbId, int $productId): void
    {
        $found = null;
        try {
            $data = Database::openCourses(false);
        } catch (SiteSyncException $e) {
            $data = null;
        }
        foreach ((array)($data['items'] ?? []) as $c) {
            foreach ((array)$c['modes'] as $m) if ((int)$m['product_id'] === $productId) { $found = [$c, $m]; break 2; }
        }
        if ($found && !empty($found[1]['full'])) { $this->api->answerCallbackQuery($cbId, '🚫 ظرفیت این شیوه تکمیل شده است.', true); return; }
        if ($found && !empty($found[0]['enrolled'])) { $this->api->answerCallbackQuery($cbId, '✅ شما قبلاً در این دوره ثبت‌نام کرده‌اید.', true); return; }
        // سایت هنگام افزودن به سبد، قیمت و ظرفیت را دوباره و قطعی بررسی می‌کند.
        (new NativeHandler($this->api))->callback($chatId, 'n:add:' . $productId);
        Database::forgetOpenCourses($chatId);
    }

    /** پشتیبانی از افزونهٔ قدیمی‌تر که متد openCourses را ندارد. */
    private function legacyList(string $chatId, int $msgId): void
    {
        $result = Database::coursePage(1);
        $courses = (array)($result['items'] ?? []);
        if (!$courses) { $this->put($chatId, $msgId, '📝 در حال حاضر دوره‌ای برای ثبت‌نام وجود ندارد.', [$this->home()]); return; }
        $this->put($chatId, $msgId, "📝 دوره‌های در حال ثبت‌نام\n\nیکی را انتخاب کنید:", Keyboards::courseList($courses));
    }

    private function short(string $text, int $max): string
    {
        return mb_strlen($text) > $max ? mb_substr($text, 0, $max - 1) . '…' : $text;
    }

    /** مسیریابی callbackهای «oc:». برمی‌گرداند true اگر پردازش شد. */
    public function callback(string $chatId, int $msgId, string $data, string $cbId = ''): bool
    {
        if (strpos($data, 'oc:') !== 0) return false;
        $p = explode(':', $data);
        switch ($p[1] ?? '') {
            case 'l': $this->show($chatId, (int)($p[2] ?? 1), $msgId); break;
            case 'r': $this->show($chatId, 1, $msgId, true); break;
            case 'd': $this->detail($chatId, $msgId, (int)($p[2] ?? 0), (int)($p[3] ?? 1)); break;
            case 'b': $this->buy($chatId, $cbId, (int)($p[2] ?? 0)); break;
            default: $this->show($chatId, 1, $msgId);
        }
        return true;
    }
}
