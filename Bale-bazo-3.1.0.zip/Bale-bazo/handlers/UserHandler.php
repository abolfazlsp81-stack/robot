<?php
// handlers/UserHandler.php
require_once __DIR__.'/NativeHandler.php';
require_once __DIR__.'/OpenCoursesHandler.php';
require_once __DIR__.'/MyCoursesHandler.php';

class UserHandler
{
    private BaleApi $api;

    public function __construct(BaleApi $api)
    {
        $this->api = $api;
    }

    // ───── Dispatcher اصلی پیام‌های متنی ─────────────────────────
    public function handle(array $update, array $user): void
    {
        $msg    = $update['message'] ?? null;
        if (!$msg) return;

        $chatId = (string)($msg['chat']['id'] ?? '');
        $text   = trim($msg['text'] ?? '');
        $step   = StateManager::getStep($chatId);
        if((new NativeHandler($this->api))->message($chatId,$msg))return;

        // ── عکس پروفایل ──
        if ($step === 'edit_profile_photo' && ($photoId = MediaSync::photo($msg))) {
            $this->handleProfilePhotoUpload($chatId, $photoId);
            return;
        }
        if ($step === 'edit_profile_phone') {
            $this->handlePhoneContactUpdate($chatId, $msg);
            return;
        }

        // ── عکس رسید واریزی (پرداخت کارت‌به‌کارت) ──
        if ($step === 'awaiting_receipt') {
            if ($text === '❌ لغو') {
                StateManager::clear($chatId);
                $this->api->sendMessage($chatId, "❌ لغو شد.", Keyboards::userMain());
                return;
            }
            $receiptId = MediaSync::photo($msg);
            $receiptName = '';
            if (!$receiptId && !empty($msg['document']['file_id']) && ($msg['document']['mime_type'] ?? '') === 'application/pdf') {
                $receiptId = (string)$msg['document']['file_id'];
                $receiptName = (string)($msg['document']['file_name'] ?? '');
            }
            if ($receiptId) {
                $this->handleReceiptUpload($chatId, $receiptId, $receiptName, $user);
            } else {
                $this->api->sendMessage($chatId, "⚠️ لطفاً رسید را به‌صورت <b>عکس یا PDF</b> ارسال کنید:", Keyboards::cancelOnly());
            }
            return;
        }

        // ── وضعیت‌های چندمرحله‌ای ──
        if ($step && str_starts_with($step, 'contact_')) {
            $this->handleContactAdmin($chatId, $text, $user, $msg);
            return;
        }
        if ($step && str_starts_with($step, 'edit_profile_')) {
            $this->handleProfileEdit($chatId, $text, $step);
            return;
        }
        if ($step && str_starts_with($step, 'appt_')) {
            $this->handleAppointment($chatId, $text, $step, $update, $user);
            return;
        }

        // ── عکس بدون زمینه: راهنمایی به‌جای سکوت ──
        if ($text === '' && !$step && MediaSync::photo($msg)) {
            $this->api->sendMessage($chatId, "📷 عکسی که فرستادید به هیچ بخشی وصل نیست.\nاگر می‌خواهید عکس پروفایل را عوض کنید، از «👤 پروفایل من» وارد شوید و «✏️ ویرایش اطلاعات» را بزنید.", Keyboards::userMain());
            return;
        }

        $siteSelection = Keyboards::resolveSiteSelection($text);
        if ($siteSelection) {
            $this->handleSiteSelection($chatId, $siteSelection, $user);
            return;
        }

        match ($text) {
            '📚 ثبت‌نام دوره',
            '📚 دوره ها'             => $this->showCourses($chatId),
            '📚 دوره‌های من'          => $this->showMyCourses($chatId, $user),
            '📰 اخبار و اطلاعیه‌ها'  => $this->showNews($chatId, 'news', 0),
            '📅 رزرو نوبت'           => $this->startAppointment($chatId),
            '📅 نوبت‌های من'          => $this->showMyAppointments($chatId, $user),
            '✉️ ارتباط با ادمین'     => $this->startContactAdmin($chatId),
            '🎓 گواهینامه‌های من'     => $this->showMyCertificates($chatId, $user),
            '👤 پروفایل من'          => $this->showProfile($chatId),
            '❌ لغو'                  => $this->cancelAndBack($chatId),
            default                   => $this->sendMainMenu($chatId, $user),
        };
    }

    // ───── پروفایل ───────────────────────────────────────────────
    private function showProfile(string $chatId): void
    {
        $user    = Database::getUser($chatId);
        if (!$user) {
            $this->api->sendMessage($chatId, "⚠️ اطلاعات حساب سایت در دسترس نیست.", Keyboards::userMain());
            return;
        }
        $firstName = $user['first_name'] ?? '';
        $lastName  = $user['last_name'] ?? '';
        $firstEn   = $user['first_name_en'] ?? '';
        $lastEn    = $user['last_name_en'] ?? '';
        $caption = "👤 <b>پروفایل کاربری</b>\n\n"
                 . "👤 نام: " . ($firstName ?: '—') . "\n"
                 . "👤 نام‌خانوادگی: " . ($lastName ?: '—') . "\n"
                 . "🌍 نام به انگلیسی: " . ($firstEn ?: '—') . "\n"
                 . "🌍 نام‌خانوادگی به انگلیسی: " . ($lastEn ?: '—') . "\n"
                 . "📞 تلفن: {$user['phone']}\n"
                 . "📧 ایمیل: " . (($user['email'] ?? '') !== '' ? self::h((string)$user['email']) : '—') . "\n"
                 . "🪪 کد ملی: " . ($user['id_card'] ?: '—') . "\n"
                 . "🎂 تاریخ تولد: " . ($user['birthday'] ?: $user['birthdate']) . "\n"
                 . "🎓 رشته تحصیلی: " . ($user['field_of_study'] ?: '—') . "\n"
                 . "📚 مقطع تحصیلی: " . ($user['education_level'] ?: '—') . "\n"
                 . "🏠 آدرس: " . ($user['address'] ?: '—') . "\n"
                 . "📅 عضویت: {$user['created_at']}";
        if (($user['email'] ?? '') === '') $caption .= "\n\n⚠️ ایمیل ثبت نشده است؛ از «ویرایش پروفایل» آن را ثبت کنید تا بازیابی حساب و اطلاع‌رسانی ممکن شود.";

        $photo = $user['profile_photo'] ?: ($user['avatar_url'] ?? '');
        if ($photo !== '') $this->api->sendPhoto($chatId, $photo, $caption, Keyboards::profileView());
        else $this->api->sendInlineMessage($chatId, $caption, Keyboards::profileView());
    }

    // ───── ویرایش پروفایل ─────────────────────────────────────────
    private function handleProfileEdit(string $chatId, string $text, string $step): void
    {
        if ($text === '❌ لغو') {
            StateManager::clear($chatId);
            $this->showProfile($chatId);
            return;
        }

        $field = str_replace('edit_profile_', '', $step);
        $label = [
            'first_name'      => 'نام',
            'last_name'       => 'نام‌خانوادگی',
            'first_name_en'   => 'نام به انگلیسی',
            'last_name_en'    => 'نام‌خانوادگی به انگلیسی',
            'phone'           => 'شماره تلفن',
            'id_card'         => 'کد ملی',
            'birthday'        => 'تاریخ تولد',
            'address'         => 'آدرس',
            'field_of_study'  => 'رشته تحصیلی',
            'education_level' => 'مقطع تحصیلی',
            'email'           => 'ایمیل',
        ][$field] ?? $field;

        // اعتبارسنجی
        if ($field === 'email') {
            $email = trim($text);
            if (strlen($email) > 100 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $this->api->sendMessage($chatId, "⚠️ ایمیل معتبر وارد کنید (مثال: name@example.com):", Keyboards::cancelOnly());
                return;
            }
            $text = $email;
        }
        if ($field === 'id_card') {
            $code = preg_replace('/\D+/', '', self::normalizeDigits($text));
            if (strlen($code) !== 10) {
                $this->api->sendMessage($chatId, "⚠️ کد ملی باید ۱۰ رقم باشد. مجدداً وارد کنید:", Keyboards::cancelOnly());
                return;
            }
            $text = $code;
        }
        if ($field === 'education_level') {
            $valid = ['دیپلم', 'کاردانی', 'کارشناسی', 'کارشناسی ارشد', 'دکتری'];
            if (!in_array($text, $valid, true)) {
                $this->api->sendMessage($chatId, "⚠️ لطفاً مقطع تحصیلی را از گزینه‌های زیر انتخاب کنید:", Keyboards::educationLevels());
                return;
            }
        }
        if (($field === 'first_name' || $field === 'last_name') && !self::validPersonName($text)) {
            $this->api->sendMessage($chatId, "⚠️ {$label} باید حداقل ۲ حرف باشد و نمی‌تواند عدد یا کد باشد. مجدداً وارد کنید:", Keyboards::cancelOnly());
            return;
        }
        if (in_array($field, ['first_name_en', 'last_name_en'], true) && !self::validEnglishName($text)) {
            $this->api->sendMessage($chatId, "⚠️ {$label} باید فقط شامل حروف انگلیسی باشد. مجدداً وارد کنید:", Keyboards::cancelOnly());
            return;
        }

        if (!Database::updateUserField($chatId, $field, $text)) {
            $error = Database::lastError();
            $message = is_array($error) && !empty($error['message']) ? (string)$error['message'] : 'ذخیره تغییرات در سایت انجام نشد.';
            $this->api->sendMessage($chatId, "❌ " . self::h($message), Keyboards::cancelOnly());
            return;
        }
        StateManager::clear($chatId);
        $doneText = $field === 'email'
            ? "✅ لینک تأیید به ایمیل جدید ارسال شد. تا وقتی روی لینک کلیک نکنید، ایمیل قبلی معتبر می‌ماند."
            : "✅ <b>{$label}</b> با موفقیت بروزرسانی شد.";
        $this->api->sendMessage($chatId, $doneText, Keyboards::userMain());
        $this->showProfile($chatId);
    }

    private function handlePhoneContactUpdate(string $chatId, array $message): void
    {
        $text = trim((string)($message['text'] ?? ''));
        if ($text === '❌ لغو') { StateManager::clear($chatId); $this->showProfile($chatId); return; }
        $contact = is_array($message['contact'] ?? null) ? $message['contact'] : [];
        $contactId = (string)($contact['user_id'] ?? '');
        if ($contactId !== $chatId || (string)($message['from']['id'] ?? '') !== $chatId
            || isset($message['forward_from']) || isset($message['forward_origin']) || isset($message['forward_date'])) {
            $this->api->sendMessage($chatId, '⚠️ تغییر شماره فقط با دکمه «تأیید شماره من» و شماره متعلق به خودتان انجام می‌شود.', Keyboards::ownContact());
            return;
        }
        $phone = preg_replace('/\D+/', '', self::normalizeDigits((string)($contact['phone_number'] ?? '')));
        if (strpos($phone, '0098') === 0) $phone = '0' . substr($phone, 4);
        elseif (strpos($phone, '98') === 0) $phone = '0' . substr($phone, 2);
        if (!preg_match('/^09\d{9}$/', $phone) || !Database::updatePhoneByContact($chatId, $phone, $contactId)) {
            $error = Database::lastError();
            $errorMessage = (string)($error['message'] ?? 'شماره موبایل معتبر نیست یا قبلاً برای حساب دیگری ثبت شده است.');
            $this->api->sendMessage($chatId, '❌ ' . self::h($errorMessage), Keyboards::ownContact());
            return;
        }
        StateManager::clear($chatId);
        $this->api->sendMessage($chatId, '✅ شماره تلفن در حساب سایت به‌روزرسانی شد.', Keyboards::userMain());
        $this->showProfile($chatId);
    }

    private function handleProfilePhotoUpload(string $chatId, string $fileId): void
    {
        try {
            $synced = MediaSync::transfer($this->api, $fileId, 'profile');
            if ($synced) $synced = (bool)Database::updateProfilePhoto($chatId, $fileId);
        } catch (SiteSyncException $error) {
            UpdateLifecycle::clear();Database::clearRetryError();
            $detail = MediaSync::lastError()['message'] ?? '';
            $this->api->sendMessage($chatId, "⚠️ انتقال عکس نیمه‌کاره ماند؛ لطفاً همین عکس را دوباره ارسال کنید." . ($detail !== '' ? "\n" . $detail : ''), Keyboards::cancelOnly());
            return;
        }
        if (!$synced) {
            $reason = MediaSync::lastError()['message'] ?? null;
            $this->api->sendMessage($chatId, "❌ " . ($reason ?: 'انتقال عکس به رسانه سایت انجام نشد؛ لطفاً تصویر کوچک‌تر از ۲ مگابایت بفرستید.'), Keyboards::cancelOnly());
            return;
        }
        StateManager::clear($chatId);
        $this->api->sendMessage($chatId, "✅ عکس پروفایل با موفقیت بروزرسانی شد.", Keyboards::userMain());
        $this->showProfile($chatId);
    }

    // ───── دریافت رسید واریزی و ارسال آن برای بررسی ادمین ─────────
    private function handleReceiptUpload(string $chatId, string $fileId, string $fileName, array $user): void
    {
        $data     = StateManager::getData($chatId);
        $enrollId = (int)($data['receipt_enroll_id'] ?? 0);
        $enroll   = $enrollId ? Database::getEnrollmentById($enrollId) : null;

        if (!$enroll || (int)$enroll['user_id'] !== (int)$user['id']) {
            StateManager::clear($chatId);
            $this->api->sendMessage($chatId, "❌ ثبت‌نام مربوطه یافت نشد. لطفاً دوباره از منوی دوره‌ها اقدام کنید.", Keyboards::userMain());
            return;
        }

        try {
            $synced = MediaSync::transfer($this->api, $fileId, 'receipt', $enrollId, $fileName);
        } catch (SiteSyncException $error) {
            UpdateLifecycle::clear();Database::clearRetryError();
            $detail = MediaSync::lastError()['message'] ?? '';
            $this->api->sendMessage($chatId, "⚠️ انتقال رسید نیمه‌کاره ماند؛ لطفاً همین فایل را دوباره ارسال کنید." . ($detail !== '' ? "\n" . $detail : ''), Keyboards::cancelOnly());
            return;
        }
        if (!$synced) {
            $reason = MediaSync::lastError()['message'] ?? null;
            $this->api->sendMessage($chatId, "❌ " . ($reason ?: 'انتقال رسید به سایت انجام نشد؛ لطفاً تصویر واضح و کوچک‌تر از ۲ مگابایت ارسال کنید:'), Keyboards::cancelOnly());
            return;
        }
        try {
            $receiptSaved = Database::saveReceipt($enrollId, (string)$fileId);
        } catch (SiteSyncException $error) {
            UpdateLifecycle::clear();Database::clearRetryError();
            $detail = Database::lastError()['message'] ?? '';
            $this->api->sendMessage($chatId, "⚠️ ثبت رسید نیمه‌کاره ماند؛ لطفاً دوباره تلاش کنید." . ($detail !== '' ? "\n" . $detail : ''), Keyboards::cancelOnly());
            return;
        }
        if (!$receiptSaved) {
            $this->api->sendMessage($chatId, "❌ ثبت وضعیت فیش در سفارش سایت انجام نشد؛ دوباره تلاش کنید.", Keyboards::cancelOnly());
            return;
        }
        StateManager::clear($chatId);

        $this->api->sendMessage(
            $chatId,
            "✅ رسید شما ثبت شد و برای بررسی برای ادمین ارسال گردید.\n🔢 کد پیگیری: <code>{$enroll['tracking_code']}</code>\n\nپس از تأیید ادمین، ثبت‌نام شما نهایی خواهد شد.",
            Keyboards::userMain()
        );

        // ── ارسال رسید و اطلاعات پرداخت به همه ادمین‌ها ──
        $price   = number_format((int)$enroll['price']);
        $admins  = Database::getAllAdmins();
        $notice  = "🧾 <b>رسید پرداخت جدید</b>\n\n"
                 . "👤 کاربر: {$user['fl_name']}\n"
                 . "📞 تلفن: {$user['phone']}\n"
                 . "📖 دوره: {$enroll['course_title']}\n"
                 . "💰 مبلغ: {$price} تومان\n"
                 . "🔢 کد پیگیری: <code>{$enroll['tracking_code']}</code>";
        $confirmBtn = Keyboards::paymentConfirmButton($enrollId);
        foreach ($admins as $admin) {
            $this->api->sendPhoto((string)$admin['chat_id'], $fileId, $notice, $confirmBtn);
        }
    }

    // ───── اجرای پرداخت دوره طبق روش انتخاب‌شده (بله یا کارت‌به‌کارت) ─────
    private function processCoursePayment(string $chatId, int $msgId, int $courseId, array $course, string $method, array $user, int $productId = 0): void
    {
        global $config;
        if ($method === 'bale' && empty($config['payment_token'])) {
            $this->api->sendMessage($chatId, '⚠️ درگاه پرداخت بله هنوز توسط مدیر ربات پیکربندی نشده است.');
            return;
        }
        $variant = $productId > 0 ? $this->findCourseVariant($course, $productId) : null;
        if ($productId > 0 && !$variant) {
            $this->api->sendMessage($chatId, '❌ شیوه فروش انتخاب‌شده دیگر در سایت فعال نیست.');
            return;
        }
        $this->sendCoursePromo($chatId, $course);

        $trackingCode = Database::enrollUserPending((int)$user['id'], $courseId, $productId);
        if (!$trackingCode) {
            $error = Database::lastError();
            $this->api->sendMessage($chatId, '❌ ' . ($error['message'] ?? 'خطا در ثبت درخواست. مجدداً تلاش کنید.'));
            return;
        }

        $enroll = Database::getEnrollmentByUserCourse((int)$user['id'], $courseId, $productId);
        if (!$enroll) {
            $this->api->sendMessage($chatId, '❌ سفارش در سایت ساخته شد اما جزئیات نهایی آن در دسترس نیست؛ لطفاً دوباره تلاش کنید.');
            return;
        }
        // مبلغ از Total واقعی سفارش WooCommerce می‌آید تا مالیات و واحد ریال/تومان
        // باعث اختلاف فاکتور بله با سفارش سایت نشود.
        $priceValue = (int)$enroll['price'];
        $paymentAmountRial = (int)($enroll['payment_amount_rial'] ?? ($priceValue * 10));
        $price = number_format($priceValue);
        $variantLabel = trim((string)($variant['label'] ?? ''));
        $saleTitlePlain = (string)$course['title'] . ($variantLabel !== '' ? " — {$variantLabel}" : '');
        $saleTitle = self::h($saleTitlePlain);

        // ── درگاه آنلاین بله ──
        if ($method === 'bale') {
            $this->api->editMessageText(
                $chatId, $msgId,
                "💳 <b>پرداخت دوره: {$saleTitle}</b>\n\n💰 مبلغ: <b>{$price} تومان</b>\n🔢 کد پیگیری شما: <code>{$trackingCode}</code>\n\nبرای پرداخت روی فاکتور ارسالی کلیک کنید."
            );
            $payload = 'mph_order_' . (int)$enroll['id'];
            $invoice = $this->api->sendInvoice(
                $chatId,
                "ثبت‌نام دوره: {$saleTitlePlain}",
                ($course['description'] ?? '') . "\nکد پیگیری: {$trackingCode}",
                $payload,
                $config['payment_token'],
                [['label' => $saleTitlePlain, 'amount' => $paymentAmountRial]]
            );
            if (empty($invoice['ok'])) {
                $this->api->sendMessage($chatId, '❌ ساخت فاکتور بله انجام نشد. سفارش شما در سایت محفوظ است؛ چند لحظه بعد دوباره از همین دوره اقدام کنید.');
            }
            return;
        }

        // ── کارت‌به‌کارت با تأیید دستی ادمین ──
        $cardNumber = Database::getPaymentCardNumber();
        $cardHolder = Database::getPaymentCardHolder();
        $this->api->editMessageText(
            $chatId, $msgId,
            "💳 <b>پرداخت دوره: {$saleTitle}</b>\n\n"
            . "💰 مبلغ قابل پرداخت: <b>{$price} تومان</b>\n"
            . "🔢 کد پیگیری شما: <code>{$trackingCode}</code>\n\n"
            . "لطفاً مبلغ فوق را به شماره کارت زیر واریز کنید:\n"
            . "💳 <code>{$cardNumber}</code>\n"
            . ($cardHolder ? "👤 به نام: {$cardHolder}\n" : "")
            . "\nپس از واریز، روی دکمه زیر بزنید و عکس رسید را ارسال کنید. ✅",
            $enroll ? Keyboards::receiptStartButton((int)$enroll['id']) : []
        );
    }

    // ───── ارسال پیام تبلیغاتی دوره (اگر ثبت شده باشد) پیش از جزئیات ──
    private function sendCoursePromo(string $chatId, array $course): void
    {
        $type    = $course['promo_type']    ?? null;
        $content = $course['promo_content'] ?? null;
        if (!$type || !$content) return;

        $caption = $course['promo_caption'] ?? '';
        match ($type) {
            'photo' => $this->api->sendPhoto($chatId, $content, $caption),
            'video' => $this->api->sendVideo($chatId, $content, $caption),
            default => $this->api->sendMessage($chatId, $content),
        };
    }

    // ───── دوره‌های کاربر ─────────────────────────────────────────
    private function showMyCourses(string $chatId, array $user): void
    {
        $courses = Database::getUserCourses((int)$user['id']);
        if (empty($courses)) {
            $this->api->sendMessage($chatId, "📚 شما هنوز در هیچ دوره‌ای ثبت‌نام نکرده‌اید.");
            return;
        }
        $text = "📚 <b>دوره‌های من</b>\n\n";
        foreach ($courses as $i => $c) {
            $payStatus = match ($c['payment_status']) {
                'paid'    => '💳 پرداخت‌شده',
                'pending' => '⏳ در انتظار تأیید پرداخت',
                default   => '🆓 رایگان',
            };
            $mode = trim((string)($c['delivery_label'] ?? ''));
            $text .= ($i + 1) . ". <b>{$c['title']}</b>" . ($mode !== '' ? " — {$mode}" : '') . " [{$payStatus}]\n";
            $text .= "   📅 {$c['start_date']} تا {$c['end_date']}\n";
            $text .= "   🗓 ثبت‌نام: {$c['enrolled_at']}\n";
            if (!empty($c['tracking_code'])) {
                $text .= "   🔢 کد پیگیری: <code>{$c['tracking_code']}</code>\n";
            }
            $text .= "\n";
        }
        $this->api->sendMessage($chatId, $text);
    }

    // ───── نوبت‌های کاربر ─────────────────────────────────────────
    private function showMyAppointments(string $chatId, array $user): void
    {
        $appts = Database::getUserAppointments((int)$user['id']);
        if (empty($appts)) {
            $this->api->sendMessage($chatId, "📅 شما هنوز نوبتی رزرو نکرده‌اید.");
            return;
        }
        $text    = "📅 <b>نوبت‌های من</b>\n\n";
        $buttons = [];
        foreach ($appts as $i => $a) {
            $statusLabel = match ($a['status']) {
                'pending'   => '⏳ در انتظار',
                'confirmed' => '✅ تأییدشده',
                default     => $a['status'],
            };
            $dateLabel = preg_match('/^\d{4}-\d{2}-\d{2}$/', $a['date']) ? Keyboards::formatApptDate($a['date']) : $a['date'];
            $text .= "━━━━━━━━━━━━━━━━\n";
            $text .= ($i + 1) . ". 📅 {$dateLabel} ⏰ {$a['time_slot']}\n";
            $text .= "   📝 " . ($a['description'] ?: '—') . "\n";
            $text .= "   🔢 کد پیگیری: <code>{$a['tracking_code']}</code>\n";
            $text .= "   وضعیت: {$statusLabel}\n\n";
            $buttons[] = [['text' => "🗑 لغو نوبت {$dateLabel} {$a['time_slot']}", 'callback_data' => "delappt_confirm_{$a['id']}"]];
        }
        $this->api->sendInlineMessage($chatId, $text, $buttons);
    }

    // ───── گواهینامه‌های کاربر ────────────────────────────────────
    private function showMyCertificates(string $chatId, array $user): void
    {
        $certs = Database::getUserCertificates((int)$user['id']);
        if (empty($certs)) {
            $this->api->sendMessage($chatId, "🎓 هنوز گواهینامه‌ای برای شما صادر نشده است.");
            return;
        }
        $text = "🎓 <b>گواهینامه‌های من</b>\n\n";
        $buttons = [];
        foreach ($certs as $i => $cert) {
            $text .= "━━━━━━━━━━━━━━━━\n";
            $text .= ($i + 1) . ". <b>{$cert['title']}</b>\n";
            if (!empty($cert['course_title'])) {
                $text .= "   📚 دوره: {$cert['course_title']}\n";
            }
            $text .= "   🔢 شماره: <code>{$cert['cert_number']}</code>\n";
            $text .= "   📅 تاریخ صدور: {$cert['issue_date']}\n\n";
            if (!empty($cert['pdf_file_id'])) {
                $buttons[] = [['text' => "📄 دریافت PDF — {$cert['cert_number']}", 'callback_data' => "cert_pdf_{$cert['id']}"]];
            }
        }

        if (!empty($buttons)) {
            $this->api->sendInlineMessage($chatId, $text, $buttons);
        } else {
            $this->api->sendMessage($chatId, $text);
        }
    }

    // ───── نمایش دوره‌ها ──────────────────────────────────────────
    private function showCourses(string $chatId, int $page=1, int $messageId=0): void
    {
        $result = Database::coursePage($page);
        $courses = (array)($result['items']??[]);
        if (empty($courses)) {
            $this->api->sendMessage($chatId, "📚 در حال حاضر دوره‌ای برای ثبت‌نام وجود ندارد.");
            return;
        }
        $keyboard=Keyboards::courseList($courses);
        $navigation=[];
        if($page>1)$navigation[]=['text'=>'صفحه قبل','callback_data'=>'courses_page_'.($page-1)];
        if($page<(int)($result['pages']??1))$navigation[]=['text'=>'صفحه بعد','callback_data'=>'courses_page_'.($page+1)];
        if($navigation)array_splice($keyboard,max(0,count($keyboard)-1),0,[$navigation]);
        $text="📚 دوره‌های فعال — صفحه {$page}\n\nروی دوره موردنظر کلیک کنید:";
        if($messageId>0)$this->api->editMessageText($chatId,$messageId,$text,$keyboard);
        else $this->api->sendInlineMessage($chatId,$text,$keyboard);
    }

    // ───── جزئیات دوره ───────────────────────────────────────────
    private function showCourseDetail(string $chatId, int $courseId, array $user): void
    {
        $course = Database::getCourse($courseId);
        if (!$course) {
            $this->api->sendMessage($chatId, "❌ دوره یافت نشد.");
            return;
        }
        $this->sendCoursePromo($chatId, $course);

        $enrolled    = Database::isUserEnrolled((int)$user['id'], $courseId);
        $enrollCount = Database::getCourseEnrollCount($courseId);
        $capacity    = (int)($course['capacity'] ?? 0);
        $full        = $capacity > 0 && $enrollCount >= $capacity;
        $remaining   = $capacity > 0 ? (string)max(0, $capacity - $enrollCount) : 'نامحدود';

        $price = (int)($course['price'] ?? 0);
        $priceText = $price > 0 ? number_format($price) . " تومان" : "رایگان 🆓";

        $text = "📖 <b>{$course['title']}</b>\n\n"
              . "📝 {$course['description']}\n\n"
              . "📅 شروع: {$course['start_date']}\n"
              . "📅 پایان: {$course['end_date']}\n"
              . "👥 ظرفیت: " . ($capacity > 0 ? "{$capacity} نفر" : "نامحدود") . "\n"
             // . "✅ ثبت‌نام‌شده: {$enrollCount} نفر\n"
              . "🪑 ظرفیت باقی‌مانده: " . ($capacity > 0 ? "{$remaining} نفر" : $remaining) . "\n"
              . "💰 هزینه پایه: {$priceText}"
              . $this->deliveryModesText($course);

        $this->api->sendInlineMessage($chatId, $text, Keyboards::courseDetail($course, $enrolled, $full));
    }

    // ───── اخبار و اطلاعیه‌ها ──────────────────────────────────────
    private function showNews(string $chatId, string $type = 'news', int $idx = 0): void
    {
        $type  = $type === 'announcement' ? 'announcement' : 'news';
        $label = $type === 'announcement' ? 'اطلاعیه‌ها' : 'اخبار';
        $icon  = $type === 'announcement' ? '📢' : '📰';

        $news = Database::getNewsByType($type, 50);
        $total = count($news);

        if ($total === 0) {
            $text = "📭 در حال حاضر هیچ <b>{$label}</b>ی ثبت نشده است.";
            $this->api->sendInlineMessage($chatId, $text, Keyboards::newsNav($type, 0, 0));
            return;
        }

        $idx  = max(0, min($idx, $total - 1));
        $item = $news[$idx];

        $text = "{$icon} <b>{$label}</b>\n\n"
              . "━━━━━━━━━━━━━━━━\n"
              . "🔹 <b>{$item['title']}</b>\n\n"
              . "{$item['content']}\n\n"
              . "<i>📅 {$item['created_at']}</i>";

        $this->api->sendInlineMessage($chatId, $text, Keyboards::newsNav($type, $idx, $total));
    }

    // ویرایش پیام اخبار/اطلاعیه‌ها (هنگام جابجایی با دکمه‌ها)
    private function editNews(string $chatId, int $msgId, string $type = 'news', int $idx = 0): void
    {
        $type  = $type === 'announcement' ? 'announcement' : 'news';
        $label = $type === 'announcement' ? 'اطلاعیه‌ها' : 'اخبار';
        $icon  = $type === 'announcement' ? '📢' : '📰';

        $news  = Database::getNewsByType($type, 50);
        $total = count($news);

        if ($total === 0) {
            $text = "📭 در حال حاضر هیچ <b>{$label}</b>ی ثبت نشده است.";
            $this->api->editMessageText($chatId, $msgId, $text, Keyboards::newsNav($type, 0, 0));
            return;
        }

        $idx  = max(0, min($idx, $total - 1));
        $item = $news[$idx];

        $text = "{$icon} <b>{$label}</b>\n\n"
              . "━━━━━━━━━━━━━━━━\n"
              . "🔹 <b>{$item['title']}</b>\n\n"
              . "{$item['content']}\n\n"
              . "<i>📅 {$item['created_at']}</i>";

        $this->api->editMessageText($chatId, $msgId, $text, Keyboards::newsNav($type, $idx, $total));
    }

    // ───── رزرو نوبت ─────────────────────────────────────────────
    private function startAppointment(string $chatId): void
    {
        (new NativeHandler($this->api))->panel($chatId,'book_appointment');
        return;
        $user = Database::getUser($chatId) ?? [];
        $mode = (string) ($user['active_mode'] ?? 'user');
        $url = Database::getPanelUrl($chatId, $mode, 'book_appointment');
        if ($url === '') {
            $this->api->sendMessage($chatId, "⚠️ صفحه نوبت‌دهی سایت در دسترس نیست.", Keyboards::userMain());
            return;
        }
        $this->api->sendInlineMessage(
            $chatId,
            "📅 <b>رزرو نوبت متصل به سایت</b>\n\nبرای جلوگیری از رزرو هم‌زمان و نمایش درمانگر، تقویم شمسی، نوع جلسه، مبلغ و وضعیت واقعی پرداخت، رزرو در صفحه امن سایت تکمیل می‌شود.",
            [[['text'=>'📅 باز کردن تقویم نوبت‌دهی', 'url'=>$url]]]
        );
    }

    private function handleAppointment(string $chatId, string $text, string $step, array $update, array $user): void
    {
        if ($text === '❌ لغو') {
            StateManager::clear($chatId);
            $this->cancelAndBack($chatId);
            return;
        }
        if ($step === 'appt_desc') {
            $data   = StateManager::getData($chatId);
            $booked = Database::getBookedSlotsForDay($data['day']);
            if (in_array($data['time'], $booked, true)) {
                StateManager::clear($chatId);
                $this->api->sendMessage(
                    $chatId,
                    "⚠️ متأسفانه این نوبت هم‌اکنون توسط فرد دیگری رزرو شد. لطفاً دوباره تلاش کنید.",
                    Keyboards::userMain()
                );
                return;
            }
            $trackingCode = Database::createAppointment((int)$user['id'], $data['day'], $data['time'], $text);
            StateManager::clear($chatId);
            if (!$trackingCode) {
                $this->api->sendMessage($chatId, "❌ خطایی در ثبت نوبت رخ داد. لطفاً دوباره تلاش کنید.", Keyboards::userMain());
                return;
            }
            $this->api->sendMessage(
                $chatId,
                "✅ <b>نوبت شما ثبت شد!</b>\n\n📅 روز: " . ($data['day_label'] ?? $data['day']) . "\n⏰ ساعت: {$data['time']}\n📝 توضیحات: {$text}\n\n🔢 کد پیگیری شما: <code>{$trackingCode}</code>",
                Keyboards::userMain()
            );
        }
    }

    // ───── ارتباط با ادمین ────────────────────────────────────────
    private function startContactAdmin(string $chatId): void
    {
        StateManager::set($chatId, 'contact_write');
        $this->api->sendMessage($chatId, "✉️ <b>ارتباط با ادمین</b>\n\nپیام خود را بنویسید:", Keyboards::cancelOnly());
    }

    private function handleContactAdmin(string $chatId, string $text, array $user, array $msg = []): void
    {
        if ($text === '❌ لغو') {
            StateManager::clear($chatId);
            $this->cancelAndBack($chatId);
            return;
        }

        // تشخیص پیوست (عکس یا فایل) همراه با کپشن
        $fileId   = null;
        $fileType = null;
        $caption  = trim($msg['caption'] ?? '');

        if (!empty($msg['photo'])) {
            $fileId   = end($msg['photo'])['file_id'] ?? null;
            $fileType = 'photo';
            $text     = $caption !== '' ? $caption : '(بدون متن)';
        } elseif (!empty($msg['document'])) {
            $fileId   = $msg['document']['file_id'] ?? null;
            $fileType = 'document';
            $text     = $caption !== '' ? $caption : ($msg['document']['file_name'] ?? '(فایل بدون نام)');
        }

        if (!$fileId && trim($text) === '') {
            $this->api->sendMessage($chatId, "⚠️ پیام نمی‌تواند خالی باشد. لطفاً متن، عکس یا فایل خود را ارسال کنید:", Keyboards::cancelOnly());
            return;
        }

        $msgId = Database::saveMessage((int)$user['id'], $text, $fileId, $fileType);
        if ($msgId <= 0) {
            $error = Database::lastError();
            $this->api->sendMessage($chatId, "❌ " . ($error['message'] ?? 'ثبت تیکت در سایت انجام نشد.'), Keyboards::cancelOnly());
            return;
        }
        $attachmentSynced = true;
        if ($fileId) {
            $fileName = !empty($msg['document']['file_name']) ? (string)$msg['document']['file_name'] : '';
            try {
                $attachmentSynced = (bool)MediaSync::transfer($this->api, (string)$fileId, 'ticket', $msgId, $fileName);
            } catch (SiteSyncException $error) {
                UpdateLifecycle::clear();Database::clearRetryError();
                $attachmentSynced = false;
            }
        }
        Database::openOrCreateChat((int)$user['id']);
        StateManager::clear($chatId);

        $sentText = "✅ پیام شما ارسال شد.\nادمین در اسرع وقت پاسخ خواهد داد.";
        if (!$attachmentSynced) $sentText .= "\n⚠️ متن ثبت شد اما انتقال پیوست کامل نشد (" . (MediaSync::lastError()['message'] ?? 'خطای نامشخص') . ')؛ در صورت نیاز دوباره ارسال کنید.';
        $this->api->sendMessage($chatId, $sentText, Keyboards::userMain());
        $this->api->sendInlineMessage(
            $chatId,
            "می‌توانید پیام جدیدی ارسال کنید یا پیام‌های قبلی خود را ببینید:",
            Keyboards::contactReplyOptions()
        );

        // ارسال به همه ادمین‌ها
        $admins   = Database::getAllAdmins();
        $safeMessage = self::h($text);
        $notice   = "📨 <b>پیام جدید از کاربر</b>\n"
                  . "👤 نام: " . self::h((string)($user['fl_name'] ?? 'کاربر سایت')) . "\n"
                  . "🆔 شناسه: <code>{$chatId}</code>\n\n"
                  . "💬 {$safeMessage}";
        $replyBtn = [[['text' => '↩️ پاسخ دادن', 'callback_data' => "reply_msg_{$msgId}"]]];

        foreach ($admins as $admin) {
            $adminChatId = trim((string)($admin['chat_id'] ?? ''));
            if ($adminChatId === '') continue;
            if ($fileType === 'photo') {
                $this->api->sendPhoto($adminChatId, $fileId, $notice, $replyBtn);
            } elseif ($fileType === 'document') {
                $this->api->sendDocument($adminChatId, $fileId, $notice);
                $this->api->sendInlineMessage($adminChatId, "👆 برای پاسخ به پیام بالا:", $replyBtn);
            } else {
                $this->api->sendInlineMessage($adminChatId, $notice, $replyBtn);
            }
        }
    }

    // ───── نمایش تاریخچه پیام‌های کاربر با ادمین ─────────────────
    private function showContactHistory(string $chatId, array $user): void
    {
        $history = Database::getUserMessageHistory((int)$user['id'], 10);
        if (empty($history)) {
            $this->api->sendMessage($chatId, "📭 شما هنوز پیامی برای ادمین ارسال نکرده‌اید.");
            return;
        }
        $text = "📜 <b>پیام‌های قبلی شما</b>\n\n";
        foreach (array_reverse($history) as $m) {
            $text .= "━━━━━━━━━━━━━━━━\n";
            $text .= "📅 {$m['created_at']}\n";
            $text .= "💬 شما: " . self::h((string)$m['message']) . "\n";
            $text .= $m['reply'] ? "↩️ ادمین: " . self::h((string)$m['reply']) . "\n" : "⏳ هنوز پاسخ داده نشده\n";
        }
        $this->api->sendInlineMessage($chatId, $text, Keyboards::contactReplyOptions());
    }

    // ───── پرداخت موفق ───────────────────────────────────────────
    public function handleSuccessfulPayment(array $update, array $user): bool
    {
        $msg     = $update['message'] ?? null;
        $payment = $msg['successful_payment'] ?? null;
        if (!$payment) return true;

        $chatId  = (string)($msg['chat']['id'] ?? '');
        $payload = $payment['invoice_payload'] ?? '';
        $payId   = trim((string)($payment['telegram_payment_charge_id'] ?? $payment['provider_payment_charge_id'] ?? ''));

        // فاکتور جدید به شناسه دقیق سفارش متصل است؛ فرمت قدیمی نیز خوانده می‌شود.
        $orderId = preg_match('/^mph_order_(\d+)$/', (string)$payload, $orderMatch) ? (int)$orderMatch[1] : 0;
        if ($orderId || preg_match('/^course_PAY_(\d+)(?:_(\d+))?$/', (string)$payload, $m)) {
            $courseId = $orderId ? 0 : (int)$m[1];
            $productId = !$orderId && isset($m[2]) ? (int)$m[2] : 0;
            $enroll = $orderId ? Database::getEnrollmentById($orderId) : Database::getEnrollmentByUserCourse((int)$user['id'], $courseId, $productId);
            $enrollmentError = Database::lastError();
            if ($orderId && $enroll) {
                $courseId = (int)($enroll['course_id'] ?? 0);
                $productId = (int)($enroll['product_id'] ?? 0);
            }
            $expectedRial = $enroll ? (int)($enroll['payment_amount_rial'] ?? ((int)$enroll['price'] * 10)) : -1;
            $validAmount = $enroll
                && strtoupper((string)($payment['currency'] ?? '')) === 'IRR'
                && (int)($payment['total_amount'] ?? -1) === $expectedRial;
            if (!$enroll && $enrollmentError) return false;
            if (!$validAmount || $payId === '' || (string)($enroll['user_chat_id'] ?? '') !== $chatId) {
                $safePayId = self::h($payId ?: 'نامشخص');
                $this->api->sendMessage($chatId, "⚠️ پرداخت دریافت شد اما اطلاعات آن با سفارش سایت مطابقت ندارد؛ کد پرداخت را برای پشتیبانی ارسال کنید: <code>{$safePayId}</code>");
                return true;
            }
            if (($enroll['payment_status'] ?? '') === 'paid') {
                // Retry همان SuccessfulPayment بی‌صدا و بدون پیام/دسترسی تکراری پایان می‌یابد.
                if ((string)($enroll['payment_id'] ?? '') !== '' && hash_equals((string)$enroll['payment_id'], $payId)) {
                    if (!empty($enroll['access_synced'])) return true;
                } else {
                    $this->api->sendMessage($chatId, '⚠️ این سفارش قبلاً با شناسه پرداخت دیگری قطعی شده است؛ لطفاً با پشتیبانی تماس بگیرید.');
                    return true;
                }
            }

            $inquiry = $this->api->inquireTransaction($payId);
            if (empty($inquiry['ok'])) return false;
            $transaction = is_array($inquiry['result'] ?? null) ? $inquiry['result'] : [];
            $transactionUser = (string)($transaction['userID'] ?? '');
            $verifiedTransaction = strtolower((string)($transaction['status'] ?? '')) === 'paid'
                && (int)($transaction['amount'] ?? -2) === $expectedRial
                && ($transactionUser === '' || hash_equals((string)$chatId, $transactionUser));
            if (!$verifiedTransaction) {
                $safePayId = self::h($payId);
                $this->api->sendMessage($chatId, "⚠️ نتیجه استعلام تراکنش با سفارش سایت مطابقت ندارد؛ کد پرداخت را برای پشتیبانی ارسال کنید: <code>{$safePayId}</code>");
                return true;
            }
            if (!Database::confirmEnrollment((int)$user['id'], $courseId, (string)$payId, $productId, $orderId, $expectedRial)) {
                $confirmError = Database::lastError();
                if (($confirmError['code'] ?? '') === 'amount_mismatch') {
                    $safePayId = self::h($payId);
                    $this->api->sendMessage($chatId, "⚠️ مبلغ پرداخت‌شده با سفارش سایت مطابقت ندارد و ثبت‌نام قطعی نشد؛ کد پرداخت را برای پشتیبانی ارسال کنید: <code>{$safePayId}</code>");
                    return true;
                }
                return false;
            }
            $trackCode = $enroll['tracking_code'] ?? null;
            $variantLabel = trim((string)($enroll['delivery_label'] ?? ''));
            $saleTitle = self::h((string)($enroll['course_title'] ?? 'دوره') . ($variantLabel !== '' ? " — {$variantLabel}" : ''));
            $payId = self::h($payId);
            $this->api->sendMessage(
                $chatId,
                "✅ <b>پرداخت موفق!</b>\n\nثبت‌نام شما در دوره «{$saleTitle}» تأیید شد."
                . ($trackCode ? "\n🔢 کد پیگیری: <code>{$trackCode}</code>" : "")
                . "\n🧾 شناسه پرداخت: <code>{$payId}</code>",
                Keyboards::userMain()
            );
            return true;
        }
        return true;
    }

    // ───── Callback Queries ───────────────────────────────────────
    private function showTicketPush(string $chatId, string $cbId, int $ticketId): void
    {
        SiteClient::setActorChatId($chatId);
        try {
            $reply = Database::ticketLatestReply($chatId, $ticketId);
        } catch (SiteSyncException $error) {
            $this->api->answerCallbackQuery($cbId, '❌ ارتباط با سایت برقرار نشد؛ دوباره تلاش کنید.', true);
            return;
        }
        if (!$reply) {
            $this->api->answerCallbackQuery($cbId, '❌ پاسخ تازه‌ای برای این تیکت پیدا نشد.', true);
            return;
        }
        $this->api->answerCallbackQuery($cbId, '');
        $subject = trim((string)($reply['subject'] ?? ''));
        $text = ($subject !== '' ? '🎫 ' . $subject . "\n\n" : '') . (string)($reply['message'] ?? '');
        $this->api->sendMessage($chatId, $text !== '' ? $text : 'متن پاسخ خالی است.', Keyboards::userMain());
        $attachmentId = (int)($reply['attachment_id'] ?? 0);
        $file = is_array($reply['file'] ?? null) ? $reply['file'] : null;
        if ($attachmentId > 0 && $file) {
            try {
                $payload = Database::ticketMessageFile($chatId, $ticketId, $attachmentId);
            } catch (SiteSyncException $error) {
                $payload = null;
            }
            $raw = is_array($payload) ? base64_decode((string)($payload['data'] ?? ''), true) : false;
            if (is_string($raw) && $raw !== '') {
                $tmp = tempnam(sys_get_temp_dir(), 'bale_ticket_');
                if ($tmp !== false && file_put_contents($tmp, $raw) === strlen($raw)) {
                    $mime = (string)($payload['mime'] ?? ($file['mime'] ?? ''));
                    $name = trim((string)($payload['name'] ?? '')) !== '' ? trim((string)$payload['name']) : 'ticket-file';
                    if (str_starts_with($mime, 'image/')) {
                        $this->api->sendLocalPhoto($chatId, $tmp, $name);
                    } else {
                        $this->api->sendDocument($chatId, new CURLFile($tmp, $mime !== '' ? $mime : 'application/octet-stream', $name), $name);
                    }
                    @unlink($tmp);
                }
            } else {
                $this->api->sendMessage($chatId, '⚠️ دانلود پیوست پاسخ ممکن نبود؛ از داخل سایت آن را ببینید.', Keyboards::userMain());
            }
        }
        try {
            Database::ticketMarkUserRead($chatId, $ticketId);
        } catch (SiteSyncException $error) {
            // خوانده‌شدن در سایت ثبت نشد؛ مهم نیست.
        }
    }

    public function handleCallback(array $update, array $user): void
    {
        $cb     = $update['callback_query'];
        $chatId = (string)($cb['message']['chat']['id'] ?? '');
        $msgId  = (int)($cb['message']['message_id'] ?? 0);
        $cbId   = $cb['id'];
        $data   = $cb['data'] ?? '';

        try {

        // سرعت: برای دکمه‌های «فقط ناوبری» همان ابتدا پاسخ خالی می‌دهیم تا چرخان بودن دکمه تمام شود؛
        // دکمه‌هایی که ممکن است هشدار نشان دهند (خرید، پرداخت، ثبت‌نام) عمداً در این فهرست نیستند.
        if (preg_match('/^(back_main|back_courses|courses_page_\d+|course_\d+|oc:[ldr](:.*)?|mg:.*|mp:.*|mc:.*|site_role_.*|show_profile|my_courses|my_certs|newsnav_.*|newssw_.*|n:(cart|orders|therapists|slots:.*|ticket:list))$/D', (string)$data)) {
            $this->api->answerCallbackQuery((string)$cbId);
        }
        if ((new OpenCoursesHandler($this->api))->callback($chatId, (int)$msgId, (string)$data, (string)$cbId)) return;
        if ((new MyCoursesHandler($this->api))->callback($chatId, (int)$msgId, (string)$data)) return;
        // ── منوی سایت: گروه‌ها (mg:<id>) و بخش‌ها (mp:<id>) ──
        if (preg_match('/^mg:([a-z0-9_\-]{1,40})$/D', (string)$data, $groupMatch)) {
            Keyboards::setUserContext($user);
            $this->showGroup($chatId, $groupMatch[1], (int)$msgId);
            return;
        }
        if (preg_match('/^mp:([a-z0-9_\-]{1,40})$/D', (string)$data, $panelMatch)) {
            Keyboards::setUserContext($user);
            $found = Keyboards::findEntry($panelMatch[1]);
            if (!$found || ($found['type'] ?? '') !== 'panel') {
                $this->api->answerCallbackQuery((string)$cbId, 'این بخش دیگر در منو نیست؛ /start را بزنید.', true);
                return;
            }
            unset($found['entry']);
            $this->handleSiteSelection($chatId, $found, $user);
            return;
        }
        if((new NativeHandler($this->api))->callback($chatId,(string)$data))return;
        // ── noop ──
        if ($data === 'noop') return;

        // ── مشاهده پاسخ تازه پشتیبانی (دکمه پوش تیکت) ──
        if (preg_match('/^ticket_view_(\d+)$/D', (string)$data, $ticketMatch)) {
            $this->showTicketPush($chatId, (string)$cbId, (int)$ticketMatch[1]);
            return;
        }

        if (preg_match('/^site_role_(user|instructor|therapist|manager)$/D', $data, $roleMatch)) {
            $this->handleSiteSelection($chatId, ['type'=>'role','mode'=>$roleMatch[1]], $user);
            return;
        }

        // ── بازگشت ──
        if ($data === 'back_main') {
            $this->sendMainMenu($chatId, $user);
            return;
        }

        // ── لیست دوره‌ها ──
        if ($data === 'back_courses') {
            $this->showCourses($chatId,1,(int)$msgId);
            return;
        }
        if (preg_match('/^courses_page_(\d+)$/',$data,$pageMatch)) { $this->showCourses($chatId,max(1,(int)$pageMatch[1]),(int)$msgId); return; }

        // ── انتخاب شیوه واقعی فروش دوره از محصولات متصل سایت ──
        if (preg_match('/^course_variant_(\d+)_(\d+)$/', $data, $variantMatch)) {
            $courseId = (int)$variantMatch[1];
            $productId = (int)$variantMatch[2];
            $course = Database::getCourse($courseId);
            $variant = $course ? $this->findCourseVariant($course, $productId) : null;
            if (!$course || !$variant) {
                $this->api->answerCallbackQuery($cbId, '❌ این شیوه فروش دیگر فعال نیست.', true);
                return;
            }
            if (!empty($variant['full'])) {
                $this->api->answerCallbackQuery($cbId, '🚫 ظرفیت این شیوه تکمیل است.', true);
                return;
            }
            (new NativeHandler($this->api))->callback($chatId,'n:add:'.$productId);
            return;

            $priceValue = (int)round((float)($variant['price'] ?? 0));
            $variantLabel = trim((string)($variant['label'] ?? 'شیوه انتخابی'));
            if ($priceValue <= 0) {
                $this->sendCoursePromo($chatId, $course);
                $trackingCode = Database::enrollUser((int)$user['id'], $courseId, $productId);
                if (!$trackingCode) {
                    $error = Database::lastError();
                    $this->api->answerCallbackQuery($cbId, '❌ ' . ($error['message'] ?? 'ثبت‌نام انجام نشد.'), true);
                    return;
                }
                $this->api->editMessageText($chatId, $msgId, "✅ ثبت‌نام «{$course['title']} — {$variantLabel}» انجام شد.\n\n🔢 کد پیگیری: <code>{$trackingCode}</code>");
                $this->notifyCourseEnrollmentAdmins($user, $course, $variantLabel, $trackingCode);
                return;
            }

            $method = Database::getPaymentMethod();
            if ($method === 'both') {
                $price = number_format($priceValue);
                $this->api->editMessageText($chatId, $msgId, "💳 <b>{$course['title']} — {$variantLabel}</b>\n\n💰 مبلغ: <b>{$price} تومان</b>\n\nروش پرداخت را انتخاب کنید:", Keyboards::paymentMethodChoice($courseId, $productId));
                return;
            }
            $this->processCoursePayment($chatId, $msgId, $courseId, $course, $method, $user, $productId);
            return;
        }

        // ── نمایش جزئیات دوره ──
        if (str_starts_with($data, 'course_') && !str_starts_with($data, 'course_pay_') && !str_starts_with($data, 'course_enroll_') && !str_starts_with($data, 'course_variant_')) {
            $courseId = (int)str_replace('course_', '', $data);
            $this->showCourseDetailInline($chatId, $msgId, $courseId, $user);
            return;
        }

        // ── ثبت‌نام رایگان ──
        if (str_starts_with($data, 'course_enroll_')) {
            $courseId = (int)str_replace('course_enroll_', '', $data);
            $course   = Database::getCourse($courseId);
            if (!$course) return;
            $enrollCount = Database::getCourseEnrollCount($courseId);
            if ((int)$course['capacity'] > 0 && $enrollCount >= (int)$course['capacity']) {
                $this->api->answerCallbackQuery($cbId, '🚫 ظرفیت تکمیل است!', true);
                return;
            }
            if (Database::isUserEnrolled((int)$user['id'], $courseId)) {
                $this->api->answerCallbackQuery($cbId, '⚠️ قبلاً ثبت‌نام کرده‌اید.', true);
                return;
            }
            $this->sendCoursePromo($chatId, $course);
            $trackingCode = Database::enrollUser((int)$user['id'], $courseId);
            if (!$trackingCode) {
                $this->api->answerCallbackQuery($cbId, '❌ خطا در ثبت‌نام.', true);
                return;
            }
            $this->api->editMessageText(
                $chatId, $msgId,
                "✅ ثبت‌نام شما در دوره «{$course['title']}» با موفقیت انجام شد!\n\n🔢 کد پیگیری: <code>{$trackingCode}</code>"
            );

            $this->notifyCourseEnrollmentAdmins($user, $course, '', $trackingCode);
            return;
        }

        // ── پرداخت دوره: انتخاب روش پرداخت (اگر هر دو روش فعال باشد) یا شروع مستقیم ──
        if (str_starts_with($data, 'course_pay_')) {
            if (!preg_match('/^course_pay_(\d+)(?:_(\d+))?$/', $data, $payMatch)) return;
            $courseId = (int)$payMatch[1];
            $productId = isset($payMatch[2]) ? (int)$payMatch[2] : 0;
            $course   = Database::getCourse($courseId);
            if (!$course) return;
            $variant = $productId > 0 ? $this->findCourseVariant($course, $productId) : null;
            if ($productId > 0 && !$variant) return;
            $enrollCount = Database::getCourseEnrollCount($courseId);
            $legacyFull = (int)$course['capacity'] > 0 && $enrollCount >= (int)$course['capacity'];
            if (($variant && !empty($variant['full'])) || (!$variant && $legacyFull)) {
                $this->api->answerCallbackQuery($cbId, '🚫 ظرفیت تکمیل است!', true);
                return;
            }
            if ($productId > 0 && $this->existingVariantOrderBlocks($cbId, $user, $courseId, $productId)) return;

            $method = Database::getPaymentMethod();
            if ($method === 'both') {
                $price = number_format((int)round((float)($variant['price'] ?? $course['price'])));
                $this->api->editMessageText(
                    $chatId, $msgId,
                    "💳 <b>پرداخت دوره: {$course['title']}</b>\n\n💰 مبلغ: <b>{$price} تومان</b>\n\nروش پرداخت را انتخاب کنید:",
                    Keyboards::paymentMethodChoice($courseId, $productId)
                );
                return;
            }
            $this->processCoursePayment($chatId, $msgId, $courseId, $course, $method, $user, $productId);
            return;
        }

        // ── انتخاب روش پرداخت پس از نمایش هر دو گزینه ──
        if (preg_match('/^pay_choose_(bale|card)_(\d+)(?:_(\d+))?$/', $data, $chooseMatch)) {
            $method   = $chooseMatch[1];
            $courseId = (int)$chooseMatch[2];
            $productId = isset($chooseMatch[3]) ? (int)$chooseMatch[3] : 0;
            $course   = Database::getCourse($courseId);
            if (!$course) return;
            $variant = $productId > 0 ? $this->findCourseVariant($course, $productId) : null;
            if ($productId > 0 && !$variant) return;
            if ($productId > 0 && $this->existingVariantOrderBlocks($cbId, $user, $courseId, $productId)) return;
            $this->processCoursePayment($chatId, $msgId, $courseId, $course, $method, $user, $productId);
            return;
        }

        // ── شروع ارسال رسید (بعد از کلیک «واریز کردم») ──
        if (str_starts_with($data, 'receipt_start_')) {
            $enrollId = (int)str_replace('receipt_start_', '', $data);
            $enroll   = Database::getEnrollmentById($enrollId);
            if (!$enroll || (int)$enroll['user_id'] !== (int)$user['id']) {
                $this->api->answerCallbackQuery($cbId, '❌ این ثبت‌نام متعلق به شما نیست.', true);
                return;
            }
            if ($enroll['payment_status'] === 'paid') {
                $this->api->answerCallbackQuery($cbId, '✅ این پرداخت قبلاً تأیید شده است.', true);
                return;
            }
            StateManager::set($chatId, 'awaiting_receipt', ['receipt_enroll_id' => $enrollId]);
            $this->api->sendMessage(
                $chatId,
                "🧾 لطفاً عکس رسید واریزی خود را ارسال کنید:\n🔢 کد پیگیری: <code>{$enroll['tracking_code']}</code>",
                Keyboards::cancelOnly()
            );
            return;
        }

        // ── نمایش پروفایل ──
        if ($data === 'show_profile') {
            $this->showProfile($chatId);
            return;
        }

        // ── ویرایش پروفایل (Inline select) ──
        if ($data === 'edit_profile') {
            $this->api->editMessageCaption(
                $chatId, $msgId,
                "✏️ <b>ویرایش پروفایل</b>\n\nکدام بخش را می‌خواهید ویرایش کنید؟",
                Keyboards::profileEditFields()
            );
            return;
        }

        if (str_starts_with($data, 'edit_field_')) {
            $field = str_replace('edit_field_', '', $data);
            if ($field === 'phone') {
                StateManager::set($chatId, 'edit_profile_phone');
                $this->api->sendMessage($chatId, "📱 برای تغییر شماره، دکمه زیر را بزنید و شماره متعلق به همین حساب بله را تأیید کنید:", Keyboards::ownContact());
            } elseif ($field === 'photo') {
                StateManager::set($chatId, 'edit_profile_photo');
                $this->api->sendMessage($chatId, "🖼 <b>تغییر عکس پروفایل</b>\n\nعکس جدید خود را ارسال کنید:", Keyboards::cancelOnly());
            } elseif ($field === 'education_level') {
                StateManager::set($chatId, 'edit_profile_education_level');
                $this->api->sendMessage($chatId, "✏️ <b>مقطع تحصیلی</b> جدید را انتخاب کنید:", Keyboards::educationLevels());
            } elseif ($field === 'email') {
                StateManager::set($chatId, 'edit_profile_email');
                $this->api->sendMessage($chatId, "✏️ <b>ایمیل</b> جدید را وارد کنید (مثال: name@example.com):\nلینک تأیید به ایمیل جدید ارسال می‌شود و تا تأیید نشود، ایمیل قبلی معتبر می‌ماند.", Keyboards::cancelOnly());
            } else {
                $labels = [
                    'first_name'     => 'نام',
                    'last_name'      => 'نام‌خانوادگی',
                    'first_name_en'  => 'نام به انگلیسی (مثال: Ali)',
                    'last_name_en'   => 'نام‌خانوادگی به انگلیسی (مثال: Rezaei)',
                    'phone'          => 'شماره تلفن',
                    'id_card'        => 'کد ملی',
                    'birthday'       => 'تاریخ تولد (مثال: ۱۳۷۰/۰۵/۱۵)',
                    'address'        => 'آدرس',
                    'field_of_study' => 'رشته تحصیلی',
                ];
                $label = $labels[$field] ?? $field;
                StateManager::set($chatId, "edit_profile_{$field}");
                $this->api->sendMessage($chatId, "✏️ <b>{$label}</b> جدید را وارد کنید:", Keyboards::cancelOnly());
            }
            return;
        }

        // ── دوره‌های من از پروفایل ──
        if ($data === 'my_courses') {
            (new MyCoursesHandler($this->api))->show($chatId, '');
            return;
        }

        // ── گواهینامه‌هایم از پروفایل ──
        if ($data === 'my_certs') {
            $this->showMyCertificates($chatId, $user);
            return;
        }

        // ── اخبار: ناوبری درون دسته ──
        if (str_starts_with($data, 'newsnav_')) {
            $rest = str_replace('newsnav_', '', $data);
            $parts = explode('_', $rest);
            $idx   = (int)array_pop($parts);
            $type  = implode('_', $parts) ?: 'news';
            $this->editNews($chatId, $msgId, $type, $idx);
            return;
        }

        // ── اخبار: جابجایی بین اخبار و اطلاعیه‌ها ──
        if (str_starts_with($data, 'newssw_')) {
            $type = str_replace('newssw_', '', $data);
            $this->editNews($chatId, $msgId, $type, 0);
            return;
        }

        // ── رزرو نوبت ──
        if (str_starts_with($data, 'appt_day_')) {
            $dateStr   = str_replace('appt_day_', '', $data);
            $dayLabel  = Keyboards::formatApptDate($dateStr);

            $allSlots = Keyboards::getAllSlots();
            $booked   = Database::getBookedSlotsForDay($dateStr);

            if (count(array_diff($allSlots, $booked)) === 0) {
                $this->api->editMessageText(
                    $chatId, $msgId,
                    "❌ متأسفانه <b>هیچ نوبتی</b> برای روز <b>{$dayLabel}</b> باقی نمانده است.\n\nلطفاً روز دیگری را انتخاب کنید:",
                    Keyboards::appointmentDays()
                );
                return;
            }

            StateManager::set($chatId, 'appt_time', ['day' => $dateStr, 'day_label' => $dayLabel]);
            $this->api->editMessageText(
                $chatId, $msgId,
                "📅 روز: <b>{$dayLabel}</b>\n\nساعت موردنظر را انتخاب کنید:",
                Keyboards::appointmentTimes($booked)
            );
            return;
        }

        if ($data === 'appt_back_days') {
            $this->api->editMessageText(
                $chatId, $msgId,
                "📅 <b>رزرو نوبت</b>\n\nلطفاً روز موردنظر را انتخاب کنید:",
                Keyboards::appointmentDays()
            );
            return;
        }

        if (str_starts_with($data, 'appt_time_')) {
            $time     = str_replace('appt_time_', '', $data);
            $data2    = StateManager::getData($chatId);
            $dateStr  = $data2['day'] ?? null;
            $dayLabel = $data2['day_label'] ?? $dateStr;

            // بررسی مجدد برای رفع وضعیت رقابتی (Race Condition)
            if ($dateStr) {
                $booked = Database::getBookedSlotsForDay($dateStr);
                if (in_array($time, $booked, true)) {
                    $this->api->answerCallbackQuery($cbId, '⚠️ این نوبت هم‌اکنون رزرو شد. ساعت دیگری انتخاب کنید.', true);
                    $this->api->editMessageText(
                        $chatId, $msgId,
                        "📅 روز: <b>{$dayLabel}</b>\n\nساعت موردنظر را انتخاب کنید:",
                        Keyboards::appointmentTimes($booked)
                    );
                    return;
                }
            }

            StateManager::set($chatId, 'appt_desc', ['time' => $time]);
            $this->api->editMessageText($chatId, $msgId, "📅 روز: <b>{$dayLabel}</b>\n⏰ ساعت: <b>{$time}</b>\n\nلطفاً <b>توضیحات</b> یا دلیل مراجعه را بنویسید:");
            return;
        }

        // ── دریافت PDF گواهینامه ──
        if (str_starts_with($data, 'cert_pdf_')) {
            $certId = (int)str_replace('cert_pdf_', '', $data);
            $cert   = Database::getCertificateById($certId);
            if (!$cert || (int)$cert['user_chat_id'] !== (int)$user['id'] || empty($cert['pdf_file_id'])) {
                $this->api->answerCallbackQuery($cbId, '❌ فایل یافت نشد.', true);
                return;
            }
            $this->api->sendDocument($chatId, $cert['pdf_file_id'], "🎓 گواهینامه: {$cert['title']}\n🔢 {$cert['cert_number']}");
            return;
        }

        // ── ارتباط با ادمین: ادامه گفتگو ──
        if ($data === 'contact_again') {
            StateManager::set($chatId, 'contact_write');
            $this->api->sendMessage($chatId, "✉️ پیام خود را بنویسید (متن، عکس یا فایل):", Keyboards::cancelOnly());
            return;
        }

        // ── ارتباط با ادمین: تاریخچه پیام‌ها ──
        if ($data === 'contact_history') {
            $this->showContactHistory($chatId, $user);
            return;
        }

        // ── لغو نوبت: تأیید ──
        if (str_starts_with($data, 'delappt_confirm_')) {
            $id   = (int)str_replace('delappt_confirm_', '', $data);
            $appt = Database::getAppointmentById($id);
            if (!$appt || (int)$appt['user_id'] !== (int)$user['id']) {
                $this->api->answerCallbackQuery($cbId, '❌ نوبت یافت نشد.', true);
                return;
            }
            $dateLabel = preg_match('/^\d{4}-\d{2}-\d{2}$/', $appt['date']) ? Keyboards::formatApptDate($appt['date']) : $appt['date'];
            $this->api->editMessageText(
                $chatId, $msgId,
                "⚠️ آیا از لغو نوبت روز <b>{$dateLabel}</b> ساعت <b>{$appt['time_slot']}</b> مطمئن هستید؟",
                Keyboards::apptCancelConfirm($id)
            );
            return;
        }

        // ── لغو نوبت: اجرا ──
        if (str_starts_with($data, 'delappt_do_')) {
            $id = (int)str_replace('delappt_do_', '', $data);
            $ok = Database::cancelAppointment($id, (int)$user['id']);
            $cancelError = $ok ? null : Database::lastError();
            $this->api->editMessageText($chatId, $msgId, $ok ? "✅ نوبت با موفقیت لغو شد." : "❌ " . ($cancelError['message'] ?? 'خطا در لغو نوبت.'));
            return;
        }

        // ── لغو نوبت: انصراف ──
        if ($data === 'delappt_cancel') {
            $this->api->editMessageText($chatId, $msgId, "❌ از لغو نوبت منصرف شدید.");
            return;
        }
        } finally {
            $this->api->answerCallbackQueryIfPending((string)$cbId);
        }
    }

    // نمایش جزئیات دوره: حذف پیام لیست، سپس بنر، سپس پیام جزئیات/پرداخت
    private function showCourseDetailInline(string $chatId, int $msgId, int $courseId, array $user): void
    {
        $course = Database::getCourse($courseId);
        if (!$course) return;

        $this->api->deleteMessage($chatId, $msgId);
        $this->sendCoursePromo($chatId, $course);

        $enrolled    = Database::isUserEnrolled((int)$user['id'], $courseId);
        $enrollCount = Database::getCourseEnrollCount($courseId);
        $capacity    = (int)($course['capacity'] ?? 0);
        $full        = $capacity > 0 && $enrollCount >= $capacity;
        $remaining   = $capacity > 0 ? (string)max(0, $capacity - $enrollCount) : 'نامحدود';
        $price       = (int)($course['price'] ?? 0);
        $priceText   = $price > 0 ? number_format($price) . " تومان" : "رایگان 🆓";

        $text = "📖 <b>{$course['title']}</b>\n\n"
              . "📝 {$course['description']}\n\n"
              . "📅 شروع: {$course['start_date']}\n"
              . "📅 پایان: {$course['end_date']}\n"
              . "👥 ظرفیت: " . ($capacity > 0 ? "{$capacity} نفر" : "نامحدود") . "\n"
              . "✅ ثبت‌نام‌شده: {$enrollCount} نفر\n"
              . "🪑 ظرفیت باقی‌مانده: " . ($capacity > 0 ? "{$remaining} نفر" : $remaining) . "\n"
              . "💰 هزینه پایه: {$priceText}"
              . $this->deliveryModesText($course);

        $this->api->sendInlineMessage($chatId, $text, Keyboards::courseDetail($course, $enrolled, $full));
    }

    private function findCourseVariant(array $course, int $productId): ?array
    {
        foreach ((array)($course['delivery_modes'] ?? []) as $variant) {
            if ((int)($variant['product_id'] ?? 0) === $productId) return $variant;
        }
        return null;
    }

    /**
     * خرید قطعی یا فیش درحال‌بررسی را متوقف می‌کند؛ سفارش پرداخت‌نشده‌ی بله
     * اجازه ادامه دارد تا قطع ارتباط یا بستن فاکتور کاربر را برای همیشه گیر نیندازد.
     */
    private function existingVariantOrderBlocks(string $callbackId, array $user, int $courseId, int $productId): bool
    {
        if (!Database::isUserEnrolled((int)$user['id'], $courseId, $productId)) return false;
        $enrollment = Database::getEnrollmentByUserCourse((int)$user['id'], $courseId, $productId);
        if (!$enrollment) {
            $this->api->answerCallbackQuery($callbackId, '❌ بررسی سفارش باز از سایت ممکن نشد؛ دوباره تلاش کنید.', true);
            return true;
        }
        if (($enrollment['payment_status'] ?? '') === 'paid') {
            $this->api->answerCallbackQuery($callbackId, '✅ این شیوه را قبلاً خریده‌اید.', true);
            return true;
        }
        if (trim((string)($enrollment['receipt_file_id'] ?? '')) !== '') {
            $this->api->answerCallbackQuery($callbackId, '⏳ فیش این سفارش در حال بررسی مدیر است.', true);
            return true;
        }
        return false;
    }

    private function deliveryModesText(array $course): string
    {
        $modes = (array)($course['delivery_modes'] ?? []);
        if (!$modes) return '';
        $text = "\n\n📦 <b>شیوه‌های فعال سایت:</b>";
        foreach ($modes as $mode) {
            $key = (string)($mode['mode'] ?? '');
            $icon = ['offline'=>'🎬', 'online'=>'💻', 'inperson'=>'📍'][$key] ?? '🔹';
            $label = trim((string)($mode['label'] ?? '')) ?: (['offline'=>'آفلاین', 'online'=>'آنلاین', 'inperson'=>'حضوری'][$key] ?? 'دوره');
            $price = (int)round((float)($mode['price'] ?? 0));
            $status = !empty($mode['full']) ? ' — ظرفیت تکمیل' : (isset($mode['remaining']) && $mode['remaining'] !== null ? ' — ' . (int)$mode['remaining'] . ' جای خالی' : '');
            $text .= "\n{$icon} {$label}: " . ($price > 0 ? number_format($price) . ' تومان' : 'رایگان') . $status;
        }
        return $text;
    }

    private function notifyCourseEnrollmentAdmins(array $user, array $course, string $variantLabel, string $trackingCode): void
    {
        $notice = "📚 <b>ثبت‌نام دوره</b>\n\n"
                . "👤 کاربر: " . ($user['fl_name'] ?? 'کاربر سایت') . "\n"
                . "📞 تلفن: " . ($user['phone'] ?? '—') . "\n"
                . "📖 دوره: {$course['title']}" . ($variantLabel !== '' ? " — {$variantLabel}" : '') . "\n"
                . "🔢 کد پیگیری: <code>{$trackingCode}</code>";
        foreach (Database::getAllAdmins() as $admin) {
            $adminChat = trim((string)($admin['chat_id'] ?? ''));
            if ($adminChat !== '') $this->api->sendMessage($adminChat, $notice);
        }
    }

    // ───── منوی اصلی ──────────────────────────────────────────────
    public function sendMainMenu(string $chatId, array $user): void
    {
        $context = Database::refreshContext($chatId);
        $fresh = is_array($context['user'] ?? null) ? $context['user'] : $user;
        Keyboards::setUserContext($fresh);
        $isAdmin = !empty($context['is_admin']);
        $isOwner = !empty($context['is_owner']);
        $name    = $fresh['fl_name'] ?? 'کاربر سایت';
        $role    = $fresh['active_mode_title'] ?? 'کاربر';
        $kb      = $isAdmin ? Keyboards::adminMain($isOwner) : Keyboards::userMain();
        $this->api->sendMessage($chatId, "🏠 سلام <b>{$name}</b> عزیز!\nنقش فعال: <b>{$role}</b>\nمنو مستقیماً از سایت خوانده می‌شود؛ بخش‌های دارای ↗ در سایت باز می‌شوند.", $kb);
    }

    private function handleSiteSelection(string $chatId, array $selection, array $user): void
    {
        if (($selection['type'] ?? '') === 'roles') {
            Keyboards::setUserContext($user);
            $this->api->sendInlineMessage($chatId, '🎭 نقش‌های فعال شما'."\n\n".'برای نمایش منوی هر نقش، آن را انتخاب کنید.', Keyboards::rolesMenu());
            return;
        }
        if (($selection['type'] ?? '') === 'group') {
            $this->showGroup($chatId, (string)($selection['id'] ?? ''), 0);
            return;
        }
        if (($selection['type'] ?? '') === 'open_courses') {
            (new OpenCoursesHandler($this->api))->show($chatId);
            return;
        }
        if (($selection['type'] ?? '') === 'role') {
            $mode = (string) ($selection['mode'] ?? 'user');
            if (!Database::setActiveMode($chatId, $mode)) {
                $this->api->sendMessage($chatId, "❌ این نقش برای حساب سایت شما فعال نیست.", Keyboards::userMain());
                return;
            }
            $this->sendMainMenu($chatId, $user);
            return;
        }

        $panel = (string) ($selection['id'] ?? '');
        $mode = (string) ($selection['mode'] ?? ($user['active_mode'] ?? 'user'));
        if((new NativeHandler($this->api))->panel($chatId,$panel))return;
        if (in_array($panel, ['dashboard','teacher_dashboard','therapist_dashboard','manager_dashboard'], true)) {
            $this->sendMainMenu($chatId, $user);
            return;
        }
        if (in_array($panel, ['profile','teacher_settings','therapist_settings'], true)) {
            $this->showProfile($chatId);
            return;
        }
        if (array_key_exists($panel, MyCoursesHandler::PANEL_MODES)) {
            (new MyCoursesHandler($this->api))->show($chatId, MyCoursesHandler::PANEL_MODES[$panel]);
            return;
        }
        if ($panel === 'certificates') {
            $this->showMyCertificates($chatId, $user);
            return;
        }
        if ($panel === 'my_appointments') {
            $this->showMyAppointments($chatId, $user);
            return;
        }
        if ($panel === 'book_appointment') {
            $this->startAppointment($chatId);
            return;
        }
        if (in_array($panel, ['announcements','teacher_notices'], true)) {
            $this->showNews($chatId, 'announcement', 0);
            return;
        }
        if ($panel === 'ticket_support') {
            $this->startContactAdmin($chatId);
            return;
        }

        $title = (string) ($selection['title'] ?? 'این بخش');
        $hint = trim((string) ($selection['hint'] ?? ''));
        // لینک ورود یک‌بارمصرف (۶۰ ثانیه) از سایت؛ اگر افزونه قدیمی بود یا پاسخ نداد، لینک ساده.
        $url = '';
        $auto = false;
        try {
            $link = Database::panelLink($mode, $panel);
            if ($link) { $url = (string)$link['url']; $auto = !empty($link['login']); }
        } catch (SiteSyncException $e) {
            $url = '';
        }
        if ($url === '') $url = (string) ($selection['url'] ?? '');
        if ($url === '') $url = Database::getPanelUrl($chatId, $mode, $panel);
        $text = "🔗 {$title}" . ($hint !== '' ? "\n\n{$hint}" : '')
            . "\n\nاین بخش در سایت باز می‌شود." . ($auto ? "\nبا لمس دکمه، بدون وارد کردن دوباره رمز وارد حساب خود می‌شوید (لینک فقط ۶۰ ثانیه و یک‌بار معتبر است)." : '');
        if ($url !== '') {
            $this->api->sendInlineMessage($chatId, $text, [[['text'=>'🌐 باز کردن در سایت', 'url'=>$url]], [['text'=>'🏠 خانه', 'callback_data'=>'back_main']]]);
        } else {
            $this->api->sendMessage($chatId, $text, Keyboards::userMain());
        }
    }

    /** فرزندان یک گروه منوی سایت؛ $msgId>0 یعنی همان پیام را ویرایش کن. */
    private function showGroup(string $chatId, string $groupId, int $msgId): void
    {
        $found = Keyboards::findEntry($groupId);
        if (!$found || ($found['type'] ?? '') !== 'group') {
            $this->api->sendMessage($chatId, 'این بخش دیگر در منو نیست؛ /start را بزنید.', Keyboards::userMain());
            return;
        }
        $group = $found['entry'];
        $hint = trim((string)($group['hint'] ?? ''));
        $text = trim((string)($group['emoji'] ?? '') . ' ' . $group['title']) . ($hint !== '' ? "\n\n" . $hint : '') . "\n\nیکی را انتخاب کنید:";
        $keyboard = Keyboards::groupKeyboard($group);
        if ($msgId > 0) {
            $res = $this->api->editMessageText($chatId, $msgId, $text, $keyboard);
            if (!empty($res['ok'])) return;
        }
        $this->api->sendInlineMessage($chatId, $text, $keyboard);
    }

    private function cancelAndBack(string $chatId): void
    {
        $user = Database::getUser($chatId);
        $this->sendMainMenu($chatId, $user ?? ['fl_name' => '']);
    }

    private static function h(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    private static function normalizeDigits(string $value): string
    {
        return strtr($value, [
            '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
            '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
        ]);
    }

    private static function validPersonName(string $value): bool
    {
        $value = trim($value);
        if (!preg_match('/^[\p{L}\p{M}\x{200C}\s\.\'\x{2019}-]+$/u', $value)) return false;
        preg_match_all('/\p{L}/u', $value, $letters);
        return count($letters[0] ?? []) >= 2;
    }

    private static function validEnglishName(string $value): bool
    {
        $value = trim($value);
        return preg_match('/^[A-Za-z\s\.\'\x{2019}-]+$/u', $value) === 1
            && preg_match_all('/[A-Za-z]/', $value) >= 2;
    }
}
