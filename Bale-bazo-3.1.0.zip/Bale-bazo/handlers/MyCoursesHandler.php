<?php
// handlers/MyCoursesHandler.php — «دوره‌های من» (ثبت‌نام‌شده‌ها) داخل خود ربات.
//
// یک درخواست سبک (myCourses) به سایت می‌رود؛ فیلتر آنلاین/حضوری/آفلاین و صفحه‌بندی با ویرایش همان پیام انجام می‌شود.
// اگر افزونهٔ سایت قدیمی باشد، به روش قبلی (getUserCourses) برمی‌گردد.
declare(strict_types=1);

final class MyCoursesHandler
{
    private const PAGE_SIZE = 6;
    /** شناسهٔ بخش منوی سایت → فیلتر. */
    public const PANEL_MODES = ['enrolled_courses' => '', 'online_courses' => 'online', 'course_content' => 'offline', 'inperson_courses' => 'inperson'];
    private const MODE_LABEL = ['' => 'همه', 'online' => '💻 آنلاین', 'inperson' => '📍 حضوری', 'offline' => '🎬 آفلاین'];
    private const MODE_CODE = ['' => 'all', 'online' => 'on', 'inperson' => 'in', 'offline' => 'off'];

    private BaleApi $api;

    public function __construct(BaleApi $api) { $this->api = $api; }

    private function put(string $chatId, int $msgId, string $text, array $keyboard): void
    {
        if ($msgId > 0) {
            $res = $this->api->editMessageText($chatId, $msgId, $text, $keyboard);
            if (!empty($res['ok'])) return;
        }
        $this->api->sendInlineMessage($chatId, $text, $keyboard);
    }

    private static function codeToMode(string $code): string
    {
        $flip = array_flip(self::MODE_CODE);
        return $flip[$code] ?? '';
    }

    public function show(string $chatId, string $mode = '', int $page = 1, int $msgId = 0): void
    {
        $mode = array_key_exists($mode, self::MODE_LABEL) ? $mode : '';
        try {
            $data = Database::myCourses($mode);
        } catch (SiteSyncException $error) {
            $text = SiteClient::userMessage($error, Keyboards::messages());
            $this->put($chatId, $msgId, $text, [[['text' => '🔄 تلاش دوباره', 'callback_data' => 'mc:' . self::MODE_CODE[$mode] . ':' . max(1, $page)]], [['text' => '🏠 خانه', 'callback_data' => 'back_main']]]);
            return;
        }
        if ($data === null) { $this->legacy($chatId, $mode); return; }

        $items = array_values($data['items']);
        $pages = max(1, (int)ceil(count($items) / self::PAGE_SIZE));
        $page = min(max(1, $page), $pages);
        $title = '📚 دوره‌های من' . ($mode !== '' ? ' — ' . trim(self::MODE_LABEL[$mode]) : '');
        if (!$items) {
            $text = $title . "\n\n" . ($mode === '' ? 'هنوز در دوره‌ای ثبت‌نام نکرده‌اید.' : 'در این دسته دوره‌ای ندارید.');
        } else {
            $text = $title . ' (' . count($items) . ")\n";
            foreach (array_slice($items, ($page - 1) * self::PAGE_SIZE, self::PAGE_SIZE) as $i => $course) {
                $pay = ($course['payment_status'] ?? '') === 'paid' ? '✅ فعال' : '⏳ در انتظار پرداخت/تأیید';
                $text .= "\n" . (($page - 1) * self::PAGE_SIZE + $i + 1) . '. ' . $course['title']
                    . ($course['delivery_label'] !== '' ? ' — ' . $course['delivery_label'] : '') . "\n   " . $pay;
                if (trim((string)($course['start_date'] ?? '')) !== '') $text .= "\n   📅 شروع: " . $course['start_date'];
                if (trim((string)($course['tracking_code'] ?? '')) !== '') $text .= "\n   🔢 کد پیگیری: " . $course['tracking_code'];
                $text .= "\n";
            }
        }
        $rows = [];
        $filters = [];
        foreach (self::MODE_LABEL as $key => $label) {
            $filters[] = ['text' => ($key === $mode ? '• ' : '') . $label, 'callback_data' => 'mc:' . self::MODE_CODE[$key] . ':1'];
        }
        $rows[] = array_slice($filters, 0, 2);
        $rows[] = array_slice($filters, 2);
        if ($pages > 1) {
            $nav = [];
            if ($page > 1) $nav[] = ['text' => '◀ قبلی', 'callback_data' => 'mc:' . self::MODE_CODE[$mode] . ':' . ($page - 1)];
            $nav[] = ['text' => $page . ' / ' . $pages, 'callback_data' => 'noop'];
            if ($page < $pages) $nav[] = ['text' => 'بعدی ▶', 'callback_data' => 'mc:' . self::MODE_CODE[$mode] . ':' . ($page + 1)];
            $rows[] = $nav;
        }
        $rows[] = [['text' => '🏠 خانه', 'callback_data' => 'back_main']];
        $this->put($chatId, $msgId, mb_substr($text, 0, 3900), $rows);
    }

    /** روش قبلی برای افزونهٔ قدیمی. */
    private function legacy(string $chatId, string $mode): void
    {
        $courses = Database::getUserCourses((int)$chatId);
        if ($mode !== '') $courses = array_values(array_filter($courses, static fn($c) => ($c['delivery_mode'] ?? '') === $mode));
        if (!$courses) { $this->api->sendMessage($chatId, '📚 هنوز در دوره‌ای ثبت‌نام نکرده‌اید.'); return; }
        $text = "📚 دوره‌های من\n";
        foreach ($courses as $i => $c) $text .= "\n" . ($i + 1) . '. ' . ($c['title'] ?? '') . (!empty($c['delivery_label']) ? ' — ' . $c['delivery_label'] : '');
        $this->api->sendInlineMessage($chatId, mb_substr($text, 0, 3900), [[['text' => '🏠 خانه', 'callback_data' => 'back_main']]]);
    }

    /** مسیریابی «mc:<all|on|in|off>:<صفحه>». */
    public function callback(string $chatId, int $msgId, string $data): bool
    {
        if (strpos($data, 'mc:') !== 0) return false;
        $p = explode(':', $data);
        $this->show($chatId, self::codeToMode((string)($p[1] ?? 'all')), (int)($p[2] ?? 1), $msgId);
        return true;
    }
}
