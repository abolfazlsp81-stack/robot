<?php
// helpers/BaleApi.php
require_once __DIR__.'/BaleText.php';

class BaleApi
{
    private string $token;
    private string $base;
    private string $fileBase;
    private array $answeredCallbacks = [];
    private $connection = null;
    public static ?string $downloadError = null;

    public function __construct(string $token, string $base)
    {
        $this->token = $token;
        $this->base  = rtrim($base, '/');
        $this->fileBase = preg_replace('~/bot$~', '/file/bot', $this->base) ?: 'https://tapi.bale.ai/file/bot';
    }

    private function call(string $method, array $params = [], bool $multipart = false, int $timeout = 30): array
    {
        $params = BaleText::payload($method, $params);
        if(class_exists('SiteClient') && method_exists('SiteClient','heartbeat'))SiteClient::heartbeat();
        $url = "{$this->base}{$this->token}/{$method}";
        if ($this->connection === null) $this->connection=curl_init();
        $ch=$this->connection;
        curl_reset($ch);
        $timeout = max(3, min(120, $timeout));
        $opts = [
            CURLOPT_URL => $url,
            CURLOPT_POST           => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => min(5, max(2, $timeout - 1)),
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_ENCODING       => '',
            CURLOPT_FRESH_CONNECT => false,
            CURLOPT_FORBID_REUSE => false,
            CURLOPT_TCP_KEEPALIVE => 1,
            CURLOPT_USERAGENT      => 'BaleBazo/' . (defined('BALE_BAZO_VERSION') ? BALE_BAZO_VERSION : '2.0.0'),
        ];
        if ($multipart) {
            // برای آپلود واقعی فایل (CURLFile) نباید JSON ارسال شود
            $opts[CURLOPT_POSTFIELDS] = $params;
        } else {
            $opts[CURLOPT_POSTFIELDS] = json_encode($params);
            $opts[CURLOPT_HTTPHEADER] = ['Content-Type: application/json'];
        }
        curl_setopt_array($ch, $opts);
        if (defined('CURL_HTTP_VERSION_2TLS')) curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2TLS);
        curl_setopt($ch, CURLOPT_TCP_NODELAY, true);
        $res = curl_exec($ch);
        $error = curl_error($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        if ($res === false || $error !== '') {
            if (class_exists('UpdateLifecycle') && !in_array($method,['answerCallbackQuery','answerPreCheckoutQuery'],true)) UpdateLifecycle::fail('bale_network');
            error_log('[BaleBazo Bale API] network_error');
            return ['ok'=>false, 'description'=>'network_error'];
        }
        $decoded = json_decode($res, true);
        if (!is_array($decoded)) {
            if(class_exists('UpdateLifecycle') && $method!=='answerCallbackQuery') UpdateLifecycle::fail('bale_invalid_response');
            return ['ok'=>false,'description'=>'invalid_response','status'=>$status];
        }
        if (empty($decoded['ok']) && ($status>=500 || $status===429) && class_exists('UpdateLifecycle') && $method!=='answerCallbackQuery') UpdateLifecycle::fail('bale_retry');
        return $decoded;
    }

    // ───── ارسال پیام ─────────────────────────────────────────────
    public function sendMessage(string $chatId, string $text, array $keyboard = [], string $parseMode = 'HTML'): array
    {
        $params = [
            'chat_id'    => $chatId,
            'text'       => $text,
            'parse_mode' => $parseMode,
        ];
        if (!empty($keyboard)) {
            $params['reply_markup'] = json_encode(isset($keyboard['keyboard']) ? $keyboard : [
                'keyboard'        => $keyboard,
                'resize_keyboard' => true,
            ]);
        }
        return $this->call('sendMessage', $params);
    }

    public function sendInlineMessage(string $chatId, string $text, array $inlineKeyboard = [], string $parseMode = 'HTML'): array
    {
        $params = [
            'chat_id'    => $chatId,
            'text'       => $text,
            'parse_mode' => $parseMode,
        ];
        if (!empty($inlineKeyboard)) {
            $params['reply_markup'] = json_encode(['inline_keyboard' => $inlineKeyboard]);
        }
        return $this->call('sendMessage', $params);
    }

    // ───── ارسال عکس ─────────────────────────────────────────────
    public function sendPhoto(string $chatId, $photo, string $caption = '', array $inlineKeyboard = [], string $parseMode = 'HTML'): array
    {
        $params = [
            'chat_id'    => $chatId,
            'photo'      => $photo,
            'caption'    => $caption,
            'parse_mode' => $parseMode,
        ];
        if (!empty($inlineKeyboard)) {
            $params['reply_markup'] = json_encode(['inline_keyboard' => $inlineKeyboard]);
        }
        return $this->call('sendPhoto', $params);
    }

    // ───── ارسال ویدیو (با file_id یا URL)، با کپشن و کیبورد اینلاین اختیاری ──
    public function sendVideo(string $chatId, $video, string $caption = '', array $inlineKeyboard = [], string $parseMode = 'HTML'): array
    {
        $params = [
            'chat_id'    => $chatId,
            'video'      => $video,
            'caption'    => $caption,
            'parse_mode' => $parseMode,
        ];
        if (!empty($inlineKeyboard)) {
            $params['reply_markup'] = json_encode(['inline_keyboard' => $inlineKeyboard]);
        }
        return $this->call('sendVideo', $params);
    }

    // ───── ارسال عکس محلی روی سرور (آپلود واقعی) ───────────
    public function sendLocalPhoto(string $chatId, string $localPath, string $caption = ''): array
    {
        if (!is_file($localPath)) {
            return ['ok' => false, 'description' => 'file not found'];
        }
        $mime = function_exists('mime_content_type') ? (@mime_content_type($localPath) ?: 'image/jpeg') : 'image/jpeg';
        return $this->call('sendPhoto', [
            'chat_id'    => $chatId,
            'photo'      => new CURLFile($localPath, $mime, basename($localPath)),
            'caption'    => $caption,
            'parse_mode' => 'HTML',
        ], true);
    }

    // ───── ارسال فایل (با file_id یا URL) ──────────────────────────
    public function sendDocument(string $chatId, $file, string $text = ''): array
    {
        return $this->call('sendDocument', [
            'chat_id'  => $chatId,
            'document' => $file,
            'caption'  => $text,
        ], $file instanceof CURLFile);
    }

    // ───── ارسال فایل محلی روی سرور (آپلود واقعی - مثل گزارش‌های ساخته‌شده) ─
    public function sendLocalDocument(string $chatId, string $localPath, string $caption = '', string $displayName = ''): array
    {
        if (!is_file($localPath)) {
            return ['ok' => false, 'description' => 'file not found'];
        }
        return $this->call('sendDocument', [
            'chat_id'  => $chatId,
            'document' => new CURLFile($localPath, 'text/plain', $displayName !== '' ? $displayName : basename($localPath)),
            'caption'  => $caption,
        ], true);
    }

    // ───── ویرایش پیام ───────────────────────────────────────────
    public function editMessageText(string $chatId, int $messageId, string $text, array $inlineKeyboard = []): array
    {
        $params = [
            'chat_id'    => $chatId,
            'message_id' => $messageId,
            'text'       => $text,
            'parse_mode' => 'HTML',
        ];
        if (!empty($inlineKeyboard)) {
            $params['reply_markup'] = json_encode(['inline_keyboard' => $inlineKeyboard]);
        }
        return $this->call('editMessageText', $params);
    }

    // ───── حذف پیام ───────────────────────────────────────────────
    public function deleteMessage(string $chatId, int $messageId): array
    {
        return $this->call('deleteMessage', [
            'chat_id'    => $chatId,
            'message_id' => $messageId,
        ]);
    }

    public function editMessageCaption(string $chatId, int $messageId, string $caption, array $inlineKeyboard = []): array
    {
        $params = [
            'chat_id'    => $chatId,
            'message_id' => $messageId,
            'caption'    => $caption,
            'parse_mode' => 'HTML',
        ];
        if (!empty($inlineKeyboard)) {
            $params['reply_markup'] = json_encode(['inline_keyboard' => $inlineKeyboard]);
        }
        return $this->call('editMessageCaption', $params);
    }

    // ───── Callback Query ─────────────────────────────────────────
    public function answerCallbackQuery(string $callbackId, string $text = '', bool $showAlert = false): array
    {
        if (isset($this->answeredCallbacks[$callbackId])) {
            return ['ok'=>true, 'result'=>true, 'already_answered'=>true];
        }
        // هر Callback فقط یک بار پاسخ داده می‌شود تا هشدار واقعی با پاسخ خالی
        // زودهنگام جایگزین نشود.
        $this->answeredCallbacks[$callbackId] = true;
        return $this->call('answerCallbackQuery', [
            'callback_query_id' => $callbackId,
            'text'              => $text,
            'show_alert'        => $showAlert,
        ]);
    }

    public function answerCallbackQueryIfPending(string $callbackId): array
    {
        return $this->answerCallbackQuery($callbackId);
    }

    // ───── پرداخت ─────────────────────────────────────────────────
    public function sendInvoice(
        string $chatId,
        string $title,
        string $description,
        string $payload,
        string $providerToken,
        array  $prices
    ): array {
        $title = self::limitText(trim($title), 32);
        $description = self::limitText(trim($description), 255);
        if ($title === '') $title = 'سفارش سایت';
        if ($description === '') $description = 'پرداخت سفارش ثبت‌شده در سایت';
        return $this->call('sendInvoice', [
            'chat_id'         => $chatId,
            'title'           => $title,
            'description'     => $description,
            'payload'         => $payload,
            'provider_token'  => $providerToken,
            'prices'          => $prices,
        ]);
    }

    public function answerPreCheckoutQuery(string $queryId, bool $ok, string $errorMsg = ''): array
    {
        $params = [
            'pre_checkout_query_id' => $queryId,
            'ok'                    => $ok,
        ];
        if (!$ok && $errorMsg) {
            $params['error_message'] = $errorMsg;
        }
        return $this->call('answerPreCheckoutQuery', $params, false, 4);
    }

    /** استعلام رسمی تراکنش کیف پول بله پیش از قطعی‌کردن سفارش سایت. */
    public function inquireTransaction(string $transactionId): array
    {
        if ($transactionId === '') {
            return ['ok' => false, 'description' => 'missing_transaction_id'];
        }
        return $this->call('inquireTransaction', ['transaction_id' => $transactionId]);
    }

    // ───── Broadcast ─────────────────────────────────────────────
    public function broadcast(array $chatIds, string $text): array
    {
        $results = ['sent' => 0, 'failed' => 0];
        foreach ($chatIds as $cid) {
            $res = $this->sendMessage((string)$cid, $text);
            if (!empty($res['ok'])) {
                $results['sent']++;
            } else {
                $results['failed']++;
            }
            usleep(50000);
        }
        return $results;
    }

    public function setWebhook(string $url): array
    {
        return $this->call('setWebhook', ['url'=>$url]);
    }

    public function getMe(): array
    {
        return $this->call('getMe');
    }

    private static function limitText(string $text, int $length): string
    {
        if ($length < 1 || $text === '') return '';
        if (function_exists('mb_substr')) return mb_substr($text, 0, $length, 'UTF-8');
        if (preg_match_all('/./us', $text, $chars) === false) return substr($text, 0, $length);
        return implode('', array_slice($chars[0], 0, $length));
    }

    /**
     * دریافت امن فایل با getFile و لینک یک‌ساعته رسمی بله.
     * خروجی باید پس از استفاده توسط فراخواننده unlink شود.
     */
    public function downloadFile(string $fileId, int $maxBytes = 20971520): ?array
    {
        self::$downloadError = null;
        $info = $this->call('getFile', ['file_id'=>$fileId]);
        $file = is_array($info['result'] ?? null) ? $info['result'] : [];
        $path = ltrim((string)($file['file_path'] ?? ''), '/');
        $reportedSize = (int)($file['file_size'] ?? 0);
        if ($reportedSize > 0 && $reportedSize > $maxBytes) {
            self::$downloadError = 'too_large';
            return null;
        }
        if ($path === '' || str_contains($path, '..')) {
            self::$downloadError = 'unavailable';
            return null;
        }

        $segments = array_map('rawurlencode', explode('/', $path));
        $url = $this->fileBase . $this->token . '/' . implode('/', $segments);
        $tmp = tempnam(sys_get_temp_dir(), 'bale_asset_');
        if ($tmp === false) { self::$downloadError = 'network'; return null; }
        $handle = fopen($tmp, 'wb');
        if ($handle === false) { @unlink($tmp); self::$downloadError = 'network'; return null; }

        $written = 0;
        $sizeAborted = false;
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 90,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_ENCODING => '',
            CURLOPT_USERAGENT => 'BaleBazo/' . (defined('BALE_BAZO_VERSION') ? BALE_BAZO_VERSION : '2.0.0'),
            CURLOPT_WRITEFUNCTION => static function ($curl, string $chunk) use ($handle, $maxBytes, &$written, &$sizeAborted): int {
                $length = strlen($chunk);
                if ($written + $length > $maxBytes) { $sizeAborted = true; return 0; }
                $saved = fwrite($handle, $chunk);
                if ($saved === false) return 0;
                $written += $saved;
                return $saved;
            },
        ]);
        $ok = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $contentType = trim((string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE));
        curl_close($ch);
        fclose($handle);
        if ($ok === false || $status < 200 || $status >= 300 || $written < 1 || $written > $maxBytes) {
            @unlink($tmp);
            self::$downloadError = ($sizeAborted || $written > $maxBytes) ? 'too_large' : 'network';
            return null;
        }

        $name = basename(rawurldecode($path));
        if ($name === '' || $name === '.' || $name === '/') $name = 'bale-file.bin';
        return ['path'=>$tmp, 'file_name'=>$name, 'mime'=>$contentType, 'size'=>$written];
    }
}
