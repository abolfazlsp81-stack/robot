<?php
// helpers/SiteGate.php — «دروازهٔ ترافیک» بین ربات و سایت.
//
// مشکل: هر وبهوک بله یک پردازش PHP جدا است. وقتی کاربران (یا یک کاربر با لمس‌های پشت‌سرهم) چند درخواست هم‌زمان
// بسازند، همه با هم به سایت می‌روند؛ سایت/هاست (محدودیت پردازش هم‌زمان، فایروال، CDN) بعضی را رد می‌کند و کاربر
// می‌بیند «ارتباط با سایت برقرار نیست». راه‌حل اصولی چهار لایه است:
//   ۱) محدودیت هم‌زمانی: حداکثر N تماس هم‌زمان از ربات به سایت؛ بقیه چند ثانیه در صف می‌مانند (نه خطا).
//   ۲) تلاش دوباره هوشمند با تأخیر نمایی و تصادفی (Backoff + Jitter) فقط برای خطاهای گذرا.
//   ۳) قطع‌کننده (Circuit Breaker): اگر سایت پشت‌سرهم خطا داد، چند ثانیه تماس تازه نمی‌فرستیم تا سایت نفس بکشد.
//   ۴) پیام روشن و داده‌ی کهنهٔ قبلی (برای فهرست‌های عمومی) به‌جای شکست.
declare(strict_types=1);

final class SiteGate
{
    private static array $config = [];
    /** برای آزمون: جایگزین sleep. */
    public static $sleeper = null;
    private static ?string $dir = null;

    public static function configure(array $config): void
    {
        self::$config = $config;
        self::$dir = null;
    }

    private static function intCfg(string $key, int $default, int $min, int $max): int
    {
        return max($min, min($max, (int)(self::$config[$key] ?? $default)));
    }

    private static function directory(): ?string
    {
        if (self::$dir !== null) return self::$dir === '' ? null : self::$dir;
        $scope = defined('BASE_DIR') ? (string)BASE_DIR : __DIR__;
        $dir = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'bale-bazo-' . substr(hash('sha256', $scope), 0, 10);
        if (!is_dir($dir)) @mkdir($dir, 0700, true);
        self::$dir = (is_dir($dir) && is_writable($dir)) ? $dir : '';
        return self::$dir === '' ? null : self::$dir;
    }

    public static function pause(int $milliseconds): void
    {
        if (is_callable(self::$sleeper)) { (self::$sleeper)($milliseconds); return; }
        usleep(max(0, $milliseconds) * 1000);
    }

    // ───── ۱) اسلات هم‌زمانی ─────────────────────────────────────

    /** @return resource|true|null  null = در مهلت صف جا نشد. true = قفل‌گذاری در دسترس نیست (بدون محدودیت). */
    public static function acquire()
    {
        $slots = self::intCfg('site_max_concurrent', 4, 1, 32);
        $dir = self::directory();
        if ($dir === null) return true;
        $deadline = microtime(true) + self::intCfg('site_queue_wait', 8, 1, 25);
        $start = random_int(0, $slots - 1);
        do {
            for ($i = 0; $i < $slots; $i++) {
                $file = $dir . DIRECTORY_SEPARATOR . 'slot-' . (($start + $i) % $slots) . '.lock';
                $handle = @fopen($file, 'c');
                if ($handle === false) return true;
                if (@flock($handle, LOCK_EX | LOCK_NB)) return $handle;
                fclose($handle);
            }
            self::pause(random_int(25, 70));
        } while (microtime(true) < $deadline);
        return null;
    }

    public static function release($slot): void
    {
        if (is_resource($slot)) { @flock($slot, LOCK_UN); @fclose($slot); }
    }

    // ───── ۲) تأخیر تلاش دوباره ──────────────────────────────────

    public static function backoffMs(int $attempt, int $retryAfterSeconds = 0): int
    {
        $base = (int)(250 * (2 ** max(0, $attempt - 1)));          // 250, 500, 1000 …
        $jitter = random_int(70, 130) / 100;
        $ms = (int)round(min(3000, $base) * $jitter);
        if ($retryAfterSeconds > 0) $ms = max($ms, min(3000, $retryAfterSeconds * 1000));
        return $ms;
    }

    // ───── ۳) قطع‌کننده ──────────────────────────────────────────

    /** true یعنی همین حالا تماس تازه نفرست. فقط یک «تماس آزمایشی» پس از سرد شدن اجازه می‌گیرد. */
    public static function circuitOpen(): bool
    {
        $until = Cache::get('sg:open');
        if ($until === null) return false;
        if (time() < (int)$until) return true;
        if (Cache::get('sg:probe') === null) { Cache::set('sg:probe', 1, 3); return false; }
        return true;
    }

    public static function recordSuccess(): void
    {
        if (Cache::get('sg:f') !== null) Cache::forget('sg:f');
        if (Cache::get('sg:open') !== null) { Cache::forget('sg:open'); Cache::forget('sg:probe'); }
    }

    public static function recordFailure(): void
    {
        $threshold = self::intCfg('site_circuit_threshold', 5, 2, 50);
        $cooldown = self::intCfg('site_circuit_cooldown', 6, 2, 60);
        $count = (int)(Cache::get('sg:f') ?? 0) + 1;
        Cache::set('sg:f', $count, 12);
        if ($count >= $threshold) {
            Cache::set('sg:open', time() + $cooldown, $cooldown + 60);
            Cache::forget('sg:probe');
        }
    }
}
