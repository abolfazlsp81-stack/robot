<?php
// helpers/ChatLock.php — قفل «یک پیام در هر لحظه برای هر کاربر».
//
// وقتی کاربر چند دکمه را پشت‌سرهم می‌زند، بله چند وبهوک هم‌زمان می‌فرستد. سایت هم (برای محافظت از فرم‌های
// چندمرحله‌ای) تا تمام‌شدن پیام قبلی، پیام بعدی همان کاربر را با «conversation_busy» رد می‌کند و کاربر
// پیام «ارتباط با سایت برقرار نیست» می‌بیند. این قفل پیام‌های یک کاربر را در خود ربات به‌صورت صف
// و به‌ترتیب پردازش می‌کند؛ پس سایت هرگز دو درخواست هم‌زمان از یک کاربر نمی‌بیند.
declare(strict_types=1);

final class ChatLock
{
    /** @var resource|null */
    private static $handle = null;

    private static function directory(): ?string
    {
        $scope = defined('BASE_DIR') ? (string)BASE_DIR : __DIR__;
        $dir = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'bale-bazo-' . substr(hash('sha256', $scope), 0, 10) . DIRECTORY_SEPARATOR . 'chats';
        if (!is_dir($dir)) @mkdir($dir, 0700, true);
        return (is_dir($dir) && is_writable($dir)) ? $dir : null;
    }

    /** @return bool true = قفل گرفته شد (یا قفل‌گذاری ممکن نیست)، false = در مهلت نوبت نرسید */
    public static function acquire(string $chatId, float $waitSeconds): bool
    {
        $dir = self::directory();
        if ($dir === null) return true;
        $file = $dir . DIRECTORY_SEPARATOR . hash('sha256', $chatId) . '.lock';
        $handle = @fopen($file, 'c');
        if ($handle === false) return true;
        $deadline = microtime(true) + max(0.0, $waitSeconds);
        do {
            if (@flock($handle, LOCK_EX | LOCK_NB)) {
                self::$handle = $handle;
                if (random_int(1, 300) === 1) self::sweep($dir);
                return true;
            }
            usleep(random_int(30000, 70000));
        } while (microtime(true) < $deadline);
        fclose($handle);
        return false;
    }

    public static function release(): void
    {
        if (is_resource(self::$handle)) { @flock(self::$handle, LOCK_UN); @fclose(self::$handle); }
        self::$handle = null;
    }

    private static function sweep(string $dir): void
    {
        foreach (glob($dir . DIRECTORY_SEPARATOR . '*.lock') ?: [] as $file) {
            if (@filemtime($file) < time() - 86400) @unlink($file);
        }
    }
}
