<?php
// helpers/Cache.php — کش کوتاه‌مدت برای سرعت (APCu اگر بود، وگرنه فایل در پوشهٔ موقت سرور).
// فقط داده‌های کم‌حساسیت و کوتاه‌عمر (مثل فهرست دوره‌ها) نگهداری می‌شود؛ هرگز رمز، توکن یا پرداخت.
declare(strict_types=1);

final class Cache
{
    private static ?string $dir = null;
    private static array $memory = [];
    public static bool $disableApcu = false;

    private static function key(string $key): string
    {
        $scope = defined('BASE_DIR') ? (string)BASE_DIR : __DIR__;
        return 'bb3_' . substr(hash('sha256', $scope . '|' . $key), 0, 40);
    }

    private static function apcu(): bool
    {
        return !self::$disableApcu && function_exists('apcu_fetch') && function_exists('apcu_enabled') && apcu_enabled();
    }

    private static function directory(): ?string
    {
        if (self::$dir !== null) return self::$dir === '' ? null : self::$dir;
        $scope = defined('BASE_DIR') ? (string)BASE_DIR : __DIR__;
        $dir = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'bale-bazo-' . substr(hash('sha256', $scope), 0, 10);
        if (!is_dir($dir)) @mkdir($dir, 0700, true);
        self::$dir = (is_dir($dir) && is_writable($dir)) ? $dir : '';
        return self::$dir === '' ? null : self::$dir;
    }

    /** @return mixed|null  null یعنی موجود نیست یا منقضی شده. */
    public static function get(string $key)
    {
        $k = self::key($key);
        if (isset(self::$memory[$k]) && self::$memory[$k][0] >= time()) return self::$memory[$k][1];
        if (self::apcu()) {
            $hit = apcu_fetch($k, $ok);
            return $ok ? $hit : null;
        }
        $dir = self::directory();
        if ($dir === null) return null;
        $file = $dir . DIRECTORY_SEPARATOR . $k . '.json';
        $raw = @file_get_contents($file);
        if ($raw === false) return null;
        $row = json_decode($raw, true);
        if (!is_array($row) || (int)($row['e'] ?? 0) < time()) { @unlink($file); return null; }
        self::$memory[$k] = [(int)$row['e'], $row['v']];
        return $row['v'];
    }

    public static function set(string $key, $value, int $ttl): void
    {
        $ttl = max(1, $ttl);
        $k = self::key($key);
        self::$memory[$k] = [time() + $ttl, $value];
        if (self::apcu()) { apcu_store($k, $value, $ttl); return; }
        $dir = self::directory();
        if ($dir === null) return;
        $json = json_encode(['e' => time() + $ttl, 'v' => $value], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) return;
        $tmp = $dir . DIRECTORY_SEPARATOR . $k . '.' . bin2hex(random_bytes(4)) . '.tmp';
        if (@file_put_contents($tmp, $json, LOCK_EX) === false) return;
        @chmod($tmp, 0600);
        if (!@rename($tmp, $dir . DIRECTORY_SEPARATOR . $k . '.json')) @unlink($tmp);
        if (random_int(1, 200) === 1) self::sweep($dir);
    }

    public static function forget(string $key): void
    {
        $k = self::key($key);
        unset(self::$memory[$k]);
        if (self::apcu()) { apcu_delete($k); return; }
        $dir = self::directory();
        if ($dir !== null) @unlink($dir . DIRECTORY_SEPARATOR . $k . '.json');
    }

    /** فایل‌های منقضی‌شدهٔ قدیمی را گاهی پاک می‌کند. */
    private static function sweep(string $dir): void
    {
        foreach (glob($dir . DIRECTORY_SEPARATOR . 'bb3_*.json') ?: [] as $file) {
            if (@filemtime($file) < time() - 3600) @unlink($file);
        }
    }

    /** فقط برای آزمون‌ها. */
    public static function reset(?string $dir = null): void
    {
        self::$memory = [];
        self::$dir = $dir;
    }
}
