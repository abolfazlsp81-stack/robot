<?php
// index.php — نقطه ورود webhook ربات بله

declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

if (!defined('BASE_DIR')) define('BASE_DIR', __DIR__);
if (!defined('BALE_BAZO_VERSION')) define('BALE_BAZO_VERSION', '3.1.0');

// ───── بارگذاری فایل‌ها ───────────────────────────────────────
require_once BASE_DIR . '/helpers/Cache.php';
require_once BASE_DIR . '/helpers/SiteGate.php';
require_once BASE_DIR . '/helpers/ChatLock.php';
require_once BASE_DIR . '/helpers/SiteClient.php';
require_once BASE_DIR . '/database/Database.php';
require_once BASE_DIR . '/helpers/StateManager.php';
require_once BASE_DIR . '/helpers/BaleApi.php';
require_once BASE_DIR . '/helpers/MediaSync.php';
require_once BASE_DIR . '/helpers/UpdateLifecycle.php';
require_once BASE_DIR . '/helpers/Keyboards.php';
require_once BASE_DIR . '/handlers/RegisterHandler.php';
require_once BASE_DIR . '/handlers/NativeHandler.php';
require_once BASE_DIR . '/handlers/OpenCoursesHandler.php';
require_once BASE_DIR . '/handlers/MyCoursesHandler.php';
require_once BASE_DIR . '/handlers/UserHandler.php';
require_once BASE_DIR . '/handlers/AdminHandler.php';

// ───── خواندن تنظیمات ────────────────────────────────────────
$config = require BASE_DIR . '/config/config.php';

if (empty($config['bot_token']) || empty($config['site_url']) || strlen((string)$config['site_sync_secret']) < 32 || strlen((string)$config['webhook_secret']) < 32) {
    error_log('[BaleBazo] Required bot/site sync configuration is missing.');
    http_response_code(503);
    exit;
}

// کلید URL وب‌هوک جلوی ارسال درخواست جعلی مستقیم به index.php را می‌گیرد.
$provided = (string) ($_GET['key'] ?? ($_SERVER['HTTP_X_BALE_WEBHOOK_SECRET'] ?? ''));
$workerUpdate = PHP_SAPI === 'cli' && isset($GLOBALS['BALE_WORKER_UPDATE']) && is_array($GLOBALS['BALE_WORKER_UPDATE']);
if (!$workerUpdate && !hash_equals((string) $config['webhook_secret'], $provided)) {
    error_log('[BaleBazo] webhook key mismatch; re-run setup.php --webhook with the current secret.');
    http_response_code(403);
    exit;
}

SiteClient::configure($config);
$api = new BaleApi((string) $config['bot_token'], (string) $config['api_base']);

// ───── دریافت آپدیت ───────────────────────────────────────────
$input  = $workerUpdate ? '' : file_get_contents('php://input');
$update = $workerUpdate ? $GLOBALS['BALE_WORKER_UPDATE'] : json_decode($input ?: '{}', true);

set_exception_handler(static function(Throwable $error): void {
    $code=$error instanceof SiteSyncException?$error->getRemoteCode():'php_exception';
    UpdateLifecycle::fail($code);
    error_log('[BaleBazo] processing_failed code='.$code);
    http_response_code(503);
});

// عیب‌یابی استقرار: باز کردن آدرس در مرورگر (GET بدون بدنه) به‌جای سکوت،
// یک صفحه وضعیت بدون اطلاعات حساس نشان می‌دهد تا علت «ربات جواب نمی‌دهد» پیدا شود.
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET' && ($input === '' || $input === false)) {
    header('Content-Type: text/plain; charset=utf-8');
    http_response_code(200);
    echo 'Bale-bazo ' . BALE_BAZO_VERSION . " OK\n";
    echo 'PHP: ' . PHP_VERSION . "\n";
    echo 'config: ' . (!empty($config['bot_token']) && !empty($config['site_url']) ? 'present' : 'MISSING') . "\n";
    echo 'secrets: ' . (strlen((string)$config['site_sync_secret']) >= 32 && strlen((string)$config['webhook_secret']) >= 32 ? 'length-ok' : 'TOO-SHORT') . "\n";
    echo 'key: ' . ($provided !== '' ? 'received' : 'missing') . "\n";
    exit;
}

if (empty($update)) { http_response_code(200); exit; }

$updateActor = (string)($update['pre_checkout_query']['from']['id'] ?? $update['callback_query']['from']['id'] ?? $update['message']['from']['id'] ?? '');
$updateId = isset($update['update_id']) ? (string)$update['update_id'] : '';
$isPaymentCompletionUpdate = isset($update['message']['successful_payment']);
if ($updateActor !== '') SiteClient::setActorChatId($updateActor);

// ───── pre_checkout_query — تأیید پیش از پرداخت ─────────────
// این آپدیت عمداً پیش از Claim عمومی پردازش می‌شود: بله برای پاسخ فقط ۱۰ ثانیه
// فرصت می‌دهد و Retry آن نیز باید همیشه answerPreCheckoutQuery دریافت کند.
if (isset($update['pre_checkout_query'])) {
    // حداکثر چهار ثانیه برای تطبیق سفارش با سایت؛ زمان باقی‌مانده برای پاسخ API بله.
    $preCheckoutConfig = $config;
    $preCheckoutConfig['site_connect_timeout'] = 2;
    $preCheckoutConfig['site_timeout'] = 4;
    $preCheckoutConfig['site_max_attempts'] = 1;   // مهلت ۱۰ ثانیه‌ای بله: تلاش دوباره ممکن نیست
    $preCheckoutConfig['site_queue_wait'] = 2;
    $preCheckoutConfig['site_retry_budget'] = 3;
    SiteClient::configure($preCheckoutConfig);
    $pcq = $update['pre_checkout_query'];
    $payload = (string)($pcq['invoice_payload'] ?? '');
    $orderId = preg_match('/^mph_order_(\d+)$/', $payload, $orderMatch) ? (int)$orderMatch[1] : 0;
    $valid = $orderId > 0 || preg_match('/^course_PAY_(\d+)(?:_(\d+))?$/', $payload, $paymentMatch) === 1;
    $enrollment = null;
    if ($valid) {
        $courseId = $orderId ? 0 : (int)$paymentMatch[1];
        $productId = !$orderId && isset($paymentMatch[2]) ? (int)$paymentMatch[2] : 0;
        try {
            $enrollment = $orderId ? Database::getEnrollmentById($orderId) : Database::getEnrollmentByUserCourse((int)$updateActor, $courseId, $productId);
        } catch (SiteSyncException $error) { $enrollment=null; }
        $expected = $enrollment ? (int)($enrollment['payment_amount_rial'] ?? ((int)$enrollment['price'] * 10)) : -1;
        $valid = $enrollment && ($enrollment['payment_status'] ?? '') !== 'paid'
            && (string)($enrollment['user_chat_id'] ?? '') === $updateActor
            && ($enrollment['order_status'] ?? '') === 'pending'
            && strtoupper((string)($pcq['currency'] ?? '')) === 'IRR'
            && (int)($pcq['total_amount'] ?? -2) === $expected;
    }
    $answered = $api->answerPreCheckoutQuery((string)$pcq['id'], (bool)$valid, $valid ? '' : 'اطلاعات سفارش با سایت مطابقت ندارد؛ لطفاً دوباره از منوی دوره اقدام کنید.');
    http_response_code(!empty($answered['ok']) ? 200 : 503);
    exit;
}

// شناسه سایر Updateها پیش از عملیات در دیتابیس سایت Claim می‌شود تا Retry بله
// باعث ساخت سفارش، تیکت یا پیام تکراری نشود.
// Claim is now part of the durable bootstrap below, after validating a private chat.

// ───── شناسایی نوع آپدیت ──────────────────────────────────────
$isCallback = isset($update['callback_query']);
$msg        = $isCallback
    ? ($update['callback_query']['message'] ?? null)
    : ($update['message'] ?? null);

if (!$msg) {
    if ($isCallback && !empty($update['callback_query']['id'])) {
        $api->answerCallbackQuery((string)$update['callback_query']['id'], 'این دکمه دیگر قابل استفاده نیست.', true);
    }
    http_response_code(200);
    exit;
}

$chatId = (string)($msg['chat']['id'] ?? '');
$senderId = (string)($isCallback ? ($update['callback_query']['from']['id'] ?? '') : ($msg['from']['id'] ?? ''));
$text   = trim($msg['text'] ?? '');
$clbk   = $isCallback ? trim($update['callback_query']['data'] ?? '') : null;

if ($chatId === '' || $senderId === '') { http_response_code(200); exit; }

// اطلاعات حساب فقط در گفت‌وگوی خصوصی نمایش داده می‌شود. در گروه، chat_id با
// شناسه فرد متفاوت است و استفاده از آن می‌تواند داده نقش/سفارش را افشا کند.
$chatType = strtolower((string)($msg['chat']['type'] ?? 'private'));
if ($chatType !== 'private' || !hash_equals($senderId, $chatId)) {
    $privateOnly = 'برای حفظ حریم خصوصی، از ربات فقط در گفت‌وگوی خصوصی استفاده کنید.';
    if ($isCallback) $api->answerCallbackQuery((string)($update['callback_query']['id'] ?? ''), $privateOnly, true);
    else $api->sendMessage($chatId, $privateOnly);
    http_response_code(200);
    exit;
}

SiteClient::setActorChatId($senderId);
StateManager::init();
Keyboards::configure($config);

// ───── صف‌بندی پیام‌های هر کاربر ──────────────────────────────
// لمس‌های پشت‌سرهم یک کاربر در خود ربات به‌ترتیب و یکی‌یکی پردازش می‌شوند؛ پس سایت هیچ‌وقت دو
// درخواست هم‌زمان از یک گفت‌وگو نمی‌بیند و پیام «ارتباط با سایت برقرار نیست» ساخته نمی‌شود.
$callbackId = $isCallback ? (string)($update['callback_query']['id'] ?? '') : '';
if (!ChatLock::acquire($chatId, $isCallback ? 5.0 : 20.0)) {
    if ($isCallback) {
        $api->answerCallbackQuery($callbackId, $config['messages']['busy_prev'], false);
        http_response_code(200);
    } else {
        http_response_code(503);   // بله همین پیام را بعداً دوباره می‌فرستد؛ پیام گم نمی‌شود
    }
    exit;
}
if ($isCallback && $clbk !== '' && $clbk !== 'noop') {
    // دابل‌تپ: همان دکمه روی همان پیام در کمتر از ۲ ثانیه فقط یک‌بار اجرا می‌شود.
    $dedupeKey = 'cbd:' . $chatId . ':' . md5((string)($msg['message_id'] ?? '') . '|' . $clbk);
    if (Cache::get($dedupeKey) !== null) {
        $api->answerCallbackQuery($callbackId);
        http_response_code(200);
        exit;
    }
    Cache::set($dedupeKey, 1, 2);
}

// ───── ناوبری «دوره‌های در حال ثبت‌نام»: بدون هیچ تماس لازم با سایت (از کش ۳۰ ثانیه‌ای) ─────
if ($isCallback && preg_match('/^oc:[ldr](:\d+)*$/D', (string)$clbk)) {
    $api->answerCallbackQuery($callbackId);
    (new OpenCoursesHandler($api))->callback($chatId, (int)($msg['message_id'] ?? 0), (string)$clbk, $callbackId);
    http_response_code(200);
    exit;
}
// ناوبری منو (گروه‌ها/بخش‌ها/دوره‌های من): فقط خواندن؛ نیازی به ثبت و تأیید پردازش (دو درخواست کمتر) نیست.
$lightNav = $isCallback && preg_match('/^(mg|mp|mc):/', (string)$clbk) === 1;

if (!$isPaymentCompletionUpdate && $updateId !== '' && !$lightNav) {
    try {
        $bootstrap=Database::bootstrap($chatId,$updateId,$update);
    } catch (SiteSyncException $error) {
        error_log('[BaleBazo] bootstrap_failed code='.$error->getRemoteCode());
        $failText = SiteClient::userMessage($error, $config['messages']);
        if ($isCallback) $api->answerCallbackQuery($callbackId, $failText, true);
        else $api->sendMessage($chatId, $failText);
        http_response_code(200);
        exit;
    }
    if (in_array($bootstrap['status'],['done','review'],true)) { http_response_code(200); exit; }
    UpdateLifecycle::attach($updateId,(string)$bootstrap['token']);
}
$context = Database::getContext($chatId);
if (!$context && Database::lastError()) {
    $failText = $config['messages']['site_unavailable'];
    $lastError = Database::lastError();
    if (in_array($lastError['code'] ?? '', ['site_busy', 'conversation_busy', 'update_busy'], true)) $failText = $config['messages']['site_busy'];
    if ($isCallback) {
        $api->answerCallbackQuery($callbackId, $failText, true);
    } else {
        $api->sendMessage($chatId, $failText);
    }
    http_response_code($isPaymentCompletionUpdate ? 503 : 200);
    exit;
}

$user = is_array($context['user'] ?? null) ? $context['user'] : null;
Keyboards::setUserContext($user ?? ['chat_id'=>$chatId]);

// قطعی‌کردن پرداخت حتی هنگام خاموش‌بودن ربات یا بلاک‌شدن بعدی کاربر اجرا
// می‌شود؛ پولی که قبلاً پرداخت شده نباید به‌دلیل وضعیت دسترسی معلق بماند.
if (!$isCallback && isset($msg['successful_payment'])) {
    if ($user) {
        $userHandler = new UserHandler($api);
        $processed = $userHandler->handleSuccessfulPayment($update, $user);
        http_response_code($processed ? 200 : 503);
        exit;
    }
    $api->sendMessage($chatId, '⚠️ پرداخت دریافت شد اما حساب بله به کاربر سایت متصل نیست؛ شناسه پرداخت را برای پشتیبانی ارسال کنید.');
    http_response_code(200);
    exit;
}

// ───── ریست وضعیت با /start ────────────────────────────────────
// رفع باگ: اگر کاربری به هر دلیلی در یک مرحله (step) گیر کرده باشد
// (مثلاً ناقص‌بودن یک پیام میانی)، با زدن /start وضعیت کاملاً پاک می‌شود
// تا ربات دوباره به‌درستی پاسخ‌گو باشد.
if (!$isCallback && $text === '/start') {
    StateManager::clear($chatId);
}

// ───── بررسی وضعیت ربات ──────────────────────────────────────
$botActive = !array_key_exists('bot_active', $context) || !empty($context['bot_active']);
$isAdmin   = !empty($context['is_admin']);
$isOwner   = !empty($context['is_owner']);

if (!$botActive && !$isAdmin) {
    if ($isCallback) {
        $api->answerCallbackQuery((string)($update['callback_query']['id'] ?? ''), $config['messages']['bot_off'], true);
    } else {
        $api->sendMessage($chatId, $config['messages']['bot_off']);
    }
    http_response_code(200);
    exit;
}

// ───── بررسی بلاک ─────────────────────────────────────────────
if ($user && $user['is_blocked']) {
    if ($isCallback) {
        $api->answerCallbackQuery((string)($update['callback_query']['id'] ?? ''), $config['messages']['blocked'], true);
    } else {
        $api->sendMessage($chatId, $config['messages']['blocked']);
    }
    http_response_code(200);
    exit;
}

// ───── Callback queries ────────────────────────────────────────
if ($isCallback) {
    // callback‌های مخصوص ادمین
    $adminCallbackPrefixes = [
        'reply_msg_', 'delcourse_', 'msg_broadcast', 'msg_single',
        'news_create_type_', 'delnews_', 'certpdf_', 'close_chat_',
        'confirm_pay_', 'paysettings_', 'view_receipt_',
        'course_enrolls_', 'cedit_', 'cadmin_', 'bot_admin_',
    ];
    $isAdminCallback = false;
    foreach ($adminCallbackPrefixes as $prefix) {
        if (str_starts_with($clbk, $prefix)) { $isAdminCallback = true; break; }
    }

    if ($isAdmin && $isAdminCallback) {
        $adminHandler = new AdminHandler($api);
        $adminHandler->handleCallback($update, $user ?? [], $isOwner);
        http_response_code(200);
        exit;
    }

    // callback کاربران ثبت‌نام‌شده
    if ($user) {
        $userHandler = new UserHandler($api);
        $userHandler->handleCallback($update, $user);
    } else {
        $api->answerCallbackQuery((string)($update['callback_query']['id'] ?? ''), $config['messages']['not_registered'], true);
    }
    http_response_code(200);
    exit;
}

// ───── پیام‌های متنی ─────────────────────────────────────────

// /start یا کاربر ثبت‌نام‌نشده
if ($text === '/start' || !$user) {
    if (!$user) {
        $step = StateManager::getStep($chatId);
        if ($text === '/start' || !$step || !str_starts_with($step, 'reg_')) {
            $api->sendMessage($chatId, $config['messages']['welcome_new'], Keyboards::cancelOnly());
        }
        $regHandler = new RegisterHandler($api);
        $regHandler->handle($update);
        http_response_code(200);
        exit;
    }
    $userHandler = new UserHandler($api);
    $userHandler->sendMainMenu($chatId, $user);
    http_response_code(200);
    exit;
}

// ───── تعریف متن‌های ادمین ────────────────────────────────────
$adminTexts = [
    '➕ افزودن ادمین', '➖ حذف ادمین',
    '⚙️ پنل مدیریت', '⚙️ ابزارهای مدیریت ربات', '🔴 خاموش کردن ربات', '🟢 روشن کردن ربات',
    '👥 لیست کاربران', '📋 لیست دوره‌ها', '➕ ثبت دوره جدید', '🗑 حذف دوره',
    '📢 انتشار خبر', '🗑 حذف خبر/اطلاعیه', '📨 ارسال پیام', '👤 افزودن/حذف ادمین', '🚫 بلاک کاربر',
    '📥 صندوق پیام‌ها', '📑 پاسخ‌داده‌شده‌ها', '🎓 صدور گواهینامه',
    '📅 نوبت‌های رزرو شده', '💳 لیست پرداخت‌ها', '💰 تنظیمات پرداخت', '📋 فایل کامل ثبت‌نامی‌ها',
    '🔙 بازگشت',
];

$step        = StateManager::getStep($chatId);
$isAdminStep = $step && (
    in_array($step, [
        'course_title', 'course_desc', 'course_promo', 'course_cap', 'course_price',
        'course_start', 'course_end',
        'news_title', 'news_content',
        'broadcast_text',
        'single_msg_target', 'single_msg_text',
        'add_admin_id',
        'bot_admin_add', 'bot_admin_remove', 'bot_admin_confirm',
        'block_user_id',
        'cert_user_id', 'cert_title', 'cert_date', 'cert_pdf_wait', 'cert_pdf_upload',
        'payment_card_number', 'payment_card_holder',
        'course_edit_field', 'course_edit_promo',
    ])
    || str_starts_with($step, 'admin_reply_')
);

// ───── مسیریابی ادمین / کاربر ────────────────────────────────
if ($isAdmin && (in_array($text, $adminTexts) || $isAdminStep)) {
    $adminHandler = new AdminHandler($api);
    $adminHandler->handle($update, $user, $isOwner);
} else {
    $userHandler = new UserHandler($api);
    $userHandler->handle($update, $user);
}

http_response_code(200);
